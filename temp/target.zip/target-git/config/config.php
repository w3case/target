<?php

    // Configurações do banco de dados
    define('HOSTNAME', 'localhost');
    define('USERNAME', 'root');
    define('PASSWORD', 'root');
    define('DATABASE', 'target');

    // Configurações de ftp para downloads de atualizações
    define('FTP_HOSTNAME', '127.0.0.1');
    define('FTP_USERNAME', 'admin');
    define('FTP_PASSWORD', 'admin');