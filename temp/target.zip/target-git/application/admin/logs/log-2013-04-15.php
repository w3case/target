<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-04-15 14:08:47 --> Config Class Initialized
DEBUG - 2013-04-15 14:08:47 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:08:47 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:08:47 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:08:47 --> URI Class Initialized
DEBUG - 2013-04-15 14:08:47 --> Router Class Initialized
DEBUG - 2013-04-15 14:08:47 --> No URI present. Default controller set.
DEBUG - 2013-04-15 14:08:47 --> Output Class Initialized
DEBUG - 2013-04-15 14:08:47 --> Security Class Initialized
DEBUG - 2013-04-15 14:08:47 --> Input Class Initialized
DEBUG - 2013-04-15 14:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:08:47 --> Language Class Initialized
DEBUG - 2013-04-15 14:08:47 --> Loader Class Initialized
DEBUG - 2013-04-15 14:08:47 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:08:47 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:08:47 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:08:47 --> Session Class Initialized
DEBUG - 2013-04-15 14:08:47 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:08:47 --> A session cookie was not found.
DEBUG - 2013-04-15 14:08:47 --> Session routines successfully run
DEBUG - 2013-04-15 14:08:47 --> Controller Class Initialized
DEBUG - 2013-04-15 14:08:47 --> Language Class Initialized
DEBUG - 2013-04-15 14:08:47 --> Config Class Initialized
DEBUG - 2013-04-15 14:08:47 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-15 14:08:47 --> Loader Class Initialized
DEBUG - 2013-04-15 14:08:47 --> File loaded: ../application/admin/modules/autenticacao/views/login.php
DEBUG - 2013-04-15 14:08:47 --> Final output sent to browser
DEBUG - 2013-04-15 14:08:47 --> Total execution time: 0.0883
DEBUG - 2013-04-15 14:08:53 --> Config Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:08:53 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:08:53 --> URI Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Router Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Output Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Security Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Input Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:08:53 --> Language Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Loader Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:08:53 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:08:53 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:08:53 --> Session Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:08:53 --> Session routines successfully run
DEBUG - 2013-04-15 14:08:53 --> Controller Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Language Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Config Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-15 14:08:53 --> Loader Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Model Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Model Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Database Driver Class Initialized
DEBUG - 2013-04-15 14:08:53 --> Model Class Initialized
ERROR - 2013-04-15 14:08:53 --> Severity: Notice  --> Undefined index: orlike /home/w3case/public_html/target-git/application/admin/models/crud.php 121
ERROR - 2013-04-15 14:08:53 --> Severity: Notice  --> Undefined index: orlike /home/w3case/public_html/target-git/application/admin/models/crud.php 121
DEBUG - 2013-04-15 14:08:53 --> Final output sent to browser
DEBUG - 2013-04-15 14:08:53 --> Total execution time: 0.6886
DEBUG - 2013-04-15 14:08:54 --> Config Class Initialized
DEBUG - 2013-04-15 14:08:54 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:08:54 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:08:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:08:54 --> URI Class Initialized
DEBUG - 2013-04-15 14:08:54 --> Router Class Initialized
DEBUG - 2013-04-15 14:08:54 --> Output Class Initialized
DEBUG - 2013-04-15 14:08:54 --> Security Class Initialized
DEBUG - 2013-04-15 14:08:54 --> Input Class Initialized
DEBUG - 2013-04-15 14:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:08:54 --> Language Class Initialized
DEBUG - 2013-04-15 14:08:54 --> Loader Class Initialized
DEBUG - 2013-04-15 14:08:54 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:08:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:08:54 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:08:54 --> Session Class Initialized
DEBUG - 2013-04-15 14:08:54 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:08:54 --> Session routines successfully run
DEBUG - 2013-04-15 14:08:54 --> Controller Class Initialized
DEBUG - 2013-04-15 14:08:54 --> Language Class Initialized
DEBUG - 2013-04-15 14:08:54 --> Config Class Initialized
DEBUG - 2013-04-15 14:08:54 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 14:08:54 --> Loader Class Initialized
DEBUG - 2013-04-15 14:08:54 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-15 14:08:54 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:08:54 --> Final output sent to browser
DEBUG - 2013-04-15 14:08:54 --> Total execution time: 0.0165
DEBUG - 2013-04-15 14:08:56 --> Config Class Initialized
DEBUG - 2013-04-15 14:08:56 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:08:56 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:08:56 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:08:56 --> URI Class Initialized
DEBUG - 2013-04-15 14:08:56 --> Router Class Initialized
DEBUG - 2013-04-15 14:08:56 --> Output Class Initialized
DEBUG - 2013-04-15 14:08:56 --> Security Class Initialized
DEBUG - 2013-04-15 14:08:56 --> Input Class Initialized
DEBUG - 2013-04-15 14:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:08:56 --> Language Class Initialized
DEBUG - 2013-04-15 14:08:56 --> Loader Class Initialized
DEBUG - 2013-04-15 14:08:56 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:08:56 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:08:56 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:08:56 --> Session Class Initialized
DEBUG - 2013-04-15 14:08:56 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:08:56 --> Session routines successfully run
DEBUG - 2013-04-15 14:08:56 --> Controller Class Initialized
DEBUG - 2013-04-15 14:08:56 --> Language Class Initialized
DEBUG - 2013-04-15 14:08:56 --> Config Class Initialized
DEBUG - 2013-04-15 14:08:56 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 14:08:56 --> Loader Class Initialized
DEBUG - 2013-04-15 14:08:56 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-15 14:08:56 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:08:56 --> Final output sent to browser
DEBUG - 2013-04-15 14:08:56 --> Total execution time: 0.0215
DEBUG - 2013-04-15 14:08:59 --> Config Class Initialized
DEBUG - 2013-04-15 14:08:59 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:08:59 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:08:59 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:08:59 --> URI Class Initialized
DEBUG - 2013-04-15 14:08:59 --> Router Class Initialized
DEBUG - 2013-04-15 14:08:59 --> Output Class Initialized
DEBUG - 2013-04-15 14:08:59 --> Security Class Initialized
DEBUG - 2013-04-15 14:08:59 --> Input Class Initialized
DEBUG - 2013-04-15 14:08:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:08:59 --> Language Class Initialized
DEBUG - 2013-04-15 14:08:59 --> Loader Class Initialized
DEBUG - 2013-04-15 14:08:59 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:08:59 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:08:59 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:08:59 --> Session Class Initialized
DEBUG - 2013-04-15 14:08:59 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:08:59 --> Session routines successfully run
DEBUG - 2013-04-15 14:08:59 --> Controller Class Initialized
DEBUG - 2013-04-15 14:08:59 --> Language Class Initialized
DEBUG - 2013-04-15 14:08:59 --> Config Class Initialized
DEBUG - 2013-04-15 14:08:59 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-15 14:08:59 --> Loader Class Initialized
DEBUG - 2013-04-15 14:08:59 --> Model Class Initialized
DEBUG - 2013-04-15 14:08:59 --> Model Class Initialized
DEBUG - 2013-04-15 14:08:59 --> Database Driver Class Initialized
DEBUG - 2013-04-15 14:08:59 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-15 14:08:59 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-15 14:08:59 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:08:59 --> Final output sent to browser
DEBUG - 2013-04-15 14:08:59 --> Total execution time: 0.0431
DEBUG - 2013-04-15 14:09:05 --> Config Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:09:05 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:09:05 --> URI Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Router Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Output Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Security Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Input Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:09:05 --> Language Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Loader Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:09:05 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:09:05 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:09:05 --> Session Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:09:05 --> Session routines successfully run
DEBUG - 2013-04-15 14:09:05 --> Controller Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Language Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Config Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-15 14:09:05 --> Loader Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Model Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Model Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Database Driver Class Initialized
DEBUG - 2013-04-15 14:09:05 --> Model Class Initialized
DEBUG - 2013-04-15 14:09:05 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-15 14:09:05 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-15 14:09:05 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:09:05 --> Final output sent to browser
DEBUG - 2013-04-15 14:09:05 --> Total execution time: 0.0283
DEBUG - 2013-04-15 14:09:19 --> Config Class Initialized
DEBUG - 2013-04-15 14:09:19 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:09:19 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:09:19 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:09:19 --> URI Class Initialized
DEBUG - 2013-04-15 14:09:19 --> Router Class Initialized
DEBUG - 2013-04-15 14:09:19 --> Output Class Initialized
DEBUG - 2013-04-15 14:09:19 --> Security Class Initialized
DEBUG - 2013-04-15 14:09:19 --> Input Class Initialized
DEBUG - 2013-04-15 14:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:09:19 --> Language Class Initialized
DEBUG - 2013-04-15 14:09:19 --> Loader Class Initialized
DEBUG - 2013-04-15 14:09:19 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:09:19 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:09:19 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:09:19 --> Session Class Initialized
DEBUG - 2013-04-15 14:09:19 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:09:19 --> Session routines successfully run
DEBUG - 2013-04-15 14:09:19 --> Controller Class Initialized
DEBUG - 2013-04-15 14:09:19 --> Language Class Initialized
DEBUG - 2013-04-15 14:09:19 --> Config Class Initialized
DEBUG - 2013-04-15 14:09:19 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-15 14:09:19 --> Loader Class Initialized
DEBUG - 2013-04-15 14:09:19 --> Model Class Initialized
DEBUG - 2013-04-15 14:09:19 --> Model Class Initialized
DEBUG - 2013-04-15 14:09:19 --> Database Driver Class Initialized
DEBUG - 2013-04-15 14:09:19 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-15 14:09:19 --> File loaded: ../application/admin/modules/usuarios/views/usuarios.php
DEBUG - 2013-04-15 14:09:19 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:09:19 --> Final output sent to browser
DEBUG - 2013-04-15 14:09:19 --> Total execution time: 0.0356
DEBUG - 2013-04-15 14:09:21 --> Config Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:09:21 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:09:21 --> URI Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Router Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Output Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Security Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Input Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:09:21 --> Language Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Loader Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:09:21 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:09:21 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:09:21 --> Session Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:09:21 --> Session routines successfully run
DEBUG - 2013-04-15 14:09:21 --> Controller Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Language Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Config Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-15 14:09:21 --> Loader Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Model Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Model Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Database Driver Class Initialized
ERROR - 2013-04-15 14:09:21 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-15 14:09:21 --> Pagination Class Initialized
DEBUG - 2013-04-15 14:09:21 --> Model Class Initialized
DEBUG - 2013-04-15 14:09:21 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-15 14:09:21 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-15 14:09:21 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:09:21 --> Final output sent to browser
DEBUG - 2013-04-15 14:09:21 --> Total execution time: 0.0349
DEBUG - 2013-04-15 14:09:25 --> Config Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:09:25 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:09:25 --> URI Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Router Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Output Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Security Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Input Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:09:25 --> Language Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Loader Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:09:25 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:09:25 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:09:25 --> Session Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:09:25 --> Session routines successfully run
DEBUG - 2013-04-15 14:09:25 --> Controller Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Language Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Config Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-15 14:09:25 --> Loader Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Model Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Model Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Database Driver Class Initialized
DEBUG - 2013-04-15 14:09:25 --> Model Class Initialized
DEBUG - 2013-04-15 14:09:25 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-15 14:09:25 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-15 14:09:25 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:09:25 --> Final output sent to browser
DEBUG - 2013-04-15 14:09:25 --> Total execution time: 0.0300
DEBUG - 2013-04-15 14:09:28 --> Config Class Initialized
DEBUG - 2013-04-15 14:09:28 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:09:28 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:09:28 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:09:28 --> URI Class Initialized
DEBUG - 2013-04-15 14:09:28 --> Router Class Initialized
DEBUG - 2013-04-15 14:09:28 --> Output Class Initialized
DEBUG - 2013-04-15 14:09:28 --> Security Class Initialized
DEBUG - 2013-04-15 14:09:28 --> Input Class Initialized
DEBUG - 2013-04-15 14:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:09:28 --> Language Class Initialized
DEBUG - 2013-04-15 14:09:28 --> Loader Class Initialized
DEBUG - 2013-04-15 14:09:28 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:09:28 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:09:28 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:09:28 --> Session Class Initialized
DEBUG - 2013-04-15 14:09:28 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:09:28 --> Session routines successfully run
DEBUG - 2013-04-15 14:09:28 --> Controller Class Initialized
DEBUG - 2013-04-15 14:09:28 --> Language Class Initialized
DEBUG - 2013-04-15 14:09:28 --> Config Class Initialized
DEBUG - 2013-04-15 14:09:28 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-15 14:09:28 --> Loader Class Initialized
DEBUG - 2013-04-15 14:09:28 --> Model Class Initialized
DEBUG - 2013-04-15 14:09:28 --> Model Class Initialized
DEBUG - 2013-04-15 14:09:28 --> Database Driver Class Initialized
DEBUG - 2013-04-15 14:09:28 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-15 14:09:28 --> File loaded: ../application/admin/modules/usuarios/views/usuarios.php
DEBUG - 2013-04-15 14:09:28 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:09:28 --> Final output sent to browser
DEBUG - 2013-04-15 14:09:28 --> Total execution time: 0.0227
DEBUG - 2013-04-15 14:09:30 --> Config Class Initialized
DEBUG - 2013-04-15 14:09:30 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:09:30 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:09:30 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:09:30 --> URI Class Initialized
DEBUG - 2013-04-15 14:09:30 --> Router Class Initialized
DEBUG - 2013-04-15 14:09:30 --> Output Class Initialized
DEBUG - 2013-04-15 14:09:30 --> Security Class Initialized
DEBUG - 2013-04-15 14:09:30 --> Input Class Initialized
DEBUG - 2013-04-15 14:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:09:30 --> Language Class Initialized
DEBUG - 2013-04-15 14:09:30 --> Loader Class Initialized
DEBUG - 2013-04-15 14:09:30 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:09:30 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:09:30 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:09:30 --> Session Class Initialized
DEBUG - 2013-04-15 14:09:30 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:09:30 --> Session routines successfully run
DEBUG - 2013-04-15 14:09:30 --> Controller Class Initialized
DEBUG - 2013-04-15 14:09:30 --> Language Class Initialized
DEBUG - 2013-04-15 14:09:30 --> Config Class Initialized
DEBUG - 2013-04-15 14:09:30 --> Textos MX_Controller Initialized
DEBUG - 2013-04-15 14:09:30 --> Loader Class Initialized
DEBUG - 2013-04-15 14:09:30 --> File loaded: ../application/admin/modules/textos/views/nav.php
DEBUG - 2013-04-15 14:09:30 --> File loaded: ../application/admin/modules/textos/views/textos.php
DEBUG - 2013-04-15 14:09:30 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:09:30 --> Final output sent to browser
DEBUG - 2013-04-15 14:09:30 --> Total execution time: 0.0216
DEBUG - 2013-04-15 14:36:27 --> Config Class Initialized
DEBUG - 2013-04-15 14:36:27 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:36:27 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:36:27 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:36:27 --> URI Class Initialized
DEBUG - 2013-04-15 14:36:27 --> Router Class Initialized
DEBUG - 2013-04-15 14:36:27 --> No URI present. Default controller set.
DEBUG - 2013-04-15 14:36:27 --> Output Class Initialized
DEBUG - 2013-04-15 14:36:27 --> Security Class Initialized
DEBUG - 2013-04-15 14:36:27 --> Input Class Initialized
DEBUG - 2013-04-15 14:36:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:36:27 --> Language Class Initialized
DEBUG - 2013-04-15 14:36:27 --> Loader Class Initialized
DEBUG - 2013-04-15 14:36:27 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:36:27 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:36:27 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:36:27 --> Session Class Initialized
DEBUG - 2013-04-15 14:36:27 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:36:27 --> Session routines successfully run
DEBUG - 2013-04-15 14:36:27 --> Controller Class Initialized
DEBUG - 2013-04-15 14:36:27 --> Language Class Initialized
DEBUG - 2013-04-15 14:36:27 --> Config Class Initialized
DEBUG - 2013-04-15 14:36:27 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-15 14:36:27 --> Loader Class Initialized
DEBUG - 2013-04-15 14:36:27 --> File loaded: ../application/admin/modules/autenticacao/views/login.php
DEBUG - 2013-04-15 14:36:27 --> Final output sent to browser
DEBUG - 2013-04-15 14:36:27 --> Total execution time: 0.0156
DEBUG - 2013-04-15 14:36:34 --> Config Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:36:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:36:34 --> URI Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Router Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Output Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Security Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Input Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:36:34 --> Language Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Loader Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:36:34 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:36:34 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:36:34 --> Session Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:36:34 --> Session routines successfully run
DEBUG - 2013-04-15 14:36:34 --> Controller Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Language Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Config Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-15 14:36:34 --> Loader Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Model Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Model Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Database Driver Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Model Class Initialized
ERROR - 2013-04-15 14:36:34 --> Severity: Notice  --> Undefined index: orlike /home/w3case/public_html/target-git/application/admin/models/crud.php 121
ERROR - 2013-04-15 14:36:34 --> Severity: Notice  --> Undefined index: orlike /home/w3case/public_html/target-git/application/admin/models/crud.php 121
DEBUG - 2013-04-15 14:36:34 --> Final output sent to browser
DEBUG - 2013-04-15 14:36:34 --> Total execution time: 0.6091
DEBUG - 2013-04-15 14:36:34 --> Config Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:36:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:36:34 --> URI Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Router Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Output Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Security Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Input Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:36:34 --> Language Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Loader Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:36:34 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:36:34 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:36:34 --> Session Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:36:34 --> Session routines successfully run
DEBUG - 2013-04-15 14:36:34 --> Controller Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Language Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Config Class Initialized
DEBUG - 2013-04-15 14:36:34 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 14:36:34 --> Loader Class Initialized
DEBUG - 2013-04-15 14:36:34 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-15 14:36:34 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:36:34 --> Final output sent to browser
DEBUG - 2013-04-15 14:36:34 --> Total execution time: 0.0183
DEBUG - 2013-04-15 14:36:37 --> Config Class Initialized
DEBUG - 2013-04-15 14:36:37 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:36:37 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:36:37 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:36:37 --> URI Class Initialized
DEBUG - 2013-04-15 14:36:37 --> Router Class Initialized
DEBUG - 2013-04-15 14:36:37 --> Output Class Initialized
DEBUG - 2013-04-15 14:36:37 --> Security Class Initialized
DEBUG - 2013-04-15 14:36:37 --> Input Class Initialized
DEBUG - 2013-04-15 14:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:36:37 --> Language Class Initialized
DEBUG - 2013-04-15 14:36:37 --> Loader Class Initialized
DEBUG - 2013-04-15 14:36:37 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:36:37 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:36:37 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:36:37 --> Session Class Initialized
DEBUG - 2013-04-15 14:36:37 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:36:37 --> Session routines successfully run
DEBUG - 2013-04-15 14:36:37 --> Controller Class Initialized
DEBUG - 2013-04-15 14:36:37 --> Language Class Initialized
DEBUG - 2013-04-15 14:36:37 --> Config Class Initialized
DEBUG - 2013-04-15 14:36:37 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 14:36:37 --> Loader Class Initialized
DEBUG - 2013-04-15 14:36:37 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-15 14:36:37 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:36:37 --> Final output sent to browser
DEBUG - 2013-04-15 14:36:37 --> Total execution time: 0.0161
DEBUG - 2013-04-15 14:36:40 --> Config Class Initialized
DEBUG - 2013-04-15 14:36:40 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:36:40 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:36:40 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:36:40 --> URI Class Initialized
DEBUG - 2013-04-15 14:36:40 --> Router Class Initialized
DEBUG - 2013-04-15 14:36:40 --> Output Class Initialized
DEBUG - 2013-04-15 14:36:40 --> Security Class Initialized
DEBUG - 2013-04-15 14:36:40 --> Input Class Initialized
DEBUG - 2013-04-15 14:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:36:40 --> Language Class Initialized
DEBUG - 2013-04-15 14:36:40 --> Loader Class Initialized
DEBUG - 2013-04-15 14:36:40 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:36:40 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:36:40 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:36:40 --> Session Class Initialized
DEBUG - 2013-04-15 14:36:40 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:36:40 --> Session routines successfully run
DEBUG - 2013-04-15 14:36:40 --> Controller Class Initialized
DEBUG - 2013-04-15 14:36:40 --> Language Class Initialized
DEBUG - 2013-04-15 14:36:40 --> Config Class Initialized
DEBUG - 2013-04-15 14:36:40 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 14:36:40 --> Loader Class Initialized
DEBUG - 2013-04-15 14:36:40 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-15 14:36:40 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:36:40 --> Final output sent to browser
DEBUG - 2013-04-15 14:36:40 --> Total execution time: 0.0185
DEBUG - 2013-04-15 14:40:07 --> Config Class Initialized
DEBUG - 2013-04-15 14:40:07 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:40:07 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:40:07 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:40:07 --> URI Class Initialized
DEBUG - 2013-04-15 14:40:07 --> Router Class Initialized
DEBUG - 2013-04-15 14:40:07 --> Output Class Initialized
DEBUG - 2013-04-15 14:40:07 --> Security Class Initialized
DEBUG - 2013-04-15 14:40:07 --> Input Class Initialized
DEBUG - 2013-04-15 14:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:40:07 --> Language Class Initialized
DEBUG - 2013-04-15 14:40:07 --> Loader Class Initialized
DEBUG - 2013-04-15 14:40:07 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:40:07 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:40:07 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:40:07 --> Session Class Initialized
DEBUG - 2013-04-15 14:40:07 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:40:07 --> Session routines successfully run
DEBUG - 2013-04-15 14:40:07 --> Controller Class Initialized
DEBUG - 2013-04-15 14:40:07 --> Language Class Initialized
DEBUG - 2013-04-15 14:40:07 --> Config Class Initialized
DEBUG - 2013-04-15 14:40:07 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 14:40:07 --> Loader Class Initialized
DEBUG - 2013-04-15 14:40:07 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-15 14:40:07 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:40:07 --> Final output sent to browser
DEBUG - 2013-04-15 14:40:07 --> Total execution time: 0.0157
DEBUG - 2013-04-15 14:40:09 --> Config Class Initialized
DEBUG - 2013-04-15 14:40:09 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:40:09 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:40:09 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:40:09 --> URI Class Initialized
DEBUG - 2013-04-15 14:40:09 --> Router Class Initialized
DEBUG - 2013-04-15 14:40:09 --> Output Class Initialized
DEBUG - 2013-04-15 14:40:09 --> Security Class Initialized
DEBUG - 2013-04-15 14:40:09 --> Input Class Initialized
DEBUG - 2013-04-15 14:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:40:09 --> Language Class Initialized
DEBUG - 2013-04-15 14:40:09 --> Loader Class Initialized
DEBUG - 2013-04-15 14:40:09 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:40:09 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:40:09 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:40:09 --> Session Class Initialized
DEBUG - 2013-04-15 14:40:09 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:40:09 --> Session routines successfully run
DEBUG - 2013-04-15 14:40:09 --> Controller Class Initialized
DEBUG - 2013-04-15 14:40:09 --> Language Class Initialized
DEBUG - 2013-04-15 14:40:09 --> Config Class Initialized
DEBUG - 2013-04-15 14:40:09 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-15 14:40:09 --> Loader Class Initialized
DEBUG - 2013-04-15 14:40:09 --> Model Class Initialized
DEBUG - 2013-04-15 14:40:09 --> Model Class Initialized
DEBUG - 2013-04-15 14:40:09 --> Database Driver Class Initialized
DEBUG - 2013-04-15 14:40:09 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-15 14:40:09 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-15 14:40:09 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:40:09 --> Final output sent to browser
DEBUG - 2013-04-15 14:40:09 --> Total execution time: 0.0251
DEBUG - 2013-04-15 14:40:10 --> Config Class Initialized
DEBUG - 2013-04-15 14:40:10 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:40:10 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:40:10 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:40:10 --> URI Class Initialized
DEBUG - 2013-04-15 14:40:10 --> Router Class Initialized
DEBUG - 2013-04-15 14:40:10 --> Output Class Initialized
DEBUG - 2013-04-15 14:40:10 --> Security Class Initialized
DEBUG - 2013-04-15 14:40:10 --> Input Class Initialized
DEBUG - 2013-04-15 14:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:40:10 --> Language Class Initialized
DEBUG - 2013-04-15 14:40:10 --> Loader Class Initialized
DEBUG - 2013-04-15 14:40:10 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:40:10 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:40:10 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:40:10 --> Session Class Initialized
DEBUG - 2013-04-15 14:40:10 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:40:10 --> Session routines successfully run
DEBUG - 2013-04-15 14:40:10 --> Controller Class Initialized
DEBUG - 2013-04-15 14:40:10 --> Language Class Initialized
DEBUG - 2013-04-15 14:40:10 --> Config Class Initialized
DEBUG - 2013-04-15 14:40:10 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-15 14:40:10 --> Loader Class Initialized
DEBUG - 2013-04-15 14:40:10 --> Model Class Initialized
DEBUG - 2013-04-15 14:40:10 --> Model Class Initialized
DEBUG - 2013-04-15 14:40:10 --> Database Driver Class Initialized
DEBUG - 2013-04-15 14:40:10 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-15 14:40:10 --> File loaded: ../application/admin/modules/usuarios/views/usuarios.php
DEBUG - 2013-04-15 14:40:10 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:40:10 --> Final output sent to browser
DEBUG - 2013-04-15 14:40:10 --> Total execution time: 0.0275
DEBUG - 2013-04-15 14:40:12 --> Config Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:40:12 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:40:12 --> URI Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Router Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Output Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Security Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Input Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:40:12 --> Language Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Loader Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:40:12 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:40:12 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:40:12 --> Session Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:40:12 --> Session routines successfully run
DEBUG - 2013-04-15 14:40:12 --> Controller Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Language Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Config Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-15 14:40:12 --> Loader Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Model Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Model Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Database Driver Class Initialized
ERROR - 2013-04-15 14:40:12 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-15 14:40:12 --> Pagination Class Initialized
DEBUG - 2013-04-15 14:40:12 --> Model Class Initialized
DEBUG - 2013-04-15 14:40:12 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-15 14:40:12 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-15 14:40:12 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:40:12 --> Final output sent to browser
DEBUG - 2013-04-15 14:40:12 --> Total execution time: 0.0304
DEBUG - 2013-04-15 14:44:35 --> Config Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:44:35 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:44:35 --> URI Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Router Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Output Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Security Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Input Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:44:35 --> Language Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Loader Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:44:35 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:44:35 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:44:35 --> Session Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:44:35 --> Session routines successfully run
DEBUG - 2013-04-15 14:44:35 --> Controller Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Language Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Config Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-15 14:44:35 --> Loader Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Model Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Model Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Database Driver Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Model Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Final output sent to browser
DEBUG - 2013-04-15 14:44:35 --> Total execution time: 0.0235
DEBUG - 2013-04-15 14:44:35 --> Config Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:44:35 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:44:35 --> URI Class Initialized
DEBUG - 2013-04-15 14:44:35 --> Router Class Initialized
DEBUG - 2013-04-15 14:44:36 --> Output Class Initialized
DEBUG - 2013-04-15 14:44:36 --> Security Class Initialized
DEBUG - 2013-04-15 14:44:36 --> Input Class Initialized
DEBUG - 2013-04-15 14:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:44:36 --> Language Class Initialized
DEBUG - 2013-04-15 14:44:36 --> Loader Class Initialized
DEBUG - 2013-04-15 14:44:36 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:44:36 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:44:36 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:44:36 --> Session Class Initialized
DEBUG - 2013-04-15 14:44:36 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:44:36 --> Session routines successfully run
DEBUG - 2013-04-15 14:44:36 --> Controller Class Initialized
DEBUG - 2013-04-15 14:44:36 --> Language Class Initialized
DEBUG - 2013-04-15 14:44:36 --> Config Class Initialized
DEBUG - 2013-04-15 14:44:36 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-15 14:44:36 --> Loader Class Initialized
DEBUG - 2013-04-15 14:44:36 --> Model Class Initialized
DEBUG - 2013-04-15 14:44:36 --> Model Class Initialized
DEBUG - 2013-04-15 14:44:36 --> Database Driver Class Initialized
ERROR - 2013-04-15 14:44:36 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-15 14:44:36 --> Pagination Class Initialized
DEBUG - 2013-04-15 14:44:36 --> Model Class Initialized
DEBUG - 2013-04-15 14:44:36 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-15 14:44:36 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-15 14:44:36 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:44:36 --> Final output sent to browser
DEBUG - 2013-04-15 14:44:36 --> Total execution time: 0.0303
DEBUG - 2013-04-15 14:48:33 --> Config Class Initialized
DEBUG - 2013-04-15 14:48:33 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:48:33 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:48:33 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:48:33 --> URI Class Initialized
DEBUG - 2013-04-15 14:48:33 --> Router Class Initialized
DEBUG - 2013-04-15 14:48:33 --> Output Class Initialized
DEBUG - 2013-04-15 14:48:34 --> Security Class Initialized
DEBUG - 2013-04-15 14:48:34 --> Input Class Initialized
DEBUG - 2013-04-15 14:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:48:34 --> Language Class Initialized
DEBUG - 2013-04-15 14:48:34 --> Loader Class Initialized
DEBUG - 2013-04-15 14:48:34 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:48:34 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:48:34 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:48:34 --> Session Class Initialized
DEBUG - 2013-04-15 14:48:34 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:48:34 --> Session routines successfully run
DEBUG - 2013-04-15 14:48:34 --> Controller Class Initialized
DEBUG - 2013-04-15 14:48:34 --> Language Class Initialized
DEBUG - 2013-04-15 14:48:34 --> Config Class Initialized
DEBUG - 2013-04-15 14:48:34 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 14:48:34 --> Loader Class Initialized
DEBUG - 2013-04-15 14:48:34 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-15 14:48:34 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:48:34 --> Final output sent to browser
DEBUG - 2013-04-15 14:48:34 --> Total execution time: 0.0167
DEBUG - 2013-04-15 14:48:36 --> Config Class Initialized
DEBUG - 2013-04-15 14:48:36 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:48:36 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:48:36 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:48:36 --> URI Class Initialized
DEBUG - 2013-04-15 14:48:36 --> Router Class Initialized
DEBUG - 2013-04-15 14:48:36 --> Output Class Initialized
DEBUG - 2013-04-15 14:48:36 --> Security Class Initialized
DEBUG - 2013-04-15 14:48:36 --> Input Class Initialized
DEBUG - 2013-04-15 14:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:48:36 --> Language Class Initialized
DEBUG - 2013-04-15 14:48:36 --> Loader Class Initialized
DEBUG - 2013-04-15 14:48:36 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:48:36 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:48:36 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:48:36 --> Session Class Initialized
DEBUG - 2013-04-15 14:48:36 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:48:36 --> Session routines successfully run
DEBUG - 2013-04-15 14:48:36 --> Controller Class Initialized
DEBUG - 2013-04-15 14:48:36 --> Language Class Initialized
DEBUG - 2013-04-15 14:48:36 --> Config Class Initialized
DEBUG - 2013-04-15 14:48:36 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 14:48:36 --> Loader Class Initialized
DEBUG - 2013-04-15 14:48:36 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-15 14:48:36 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:48:36 --> Final output sent to browser
DEBUG - 2013-04-15 14:48:36 --> Total execution time: 0.0154
DEBUG - 2013-04-15 14:48:38 --> Config Class Initialized
DEBUG - 2013-04-15 14:48:38 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:48:38 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:48:38 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:48:38 --> URI Class Initialized
DEBUG - 2013-04-15 14:48:38 --> Router Class Initialized
DEBUG - 2013-04-15 14:48:38 --> Output Class Initialized
DEBUG - 2013-04-15 14:48:38 --> Security Class Initialized
DEBUG - 2013-04-15 14:48:38 --> Input Class Initialized
DEBUG - 2013-04-15 14:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:48:38 --> Language Class Initialized
DEBUG - 2013-04-15 14:48:38 --> Loader Class Initialized
DEBUG - 2013-04-15 14:48:38 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:48:38 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:48:38 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:48:38 --> Session Class Initialized
DEBUG - 2013-04-15 14:48:38 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:48:38 --> Session routines successfully run
DEBUG - 2013-04-15 14:48:38 --> Controller Class Initialized
DEBUG - 2013-04-15 14:48:38 --> Language Class Initialized
DEBUG - 2013-04-15 14:48:38 --> Config Class Initialized
DEBUG - 2013-04-15 14:48:38 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 14:48:38 --> Loader Class Initialized
DEBUG - 2013-04-15 14:48:38 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-15 14:48:38 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:48:38 --> Final output sent to browser
DEBUG - 2013-04-15 14:48:38 --> Total execution time: 0.0168
DEBUG - 2013-04-15 14:48:39 --> Config Class Initialized
DEBUG - 2013-04-15 14:48:39 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:48:39 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:48:39 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:48:39 --> URI Class Initialized
DEBUG - 2013-04-15 14:48:39 --> Router Class Initialized
DEBUG - 2013-04-15 14:48:39 --> Output Class Initialized
DEBUG - 2013-04-15 14:48:39 --> Security Class Initialized
DEBUG - 2013-04-15 14:48:39 --> Input Class Initialized
DEBUG - 2013-04-15 14:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:48:39 --> Language Class Initialized
DEBUG - 2013-04-15 14:48:39 --> Loader Class Initialized
DEBUG - 2013-04-15 14:48:39 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:48:39 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:48:39 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:48:39 --> Session Class Initialized
DEBUG - 2013-04-15 14:48:39 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:48:39 --> Session routines successfully run
DEBUG - 2013-04-15 14:48:39 --> Controller Class Initialized
DEBUG - 2013-04-15 14:48:39 --> Language Class Initialized
DEBUG - 2013-04-15 14:48:39 --> Config Class Initialized
DEBUG - 2013-04-15 14:48:39 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-15 14:48:39 --> Loader Class Initialized
DEBUG - 2013-04-15 14:48:39 --> Model Class Initialized
DEBUG - 2013-04-15 14:48:39 --> Model Class Initialized
DEBUG - 2013-04-15 14:48:39 --> Database Driver Class Initialized
DEBUG - 2013-04-15 14:48:39 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-15 14:48:39 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-15 14:48:39 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:48:39 --> Final output sent to browser
DEBUG - 2013-04-15 14:48:39 --> Total execution time: 0.0227
DEBUG - 2013-04-15 14:49:41 --> Config Class Initialized
DEBUG - 2013-04-15 14:49:41 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:49:41 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:49:41 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:49:41 --> URI Class Initialized
DEBUG - 2013-04-15 14:49:41 --> Router Class Initialized
DEBUG - 2013-04-15 14:49:41 --> Output Class Initialized
DEBUG - 2013-04-15 14:49:41 --> Security Class Initialized
DEBUG - 2013-04-15 14:49:41 --> Input Class Initialized
DEBUG - 2013-04-15 14:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:49:41 --> Language Class Initialized
DEBUG - 2013-04-15 14:49:41 --> Loader Class Initialized
DEBUG - 2013-04-15 14:49:41 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:49:41 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:49:41 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:49:41 --> Session Class Initialized
DEBUG - 2013-04-15 14:49:41 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:49:41 --> Session routines successfully run
DEBUG - 2013-04-15 14:49:41 --> Controller Class Initialized
DEBUG - 2013-04-15 14:49:41 --> Language Class Initialized
DEBUG - 2013-04-15 14:49:41 --> Config Class Initialized
DEBUG - 2013-04-15 14:49:41 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 14:49:41 --> Loader Class Initialized
DEBUG - 2013-04-15 14:49:41 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-15 14:49:41 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 14:49:41 --> Final output sent to browser
DEBUG - 2013-04-15 14:49:41 --> Total execution time: 0.0198
DEBUG - 2013-04-15 14:49:42 --> Config Class Initialized
DEBUG - 2013-04-15 14:49:42 --> Hooks Class Initialized
DEBUG - 2013-04-15 14:49:42 --> Utf8 Class Initialized
DEBUG - 2013-04-15 14:49:42 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 14:49:42 --> URI Class Initialized
DEBUG - 2013-04-15 14:49:42 --> Router Class Initialized
DEBUG - 2013-04-15 14:49:42 --> Output Class Initialized
DEBUG - 2013-04-15 14:49:42 --> Security Class Initialized
DEBUG - 2013-04-15 14:49:42 --> Input Class Initialized
DEBUG - 2013-04-15 14:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 14:49:42 --> Language Class Initialized
DEBUG - 2013-04-15 14:49:42 --> Loader Class Initialized
DEBUG - 2013-04-15 14:49:42 --> Helper loaded: url_helper
DEBUG - 2013-04-15 14:49:42 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 14:49:42 --> Helper loaded: text_helper
DEBUG - 2013-04-15 14:49:42 --> Session Class Initialized
DEBUG - 2013-04-15 14:49:42 --> Helper loaded: string_helper
DEBUG - 2013-04-15 14:49:42 --> Session routines successfully run
DEBUG - 2013-04-15 14:49:42 --> Controller Class Initialized
DEBUG - 2013-04-15 14:49:42 --> Language Class Initialized
DEBUG - 2013-04-15 14:49:42 --> Config Class Initialized
DEBUG - 2013-04-15 14:49:42 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 14:49:42 --> Loader Class Initialized
DEBUG - 2013-04-15 14:49:42 --> Model Class Initialized
DEBUG - 2013-04-15 14:49:42 --> Model Class Initialized
DEBUG - 2013-04-15 14:49:42 --> Database Driver Class Initialized
DEBUG - 2013-04-15 15:06:57 --> Config Class Initialized
DEBUG - 2013-04-15 15:06:57 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:06:57 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:06:57 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:06:57 --> URI Class Initialized
DEBUG - 2013-04-15 15:06:57 --> Router Class Initialized
DEBUG - 2013-04-15 15:06:57 --> No URI present. Default controller set.
DEBUG - 2013-04-15 15:06:57 --> Output Class Initialized
DEBUG - 2013-04-15 15:06:57 --> Security Class Initialized
DEBUG - 2013-04-15 15:06:57 --> Input Class Initialized
DEBUG - 2013-04-15 15:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:06:57 --> Language Class Initialized
DEBUG - 2013-04-15 15:06:57 --> Loader Class Initialized
DEBUG - 2013-04-15 15:06:57 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:06:57 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:06:57 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:06:57 --> Session Class Initialized
DEBUG - 2013-04-15 15:06:57 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:06:57 --> Session routines successfully run
DEBUG - 2013-04-15 15:06:57 --> Controller Class Initialized
DEBUG - 2013-04-15 15:06:57 --> Language Class Initialized
DEBUG - 2013-04-15 15:06:57 --> Config Class Initialized
DEBUG - 2013-04-15 15:06:57 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-15 15:06:57 --> Loader Class Initialized
DEBUG - 2013-04-15 15:06:57 --> File loaded: ../application/admin/modules/autenticacao/views/login.php
DEBUG - 2013-04-15 15:06:57 --> Final output sent to browser
DEBUG - 2013-04-15 15:06:57 --> Total execution time: 0.0177
DEBUG - 2013-04-15 15:07:14 --> Config Class Initialized
DEBUG - 2013-04-15 15:07:14 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:07:14 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:07:14 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:07:14 --> URI Class Initialized
DEBUG - 2013-04-15 15:07:14 --> Router Class Initialized
DEBUG - 2013-04-15 15:07:14 --> Output Class Initialized
DEBUG - 2013-04-15 15:07:14 --> Security Class Initialized
DEBUG - 2013-04-15 15:07:14 --> Input Class Initialized
DEBUG - 2013-04-15 15:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:07:14 --> Language Class Initialized
DEBUG - 2013-04-15 15:07:14 --> Loader Class Initialized
DEBUG - 2013-04-15 15:07:14 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:07:14 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:07:14 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:07:14 --> Session Class Initialized
DEBUG - 2013-04-15 15:07:14 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:07:14 --> Session routines successfully run
DEBUG - 2013-04-15 15:07:14 --> Controller Class Initialized
DEBUG - 2013-04-15 15:07:14 --> Language Class Initialized
DEBUG - 2013-04-15 15:07:14 --> Config Class Initialized
DEBUG - 2013-04-15 15:07:14 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-15 15:07:14 --> Loader Class Initialized
DEBUG - 2013-04-15 15:07:14 --> Model Class Initialized
DEBUG - 2013-04-15 15:07:14 --> Model Class Initialized
DEBUG - 2013-04-15 15:07:14 --> Database Driver Class Initialized
DEBUG - 2013-04-15 15:07:15 --> Model Class Initialized
ERROR - 2013-04-15 15:07:15 --> Severity: Notice  --> Undefined index: orlike /home/w3case/public_html/target-git/application/admin/models/crud.php 121
ERROR - 2013-04-15 15:07:15 --> Severity: Notice  --> Undefined index: orlike /home/w3case/public_html/target-git/application/admin/models/crud.php 121
DEBUG - 2013-04-15 15:07:15 --> Final output sent to browser
DEBUG - 2013-04-15 15:07:15 --> Total execution time: 0.7360
DEBUG - 2013-04-15 15:07:15 --> Config Class Initialized
DEBUG - 2013-04-15 15:07:15 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:07:15 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:07:15 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:07:15 --> URI Class Initialized
DEBUG - 2013-04-15 15:07:15 --> Router Class Initialized
DEBUG - 2013-04-15 15:07:15 --> Output Class Initialized
DEBUG - 2013-04-15 15:07:15 --> Security Class Initialized
DEBUG - 2013-04-15 15:07:15 --> Input Class Initialized
DEBUG - 2013-04-15 15:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:07:15 --> Language Class Initialized
DEBUG - 2013-04-15 15:07:15 --> Loader Class Initialized
DEBUG - 2013-04-15 15:07:15 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:07:15 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:07:15 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:07:15 --> Session Class Initialized
DEBUG - 2013-04-15 15:07:15 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:07:15 --> Session routines successfully run
DEBUG - 2013-04-15 15:07:15 --> Controller Class Initialized
DEBUG - 2013-04-15 15:07:15 --> Language Class Initialized
DEBUG - 2013-04-15 15:07:15 --> Config Class Initialized
DEBUG - 2013-04-15 15:07:15 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:07:15 --> Loader Class Initialized
DEBUG - 2013-04-15 15:07:15 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-15 15:07:15 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 15:07:15 --> Final output sent to browser
DEBUG - 2013-04-15 15:07:15 --> Total execution time: 0.0171
DEBUG - 2013-04-15 15:07:23 --> Config Class Initialized
DEBUG - 2013-04-15 15:07:23 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:07:23 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:07:23 --> URI Class Initialized
DEBUG - 2013-04-15 15:07:23 --> Router Class Initialized
DEBUG - 2013-04-15 15:07:23 --> Output Class Initialized
DEBUG - 2013-04-15 15:07:23 --> Security Class Initialized
DEBUG - 2013-04-15 15:07:23 --> Input Class Initialized
DEBUG - 2013-04-15 15:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:07:23 --> Language Class Initialized
DEBUG - 2013-04-15 15:07:23 --> Loader Class Initialized
DEBUG - 2013-04-15 15:07:23 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:07:23 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:07:23 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:07:23 --> Session Class Initialized
DEBUG - 2013-04-15 15:07:23 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:07:23 --> Session routines successfully run
DEBUG - 2013-04-15 15:07:23 --> Controller Class Initialized
DEBUG - 2013-04-15 15:07:23 --> Language Class Initialized
DEBUG - 2013-04-15 15:07:23 --> Config Class Initialized
DEBUG - 2013-04-15 15:07:23 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:07:23 --> Loader Class Initialized
DEBUG - 2013-04-15 15:07:23 --> Model Class Initialized
DEBUG - 2013-04-15 15:07:23 --> Model Class Initialized
DEBUG - 2013-04-15 15:07:23 --> Database Driver Class Initialized
DEBUG - 2013-04-15 15:15:54 --> Config Class Initialized
DEBUG - 2013-04-15 15:15:54 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:15:54 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:15:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:15:54 --> URI Class Initialized
DEBUG - 2013-04-15 15:15:54 --> Router Class Initialized
DEBUG - 2013-04-15 15:15:54 --> Output Class Initialized
DEBUG - 2013-04-15 15:15:54 --> Security Class Initialized
DEBUG - 2013-04-15 15:15:54 --> Input Class Initialized
DEBUG - 2013-04-15 15:15:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:15:54 --> Language Class Initialized
DEBUG - 2013-04-15 15:15:54 --> Loader Class Initialized
DEBUG - 2013-04-15 15:15:54 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:15:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:15:54 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:15:54 --> Session Class Initialized
DEBUG - 2013-04-15 15:15:54 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:15:54 --> Session routines successfully run
DEBUG - 2013-04-15 15:15:54 --> Controller Class Initialized
DEBUG - 2013-04-15 15:15:54 --> Language Class Initialized
DEBUG - 2013-04-15 15:15:54 --> Config Class Initialized
DEBUG - 2013-04-15 15:15:54 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:15:54 --> Loader Class Initialized
DEBUG - 2013-04-15 15:15:54 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-15 15:15:54 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 15:15:54 --> Final output sent to browser
DEBUG - 2013-04-15 15:15:54 --> Total execution time: 0.0180
DEBUG - 2013-04-15 15:15:55 --> Config Class Initialized
DEBUG - 2013-04-15 15:15:55 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:15:55 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:15:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:15:55 --> URI Class Initialized
DEBUG - 2013-04-15 15:15:55 --> Router Class Initialized
DEBUG - 2013-04-15 15:15:55 --> Output Class Initialized
DEBUG - 2013-04-15 15:15:55 --> Security Class Initialized
DEBUG - 2013-04-15 15:15:55 --> Input Class Initialized
DEBUG - 2013-04-15 15:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:15:55 --> Language Class Initialized
DEBUG - 2013-04-15 15:15:55 --> Loader Class Initialized
DEBUG - 2013-04-15 15:15:55 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:15:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:15:55 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:15:55 --> Session Class Initialized
DEBUG - 2013-04-15 15:15:55 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:15:55 --> Session routines successfully run
DEBUG - 2013-04-15 15:15:55 --> Controller Class Initialized
DEBUG - 2013-04-15 15:15:55 --> Language Class Initialized
DEBUG - 2013-04-15 15:15:55 --> Config Class Initialized
DEBUG - 2013-04-15 15:15:55 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:15:55 --> Loader Class Initialized
DEBUG - 2013-04-15 15:15:55 --> Model Class Initialized
DEBUG - 2013-04-15 15:15:55 --> Model Class Initialized
DEBUG - 2013-04-15 15:15:55 --> Database Driver Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Config Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:23:16 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:23:16 --> URI Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Router Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Output Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Security Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Input Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:23:16 --> Language Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Loader Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:23:16 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:23:16 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:23:16 --> Session Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:23:16 --> Session routines successfully run
DEBUG - 2013-04-15 15:23:16 --> Controller Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Language Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Config Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:23:16 --> Loader Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Model Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Model Class Initialized
DEBUG - 2013-04-15 15:23:16 --> Database Driver Class Initialized
DEBUG - 2013-04-15 15:25:27 --> Config Class Initialized
DEBUG - 2013-04-15 15:25:27 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:25:27 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:25:27 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:25:27 --> URI Class Initialized
DEBUG - 2013-04-15 15:25:27 --> Router Class Initialized
DEBUG - 2013-04-15 15:25:27 --> Output Class Initialized
DEBUG - 2013-04-15 15:25:27 --> Security Class Initialized
DEBUG - 2013-04-15 15:25:27 --> Input Class Initialized
DEBUG - 2013-04-15 15:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:25:27 --> Language Class Initialized
DEBUG - 2013-04-15 15:25:27 --> Loader Class Initialized
DEBUG - 2013-04-15 15:25:27 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:25:27 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:25:27 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:25:27 --> Session Class Initialized
DEBUG - 2013-04-15 15:25:27 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:25:27 --> Session routines successfully run
DEBUG - 2013-04-15 15:25:27 --> Controller Class Initialized
DEBUG - 2013-04-15 15:25:27 --> Language Class Initialized
DEBUG - 2013-04-15 15:25:27 --> Config Class Initialized
DEBUG - 2013-04-15 15:25:27 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:25:27 --> Loader Class Initialized
DEBUG - 2013-04-15 15:25:27 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-15 15:25:27 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 15:25:27 --> Final output sent to browser
DEBUG - 2013-04-15 15:25:27 --> Total execution time: 0.0151
DEBUG - 2013-04-15 15:25:29 --> Config Class Initialized
DEBUG - 2013-04-15 15:25:29 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:25:29 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:25:29 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:25:29 --> URI Class Initialized
DEBUG - 2013-04-15 15:25:29 --> Router Class Initialized
DEBUG - 2013-04-15 15:25:29 --> Output Class Initialized
DEBUG - 2013-04-15 15:25:29 --> Security Class Initialized
DEBUG - 2013-04-15 15:25:29 --> Input Class Initialized
DEBUG - 2013-04-15 15:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:25:29 --> Language Class Initialized
DEBUG - 2013-04-15 15:25:29 --> Loader Class Initialized
DEBUG - 2013-04-15 15:25:29 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:25:29 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:25:29 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:25:29 --> Session Class Initialized
DEBUG - 2013-04-15 15:25:29 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:25:29 --> Session routines successfully run
DEBUG - 2013-04-15 15:25:29 --> Controller Class Initialized
DEBUG - 2013-04-15 15:25:29 --> Language Class Initialized
DEBUG - 2013-04-15 15:25:29 --> Config Class Initialized
DEBUG - 2013-04-15 15:25:29 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:25:29 --> Loader Class Initialized
DEBUG - 2013-04-15 15:25:29 --> Model Class Initialized
DEBUG - 2013-04-15 15:25:29 --> Model Class Initialized
DEBUG - 2013-04-15 15:25:29 --> Database Driver Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Config Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:25:30 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:25:30 --> URI Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Router Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Output Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Security Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Input Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:25:30 --> Language Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Loader Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:25:30 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:25:30 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:25:30 --> Session Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:25:30 --> Session routines successfully run
DEBUG - 2013-04-15 15:25:30 --> Controller Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Language Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Config Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:25:30 --> Loader Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Model Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Model Class Initialized
DEBUG - 2013-04-15 15:25:30 --> Database Driver Class Initialized
DEBUG - 2013-04-15 15:26:02 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:02 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:02 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:02 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:02 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:02 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:02 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:02 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:02 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:02 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:02 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:02 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:02 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:02 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:02 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:02 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:02 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:02 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:02 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:02 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:02 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:02 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:02 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-15 15:26:02 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 15:26:02 --> Final output sent to browser
DEBUG - 2013-04-15 15:26:02 --> Total execution time: 0.0168
DEBUG - 2013-04-15 15:26:04 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:04 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:04 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:04 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:04 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:04 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:04 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:04 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:04 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:04 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:26:04 --> Unable to load the requested class: logs
DEBUG - 2013-04-15 15:26:04 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:04 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:04 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:04 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:04 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:04 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:04 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:04 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:04 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:04 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:04 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:26:04 --> Unable to load the requested class: logs
DEBUG - 2013-04-15 15:26:13 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:13 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:13 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:13 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:13 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:13 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:13 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:13 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:13 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:13 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:26:13 --> Unable to load the requested class: logs
DEBUG - 2013-04-15 15:26:13 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:13 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:13 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:13 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:13 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:13 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:13 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:13 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:13 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:13 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:13 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:26:13 --> Unable to load the requested class: logs
DEBUG - 2013-04-15 15:26:14 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:14 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:14 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:14 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:14 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:14 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:14 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:14 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:14 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:14 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:26:14 --> Unable to load the requested class: logs
DEBUG - 2013-04-15 15:26:14 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:14 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:14 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:14 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:14 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:14 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:14 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:14 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:14 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:14 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:14 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:26:14 --> Unable to load the requested class: logs
DEBUG - 2013-04-15 15:26:15 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:15 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:15 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:15 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:15 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:15 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:15 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:15 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:15 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:15 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:15 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:15 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:15 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:15 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:15 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:15 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:15 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:15 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:15 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:15 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:15 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:15 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:15 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-15 15:26:15 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 15:26:15 --> Final output sent to browser
DEBUG - 2013-04-15 15:26:15 --> Total execution time: 0.0182
DEBUG - 2013-04-15 15:26:16 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:16 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:16 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:16 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:16 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:16 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:16 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:16 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:16 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:16 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:16 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:16 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:16 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:16 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:16 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:16 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:16 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:16 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:16 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:16 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:16 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:16 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:16 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:16 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:16 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:26:16 --> Unable to load the requested class: logs
DEBUG - 2013-04-15 15:26:17 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:17 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:17 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:17 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:17 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:17 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:17 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:17 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:26:17 --> Unable to load the requested class: logs
DEBUG - 2013-04-15 15:26:17 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:17 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:17 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:17 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:17 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:17 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:17 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:17 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:26:17 --> Unable to load the requested class: logs
DEBUG - 2013-04-15 15:26:17 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:17 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:17 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:17 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:17 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:17 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:17 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:17 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:17 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:26:17 --> Unable to load the requested class: logs
DEBUG - 2013-04-15 15:26:18 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:18 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:18 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:18 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:18 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:18 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:18 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:18 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:26:18 --> Unable to load the requested class: logs
DEBUG - 2013-04-15 15:26:18 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:18 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:18 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:18 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:18 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:18 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:18 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:18 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:26:18 --> Unable to load the requested class: logs
DEBUG - 2013-04-15 15:26:18 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:18 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:18 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:18 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:18 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:18 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:18 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:18 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:18 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:26:18 --> Unable to load the requested class: logs
DEBUG - 2013-04-15 15:26:34 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:34 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:34 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:34 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:34 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:34 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:34 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:34 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:34 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:34 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:34 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:34 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:34 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:34 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:34 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:34 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:34 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:34 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:34 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:34 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:34 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:34 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:34 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:34 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:26:34 --> Unable to load the requested class: logs
DEBUG - 2013-04-15 15:26:38 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:38 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:26:38 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:26:38 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:26:38 --> URI Class Initialized
DEBUG - 2013-04-15 15:26:38 --> Router Class Initialized
DEBUG - 2013-04-15 15:26:38 --> Output Class Initialized
DEBUG - 2013-04-15 15:26:38 --> Security Class Initialized
DEBUG - 2013-04-15 15:26:39 --> Input Class Initialized
DEBUG - 2013-04-15 15:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:26:39 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:39 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:39 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:26:39 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:26:39 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:26:39 --> Session Class Initialized
DEBUG - 2013-04-15 15:26:39 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:26:39 --> Session routines successfully run
DEBUG - 2013-04-15 15:26:39 --> Controller Class Initialized
DEBUG - 2013-04-15 15:26:39 --> Language Class Initialized
DEBUG - 2013-04-15 15:26:39 --> Config Class Initialized
DEBUG - 2013-04-15 15:26:39 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:26:39 --> Loader Class Initialized
DEBUG - 2013-04-15 15:26:39 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:39 --> Model Class Initialized
DEBUG - 2013-04-15 15:26:39 --> Database Driver Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Config Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:27:33 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:27:33 --> URI Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Router Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Output Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Security Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Input Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:27:33 --> Language Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Loader Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:27:33 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:27:33 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:27:33 --> Session Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:27:33 --> Session routines successfully run
DEBUG - 2013-04-15 15:27:33 --> Controller Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Language Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Config Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:27:33 --> Loader Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Model Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Model Class Initialized
DEBUG - 2013-04-15 15:27:33 --> Database Driver Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Config Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:27:51 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:27:51 --> URI Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Router Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Output Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Security Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Input Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:27:51 --> Language Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Loader Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:27:51 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:27:51 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:27:51 --> Session Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:27:51 --> Session routines successfully run
DEBUG - 2013-04-15 15:27:51 --> Controller Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Language Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Config Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:27:51 --> Loader Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Model Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Model Class Initialized
DEBUG - 2013-04-15 15:27:51 --> Database Driver Class Initialized
DEBUG - 2013-04-15 15:28:24 --> Config Class Initialized
DEBUG - 2013-04-15 15:28:24 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:28:24 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:28:24 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:28:24 --> URI Class Initialized
DEBUG - 2013-04-15 15:28:24 --> Router Class Initialized
DEBUG - 2013-04-15 15:28:24 --> Output Class Initialized
DEBUG - 2013-04-15 15:28:24 --> Security Class Initialized
DEBUG - 2013-04-15 15:28:24 --> Input Class Initialized
DEBUG - 2013-04-15 15:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:28:24 --> Language Class Initialized
DEBUG - 2013-04-15 15:28:24 --> Loader Class Initialized
DEBUG - 2013-04-15 15:28:24 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:28:24 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:28:24 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:28:24 --> Session Class Initialized
DEBUG - 2013-04-15 15:28:24 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:28:24 --> Session routines successfully run
DEBUG - 2013-04-15 15:28:24 --> Controller Class Initialized
DEBUG - 2013-04-15 15:28:24 --> Language Class Initialized
DEBUG - 2013-04-15 15:28:24 --> Config Class Initialized
DEBUG - 2013-04-15 15:28:24 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:28:24 --> Loader Class Initialized
DEBUG - 2013-04-15 15:28:24 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-15 15:28:24 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-15 15:28:24 --> Final output sent to browser
DEBUG - 2013-04-15 15:28:24 --> Total execution time: 0.0196
DEBUG - 2013-04-15 15:29:03 --> Config Class Initialized
DEBUG - 2013-04-15 15:29:03 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:29:03 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:29:03 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:29:03 --> URI Class Initialized
DEBUG - 2013-04-15 15:29:03 --> Router Class Initialized
DEBUG - 2013-04-15 15:29:03 --> Output Class Initialized
DEBUG - 2013-04-15 15:29:03 --> Security Class Initialized
DEBUG - 2013-04-15 15:29:03 --> Input Class Initialized
DEBUG - 2013-04-15 15:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:29:03 --> Language Class Initialized
DEBUG - 2013-04-15 15:29:03 --> Loader Class Initialized
DEBUG - 2013-04-15 15:29:03 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:29:03 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:29:03 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:29:03 --> Session Class Initialized
DEBUG - 2013-04-15 15:29:03 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:29:03 --> Session routines successfully run
DEBUG - 2013-04-15 15:29:03 --> Controller Class Initialized
DEBUG - 2013-04-15 15:29:03 --> Language Class Initialized
DEBUG - 2013-04-15 15:29:03 --> Config Class Initialized
DEBUG - 2013-04-15 15:29:03 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:29:03 --> Loader Class Initialized
DEBUG - 2013-04-15 15:29:03 --> Model Class Initialized
DEBUG - 2013-04-15 15:29:03 --> Model Class Initialized
DEBUG - 2013-04-15 15:29:03 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:29:03 --> Unable to load the requested class: logs
DEBUG - 2013-04-15 15:37:11 --> Config Class Initialized
DEBUG - 2013-04-15 15:37:11 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:37:11 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:37:11 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:37:11 --> URI Class Initialized
DEBUG - 2013-04-15 15:37:11 --> Router Class Initialized
DEBUG - 2013-04-15 15:37:11 --> Output Class Initialized
DEBUG - 2013-04-15 15:37:11 --> Security Class Initialized
DEBUG - 2013-04-15 15:37:11 --> Input Class Initialized
DEBUG - 2013-04-15 15:37:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:37:11 --> Language Class Initialized
DEBUG - 2013-04-15 15:37:11 --> Loader Class Initialized
DEBUG - 2013-04-15 15:37:11 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:37:11 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:37:11 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:37:11 --> Session Class Initialized
DEBUG - 2013-04-15 15:37:11 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:37:11 --> Session routines successfully run
DEBUG - 2013-04-15 15:37:11 --> Controller Class Initialized
DEBUG - 2013-04-15 15:37:11 --> Language Class Initialized
DEBUG - 2013-04-15 15:37:11 --> Config Class Initialized
DEBUG - 2013-04-15 15:37:11 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:37:11 --> Loader Class Initialized
DEBUG - 2013-04-15 15:37:11 --> Model Class Initialized
DEBUG - 2013-04-15 15:37:11 --> Model Class Initialized
DEBUG - 2013-04-15 15:37:11 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:37:11 --> Unable to load the requested class: logs
DEBUG - 2013-04-15 15:38:36 --> Config Class Initialized
DEBUG - 2013-04-15 15:38:36 --> Hooks Class Initialized
DEBUG - 2013-04-15 15:38:36 --> Utf8 Class Initialized
DEBUG - 2013-04-15 15:38:36 --> UTF-8 Support Enabled
DEBUG - 2013-04-15 15:38:36 --> URI Class Initialized
DEBUG - 2013-04-15 15:38:36 --> Router Class Initialized
DEBUG - 2013-04-15 15:38:36 --> Output Class Initialized
DEBUG - 2013-04-15 15:38:36 --> Security Class Initialized
DEBUG - 2013-04-15 15:38:36 --> Input Class Initialized
DEBUG - 2013-04-15 15:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-15 15:38:36 --> Language Class Initialized
DEBUG - 2013-04-15 15:38:36 --> Loader Class Initialized
DEBUG - 2013-04-15 15:38:36 --> Helper loaded: url_helper
DEBUG - 2013-04-15 15:38:36 --> Helper loaded: functions_helper
DEBUG - 2013-04-15 15:38:36 --> Helper loaded: text_helper
DEBUG - 2013-04-15 15:38:36 --> Session Class Initialized
DEBUG - 2013-04-15 15:38:36 --> Helper loaded: string_helper
DEBUG - 2013-04-15 15:38:36 --> Session routines successfully run
DEBUG - 2013-04-15 15:38:36 --> Controller Class Initialized
DEBUG - 2013-04-15 15:38:36 --> Language Class Initialized
DEBUG - 2013-04-15 15:38:36 --> Config Class Initialized
DEBUG - 2013-04-15 15:38:36 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-15 15:38:36 --> Loader Class Initialized
DEBUG - 2013-04-15 15:38:36 --> Model Class Initialized
DEBUG - 2013-04-15 15:38:36 --> Model Class Initialized
DEBUG - 2013-04-15 15:38:36 --> Database Driver Class Initialized
ERROR - 2013-04-15 15:38:36 --> Unable to load the requested class: logs
