<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-04-13 08:39:35 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:35 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:39:35 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:39:35 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:39:35 --> URI Class Initialized
DEBUG - 2013-04-13 08:39:35 --> Router Class Initialized
DEBUG - 2013-04-13 08:39:35 --> No URI present. Default controller set.
DEBUG - 2013-04-13 08:39:35 --> Output Class Initialized
DEBUG - 2013-04-13 08:39:35 --> Security Class Initialized
DEBUG - 2013-04-13 08:39:35 --> Input Class Initialized
DEBUG - 2013-04-13 08:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:39:35 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:35 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:35 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:39:35 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:39:35 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:39:35 --> Session Class Initialized
DEBUG - 2013-04-13 08:39:35 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:39:35 --> A session cookie was not found.
DEBUG - 2013-04-13 08:39:35 --> Session routines successfully run
DEBUG - 2013-04-13 08:39:35 --> Controller Class Initialized
DEBUG - 2013-04-13 08:39:35 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:35 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:35 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-13 08:39:35 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:35 --> File loaded: ../application/admin/modules/autenticacao/views/login.php
DEBUG - 2013-04-13 08:39:35 --> Final output sent to browser
DEBUG - 2013-04-13 08:39:35 --> Total execution time: 0.1246
DEBUG - 2013-04-13 08:39:40 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:40 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:39:40 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:39:40 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:39:40 --> URI Class Initialized
DEBUG - 2013-04-13 08:39:40 --> Router Class Initialized
DEBUG - 2013-04-13 08:39:40 --> Output Class Initialized
DEBUG - 2013-04-13 08:39:40 --> Security Class Initialized
DEBUG - 2013-04-13 08:39:40 --> Input Class Initialized
DEBUG - 2013-04-13 08:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:39:40 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:40 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:40 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:39:40 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:39:40 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:39:40 --> Session Class Initialized
DEBUG - 2013-04-13 08:39:40 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:39:40 --> Session routines successfully run
DEBUG - 2013-04-13 08:39:40 --> Controller Class Initialized
DEBUG - 2013-04-13 08:39:40 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:40 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:40 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-13 08:39:40 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:40 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:40 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:40 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:39:41 --> Model Class Initialized
ERROR - 2013-04-13 08:39:41 --> Severity: Notice  --> Undefined index: orlike /home/w3case/public_html/target-git/application/admin/models/crud.php 121
ERROR - 2013-04-13 08:39:41 --> Severity: Notice  --> Undefined index: orlike /home/w3case/public_html/target-git/application/admin/models/crud.php 121
DEBUG - 2013-04-13 08:39:41 --> Final output sent to browser
DEBUG - 2013-04-13 08:39:41 --> Total execution time: 0.8589
DEBUG - 2013-04-13 08:39:41 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:41 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:39:41 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:39:41 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:39:41 --> URI Class Initialized
DEBUG - 2013-04-13 08:39:41 --> Router Class Initialized
DEBUG - 2013-04-13 08:39:41 --> Output Class Initialized
DEBUG - 2013-04-13 08:39:41 --> Security Class Initialized
DEBUG - 2013-04-13 08:39:41 --> Input Class Initialized
DEBUG - 2013-04-13 08:39:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:39:41 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:41 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:41 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:39:41 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:39:41 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:39:41 --> Session Class Initialized
DEBUG - 2013-04-13 08:39:41 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:39:41 --> Session routines successfully run
DEBUG - 2013-04-13 08:39:41 --> Controller Class Initialized
DEBUG - 2013-04-13 08:39:41 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:41 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:41 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 08:39:41 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:41 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 08:39:41 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:39:41 --> Final output sent to browser
DEBUG - 2013-04-13 08:39:41 --> Total execution time: 0.0302
DEBUG - 2013-04-13 08:39:43 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:43 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:39:43 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:39:43 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:39:43 --> URI Class Initialized
DEBUG - 2013-04-13 08:39:43 --> Router Class Initialized
DEBUG - 2013-04-13 08:39:43 --> Output Class Initialized
DEBUG - 2013-04-13 08:39:43 --> Security Class Initialized
DEBUG - 2013-04-13 08:39:43 --> Input Class Initialized
DEBUG - 2013-04-13 08:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:39:43 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:43 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:43 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:39:43 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:39:43 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:39:43 --> Session Class Initialized
DEBUG - 2013-04-13 08:39:43 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:39:43 --> Session routines successfully run
DEBUG - 2013-04-13 08:39:43 --> Controller Class Initialized
DEBUG - 2013-04-13 08:39:43 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:43 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:43 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-13 08:39:43 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:43 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:43 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:43 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:39:43 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-13 08:39:43 --> File loaded: ../application/admin/modules/usuarios/views/usuarios.php
DEBUG - 2013-04-13 08:39:43 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:39:43 --> Final output sent to browser
DEBUG - 2013-04-13 08:39:43 --> Total execution time: 0.0419
DEBUG - 2013-04-13 08:39:45 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:45 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:39:45 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:39:45 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:39:45 --> URI Class Initialized
DEBUG - 2013-04-13 08:39:45 --> Router Class Initialized
DEBUG - 2013-04-13 08:39:45 --> Output Class Initialized
DEBUG - 2013-04-13 08:39:45 --> Security Class Initialized
DEBUG - 2013-04-13 08:39:45 --> Input Class Initialized
DEBUG - 2013-04-13 08:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:39:45 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:45 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:45 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:39:45 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:39:45 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:39:45 --> Session Class Initialized
DEBUG - 2013-04-13 08:39:45 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:39:45 --> Session routines successfully run
DEBUG - 2013-04-13 08:39:45 --> Controller Class Initialized
DEBUG - 2013-04-13 08:39:45 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:45 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:45 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 08:39:45 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:45 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 08:39:45 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:39:45 --> Final output sent to browser
DEBUG - 2013-04-13 08:39:45 --> Total execution time: 0.0168
DEBUG - 2013-04-13 08:39:46 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:46 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:39:46 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:39:46 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:39:46 --> URI Class Initialized
DEBUG - 2013-04-13 08:39:46 --> Router Class Initialized
DEBUG - 2013-04-13 08:39:46 --> Output Class Initialized
DEBUG - 2013-04-13 08:39:46 --> Security Class Initialized
DEBUG - 2013-04-13 08:39:46 --> Input Class Initialized
DEBUG - 2013-04-13 08:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:39:46 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:46 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:46 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:39:46 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:39:46 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:39:46 --> Session Class Initialized
DEBUG - 2013-04-13 08:39:46 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:39:46 --> Session routines successfully run
DEBUG - 2013-04-13 08:39:46 --> Controller Class Initialized
DEBUG - 2013-04-13 08:39:46 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:46 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:46 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 08:39:46 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:46 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:46 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:46 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:39:46 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-13 08:39:46 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-13 08:39:46 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:39:46 --> Final output sent to browser
DEBUG - 2013-04-13 08:39:46 --> Total execution time: 0.0688
DEBUG - 2013-04-13 08:39:48 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:39:48 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:39:48 --> URI Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Router Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Output Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Security Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Input Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:39:48 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:39:48 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:39:48 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:39:48 --> Session Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:39:48 --> Session routines successfully run
DEBUG - 2013-04-13 08:39:48 --> Controller Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 08:39:48 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:39:48 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:48 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-13 08:39:48 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-13 08:39:48 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:39:48 --> Final output sent to browser
DEBUG - 2013-04-13 08:39:48 --> Total execution time: 0.0355
DEBUG - 2013-04-13 08:39:52 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:39:52 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:39:52 --> URI Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Router Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Output Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Security Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Input Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:39:52 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:39:52 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:39:52 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:39:52 --> Session Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:39:52 --> Session routines successfully run
DEBUG - 2013-04-13 08:39:52 --> Controller Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 08:39:52 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:39:52 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:52 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-13 08:39:52 --> File loaded: ../application/admin/modules/configuracao/views/metas-analytics.php
DEBUG - 2013-04-13 08:39:52 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:39:52 --> Final output sent to browser
DEBUG - 2013-04-13 08:39:52 --> Total execution time: 0.0309
DEBUG - 2013-04-13 08:39:55 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:39:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:39:55 --> URI Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Router Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Output Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Security Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Input Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:39:55 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:39:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:39:55 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:39:55 --> Session Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:39:55 --> Session routines successfully run
DEBUG - 2013-04-13 08:39:55 --> Controller Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 08:39:55 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:55 --> Final output sent to browser
DEBUG - 2013-04-13 08:39:55 --> Total execution time: 0.0244
DEBUG - 2013-04-13 08:39:57 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:39:57 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:39:57 --> URI Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Router Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Output Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Security Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Input Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:39:57 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:39:57 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:39:57 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:39:57 --> Session Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:39:57 --> Session routines successfully run
DEBUG - 2013-04-13 08:39:57 --> Controller Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 08:39:57 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:39:57 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:57 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-13 08:39:57 --> File loaded: ../application/admin/modules/configuracao/views/tempo.php
DEBUG - 2013-04-13 08:39:57 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:39:57 --> Final output sent to browser
DEBUG - 2013-04-13 08:39:57 --> Total execution time: 0.0268
DEBUG - 2013-04-13 08:39:58 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:39:58 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:39:58 --> URI Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Router Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Output Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Security Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Input Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:39:58 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:39:58 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:39:58 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:39:58 --> Session Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:39:58 --> Session routines successfully run
DEBUG - 2013-04-13 08:39:58 --> Controller Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Language Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Config Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 08:39:58 --> Loader Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Model Class Initialized
DEBUG - 2013-04-13 08:39:58 --> Final output sent to browser
DEBUG - 2013-04-13 08:39:58 --> Total execution time: 0.0219
DEBUG - 2013-04-13 08:40:04 --> Config Class Initialized
DEBUG - 2013-04-13 08:40:04 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:40:04 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:40:04 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:40:04 --> URI Class Initialized
DEBUG - 2013-04-13 08:40:04 --> Router Class Initialized
DEBUG - 2013-04-13 08:40:04 --> Output Class Initialized
DEBUG - 2013-04-13 08:40:04 --> Security Class Initialized
DEBUG - 2013-04-13 08:40:04 --> Input Class Initialized
DEBUG - 2013-04-13 08:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:40:04 --> Language Class Initialized
DEBUG - 2013-04-13 08:40:04 --> Loader Class Initialized
DEBUG - 2013-04-13 08:40:04 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:40:04 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:40:04 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:40:04 --> Session Class Initialized
DEBUG - 2013-04-13 08:40:04 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:40:04 --> Session routines successfully run
DEBUG - 2013-04-13 08:40:04 --> Controller Class Initialized
DEBUG - 2013-04-13 08:40:04 --> Language Class Initialized
DEBUG - 2013-04-13 08:40:04 --> Config Class Initialized
DEBUG - 2013-04-13 08:40:04 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 08:40:04 --> Loader Class Initialized
DEBUG - 2013-04-13 08:40:04 --> Model Class Initialized
DEBUG - 2013-04-13 08:40:04 --> Model Class Initialized
DEBUG - 2013-04-13 08:40:04 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:40:04 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-13 08:40:04 --> File loaded: ../application/admin/modules/configuracao/views/manutencao.php
DEBUG - 2013-04-13 08:40:04 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:40:04 --> Final output sent to browser
DEBUG - 2013-04-13 08:40:04 --> Total execution time: 0.0425
DEBUG - 2013-04-13 08:40:07 --> Config Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:40:07 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:40:07 --> URI Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Router Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Output Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Security Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Input Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:40:07 --> Language Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Loader Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:40:07 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:40:07 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:40:07 --> Session Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:40:07 --> Session routines successfully run
DEBUG - 2013-04-13 08:40:07 --> Controller Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Language Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Config Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 08:40:07 --> Loader Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Model Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Model Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Model Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Model Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Database Forge Class Initialized
DEBUG - 2013-04-13 08:40:07 --> Database Utility Class Initialized
DEBUG - 2013-04-13 08:40:29 --> Helper loaded: file_helper
ERROR - 2013-04-13 08:40:29 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-13 08:40:29 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-13 08:40:29 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-13 08:40:29 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-13 08:40:29 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-13 08:40:29 --> Severity: Warning  --> Missing argument 2 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 212 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-13 08:40:29 --> Severity: Warning  --> Missing argument 3 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 212 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-13 08:40:29 --> Severity: Notice  --> Undefined variable: id_name /home/w3case/public_html/target-git/application/admin/models/crud.php 272
DEBUG - 2013-04-13 08:40:29 --> Final output sent to browser
DEBUG - 2013-04-13 08:40:29 --> Total execution time: 22.5525
DEBUG - 2013-04-13 08:47:22 --> Config Class Initialized
DEBUG - 2013-04-13 08:47:22 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:47:22 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:47:22 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:47:22 --> URI Class Initialized
DEBUG - 2013-04-13 08:47:22 --> Router Class Initialized
DEBUG - 2013-04-13 08:47:22 --> Output Class Initialized
DEBUG - 2013-04-13 08:47:22 --> Security Class Initialized
DEBUG - 2013-04-13 08:47:22 --> Input Class Initialized
DEBUG - 2013-04-13 08:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:47:22 --> Language Class Initialized
DEBUG - 2013-04-13 08:47:22 --> Loader Class Initialized
DEBUG - 2013-04-13 08:47:22 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:47:22 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:47:22 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:47:22 --> Session Class Initialized
DEBUG - 2013-04-13 08:47:22 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:47:22 --> Session routines successfully run
DEBUG - 2013-04-13 08:47:22 --> Controller Class Initialized
DEBUG - 2013-04-13 08:47:22 --> Language Class Initialized
DEBUG - 2013-04-13 08:47:22 --> Config Class Initialized
DEBUG - 2013-04-13 08:47:22 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 08:47:22 --> Loader Class Initialized
DEBUG - 2013-04-13 08:47:22 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 08:47:22 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:47:22 --> Final output sent to browser
DEBUG - 2013-04-13 08:47:22 --> Total execution time: 0.0231
DEBUG - 2013-04-13 08:48:35 --> Config Class Initialized
DEBUG - 2013-04-13 08:48:35 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:48:35 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:48:35 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:48:35 --> URI Class Initialized
DEBUG - 2013-04-13 08:48:35 --> Router Class Initialized
DEBUG - 2013-04-13 08:48:35 --> Output Class Initialized
DEBUG - 2013-04-13 08:48:35 --> Security Class Initialized
DEBUG - 2013-04-13 08:48:35 --> Input Class Initialized
DEBUG - 2013-04-13 08:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:48:35 --> Language Class Initialized
DEBUG - 2013-04-13 08:48:35 --> Loader Class Initialized
DEBUG - 2013-04-13 08:48:35 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:48:35 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:48:35 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:48:35 --> Session Class Initialized
DEBUG - 2013-04-13 08:48:35 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:48:35 --> Session routines successfully run
DEBUG - 2013-04-13 08:48:35 --> Controller Class Initialized
DEBUG - 2013-04-13 08:48:35 --> Language Class Initialized
DEBUG - 2013-04-13 08:48:35 --> Config Class Initialized
DEBUG - 2013-04-13 08:48:35 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 08:48:35 --> Loader Class Initialized
DEBUG - 2013-04-13 08:48:35 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 08:48:35 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:48:35 --> Final output sent to browser
DEBUG - 2013-04-13 08:48:35 --> Total execution time: 0.0245
DEBUG - 2013-04-13 08:48:39 --> Config Class Initialized
DEBUG - 2013-04-13 08:48:39 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:48:39 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:48:39 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:48:39 --> URI Class Initialized
DEBUG - 2013-04-13 08:48:39 --> Router Class Initialized
DEBUG - 2013-04-13 08:48:39 --> Output Class Initialized
DEBUG - 2013-04-13 08:48:39 --> Security Class Initialized
DEBUG - 2013-04-13 08:48:39 --> Input Class Initialized
DEBUG - 2013-04-13 08:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:48:39 --> Language Class Initialized
DEBUG - 2013-04-13 08:48:39 --> Loader Class Initialized
DEBUG - 2013-04-13 08:48:39 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:48:39 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:48:39 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:48:39 --> Session Class Initialized
DEBUG - 2013-04-13 08:48:39 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:48:39 --> Session routines successfully run
DEBUG - 2013-04-13 08:48:39 --> Controller Class Initialized
DEBUG - 2013-04-13 08:48:39 --> Language Class Initialized
DEBUG - 2013-04-13 08:48:39 --> Config Class Initialized
DEBUG - 2013-04-13 08:48:39 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-13 08:48:39 --> Loader Class Initialized
DEBUG - 2013-04-13 08:48:39 --> Model Class Initialized
DEBUG - 2013-04-13 08:48:39 --> Model Class Initialized
DEBUG - 2013-04-13 08:48:39 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:48:39 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-13 08:48:39 --> File loaded: ../application/admin/modules/usuarios/views/usuarios.php
DEBUG - 2013-04-13 08:48:39 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:48:39 --> Final output sent to browser
DEBUG - 2013-04-13 08:48:39 --> Total execution time: 0.0282
DEBUG - 2013-04-13 08:49:50 --> Config Class Initialized
DEBUG - 2013-04-13 08:49:50 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:49:50 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:49:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:49:50 --> URI Class Initialized
DEBUG - 2013-04-13 08:49:50 --> Router Class Initialized
DEBUG - 2013-04-13 08:49:50 --> Output Class Initialized
DEBUG - 2013-04-13 08:49:50 --> Security Class Initialized
DEBUG - 2013-04-13 08:49:50 --> Input Class Initialized
DEBUG - 2013-04-13 08:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:49:50 --> Language Class Initialized
DEBUG - 2013-04-13 08:49:50 --> Loader Class Initialized
DEBUG - 2013-04-13 08:49:50 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:49:50 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:49:50 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:49:50 --> Session Class Initialized
DEBUG - 2013-04-13 08:49:50 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:49:50 --> Session routines successfully run
DEBUG - 2013-04-13 08:49:50 --> Controller Class Initialized
DEBUG - 2013-04-13 08:49:50 --> Language Class Initialized
DEBUG - 2013-04-13 08:49:50 --> Config Class Initialized
DEBUG - 2013-04-13 08:49:50 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 08:49:50 --> Loader Class Initialized
DEBUG - 2013-04-13 08:49:50 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 08:49:50 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:49:50 --> Final output sent to browser
DEBUG - 2013-04-13 08:49:50 --> Total execution time: 0.0226
DEBUG - 2013-04-13 08:49:52 --> Config Class Initialized
DEBUG - 2013-04-13 08:49:52 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:49:52 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:49:52 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:49:52 --> URI Class Initialized
DEBUG - 2013-04-13 08:49:52 --> Router Class Initialized
DEBUG - 2013-04-13 08:49:52 --> Output Class Initialized
DEBUG - 2013-04-13 08:49:52 --> Security Class Initialized
DEBUG - 2013-04-13 08:49:52 --> Input Class Initialized
DEBUG - 2013-04-13 08:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:49:52 --> Language Class Initialized
DEBUG - 2013-04-13 08:49:52 --> Loader Class Initialized
DEBUG - 2013-04-13 08:49:52 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:49:52 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:49:52 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:49:52 --> Session Class Initialized
DEBUG - 2013-04-13 08:49:52 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:49:52 --> Session routines successfully run
DEBUG - 2013-04-13 08:49:52 --> Controller Class Initialized
DEBUG - 2013-04-13 08:49:52 --> Language Class Initialized
DEBUG - 2013-04-13 08:49:52 --> Config Class Initialized
DEBUG - 2013-04-13 08:49:52 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 08:49:52 --> Loader Class Initialized
DEBUG - 2013-04-13 08:49:52 --> Model Class Initialized
DEBUG - 2013-04-13 08:49:52 --> Model Class Initialized
DEBUG - 2013-04-13 08:49:52 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:49:52 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-13 08:49:52 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-13 08:49:52 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:49:52 --> Final output sent to browser
DEBUG - 2013-04-13 08:49:52 --> Total execution time: 0.0261
DEBUG - 2013-04-13 08:49:54 --> Config Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:49:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:49:54 --> URI Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Router Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Output Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Security Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Input Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:49:54 --> Language Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Loader Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:49:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:49:54 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:49:54 --> Session Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:49:54 --> Session routines successfully run
DEBUG - 2013-04-13 08:49:54 --> Controller Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Language Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Config Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 08:49:54 --> Loader Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Model Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Model Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:49:54 --> Model Class Initialized
DEBUG - 2013-04-13 08:49:54 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-13 08:49:54 --> File loaded: ../application/admin/modules/configuracao/views/tempo.php
DEBUG - 2013-04-13 08:49:54 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:49:54 --> Final output sent to browser
DEBUG - 2013-04-13 08:49:54 --> Total execution time: 0.0265
DEBUG - 2013-04-13 08:49:56 --> Config Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:49:56 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:49:56 --> URI Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Router Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Output Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Security Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Input Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:49:56 --> Language Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Loader Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:49:56 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:49:56 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:49:56 --> Session Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:49:56 --> Session routines successfully run
DEBUG - 2013-04-13 08:49:56 --> Controller Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Language Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Config Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 08:49:56 --> Loader Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Model Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Model Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Model Class Initialized
DEBUG - 2013-04-13 08:49:56 --> Final output sent to browser
DEBUG - 2013-04-13 08:49:56 --> Total execution time: 0.0232
DEBUG - 2013-04-13 08:49:58 --> Config Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:49:58 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:49:58 --> URI Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Router Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Output Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Security Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Input Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:49:58 --> Language Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Loader Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:49:58 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:49:58 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:49:58 --> Session Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:49:58 --> Session routines successfully run
DEBUG - 2013-04-13 08:49:58 --> Controller Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Language Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Config Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 08:49:58 --> Loader Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Model Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Model Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:49:58 --> Model Class Initialized
DEBUG - 2013-04-13 08:49:58 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-13 08:49:58 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-13 08:49:58 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:49:58 --> Final output sent to browser
DEBUG - 2013-04-13 08:49:58 --> Total execution time: 0.0381
DEBUG - 2013-04-13 08:49:59 --> Config Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:49:59 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:49:59 --> URI Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Router Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Output Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Security Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Input Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:49:59 --> Language Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Loader Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:49:59 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:49:59 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:49:59 --> Session Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:49:59 --> Session routines successfully run
DEBUG - 2013-04-13 08:49:59 --> Controller Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Language Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Config Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 08:49:59 --> Loader Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Model Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Model Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Model Class Initialized
DEBUG - 2013-04-13 08:49:59 --> Final output sent to browser
DEBUG - 2013-04-13 08:49:59 --> Total execution time: 0.0269
DEBUG - 2013-04-13 08:50:03 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:03 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:50:03 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:50:03 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:50:03 --> URI Class Initialized
DEBUG - 2013-04-13 08:50:03 --> Router Class Initialized
DEBUG - 2013-04-13 08:50:03 --> Output Class Initialized
DEBUG - 2013-04-13 08:50:03 --> Security Class Initialized
DEBUG - 2013-04-13 08:50:03 --> Input Class Initialized
DEBUG - 2013-04-13 08:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:50:03 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:03 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:03 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:50:03 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:50:03 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:50:03 --> Session Class Initialized
DEBUG - 2013-04-13 08:50:03 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:50:03 --> Session routines successfully run
DEBUG - 2013-04-13 08:50:03 --> Controller Class Initialized
DEBUG - 2013-04-13 08:50:03 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:03 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:03 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 08:50:03 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:03 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:03 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:03 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:50:03 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-13 08:50:03 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-13 08:50:03 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:50:03 --> Final output sent to browser
DEBUG - 2013-04-13 08:50:03 --> Total execution time: 0.0256
DEBUG - 2013-04-13 08:50:05 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:05 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:50:05 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:50:05 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:50:05 --> URI Class Initialized
DEBUG - 2013-04-13 08:50:05 --> Router Class Initialized
DEBUG - 2013-04-13 08:50:05 --> Output Class Initialized
DEBUG - 2013-04-13 08:50:05 --> Security Class Initialized
DEBUG - 2013-04-13 08:50:05 --> Input Class Initialized
DEBUG - 2013-04-13 08:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:50:05 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:05 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:05 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:50:05 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:50:05 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:50:05 --> Session Class Initialized
DEBUG - 2013-04-13 08:50:05 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:50:05 --> Session routines successfully run
DEBUG - 2013-04-13 08:50:05 --> Controller Class Initialized
DEBUG - 2013-04-13 08:50:05 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:05 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:05 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-13 08:50:05 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:05 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:05 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:05 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:50:05 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-13 08:50:05 --> File loaded: ../application/admin/modules/usuarios/views/usuarios.php
DEBUG - 2013-04-13 08:50:05 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:50:05 --> Final output sent to browser
DEBUG - 2013-04-13 08:50:05 --> Total execution time: 0.0275
DEBUG - 2013-04-13 08:50:07 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:50:07 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:50:07 --> URI Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Router Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Output Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Security Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Input Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:50:07 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:50:07 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:50:07 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:50:07 --> Session Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:50:07 --> Session routines successfully run
DEBUG - 2013-04-13 08:50:07 --> Controller Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-13 08:50:07 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Database Driver Class Initialized
ERROR - 2013-04-13 08:50:07 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-13 08:50:07 --> Pagination Class Initialized
DEBUG - 2013-04-13 08:50:07 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:07 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-13 08:50:07 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-13 08:50:07 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:50:07 --> Final output sent to browser
DEBUG - 2013-04-13 08:50:07 --> Total execution time: 0.0519
DEBUG - 2013-04-13 08:50:09 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:50:09 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:50:09 --> URI Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Router Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Output Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Security Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Input Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:50:09 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:50:09 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:50:09 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:50:09 --> Session Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:50:09 --> Session routines successfully run
DEBUG - 2013-04-13 08:50:09 --> Controller Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-13 08:50:09 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Final output sent to browser
DEBUG - 2013-04-13 08:50:09 --> Total execution time: 0.0267
DEBUG - 2013-04-13 08:50:09 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:50:09 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:50:09 --> URI Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Router Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Output Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Security Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Input Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:50:09 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:50:09 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:50:09 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:50:09 --> Session Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:50:09 --> Session routines successfully run
DEBUG - 2013-04-13 08:50:09 --> Controller Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-13 08:50:09 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Database Driver Class Initialized
ERROR - 2013-04-13 08:50:09 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-13 08:50:09 --> Pagination Class Initialized
DEBUG - 2013-04-13 08:50:09 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:09 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-13 08:50:09 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-13 08:50:09 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:50:09 --> Final output sent to browser
DEBUG - 2013-04-13 08:50:09 --> Total execution time: 0.0307
DEBUG - 2013-04-13 08:50:14 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:14 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:50:14 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:50:14 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:50:14 --> URI Class Initialized
DEBUG - 2013-04-13 08:50:14 --> Router Class Initialized
DEBUG - 2013-04-13 08:50:14 --> Output Class Initialized
DEBUG - 2013-04-13 08:50:14 --> Security Class Initialized
DEBUG - 2013-04-13 08:50:14 --> Input Class Initialized
DEBUG - 2013-04-13 08:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:50:14 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:14 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:14 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:50:14 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:50:14 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:50:14 --> Session Class Initialized
DEBUG - 2013-04-13 08:50:14 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:50:14 --> Session routines successfully run
DEBUG - 2013-04-13 08:50:14 --> Controller Class Initialized
DEBUG - 2013-04-13 08:50:14 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:14 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:14 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-13 08:50:14 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:14 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:14 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:14 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:50:14 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-13 08:50:14 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-13 08:50:14 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:50:14 --> Final output sent to browser
DEBUG - 2013-04-13 08:50:14 --> Total execution time: 0.0346
DEBUG - 2013-04-13 08:50:34 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:34 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:50:34 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:50:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:50:34 --> URI Class Initialized
DEBUG - 2013-04-13 08:50:34 --> Router Class Initialized
DEBUG - 2013-04-13 08:50:34 --> Output Class Initialized
DEBUG - 2013-04-13 08:50:34 --> Security Class Initialized
DEBUG - 2013-04-13 08:50:34 --> Input Class Initialized
DEBUG - 2013-04-13 08:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:50:34 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:34 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:34 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:50:34 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:50:34 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:50:34 --> Session Class Initialized
DEBUG - 2013-04-13 08:50:34 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:50:34 --> Session routines successfully run
DEBUG - 2013-04-13 08:50:34 --> Controller Class Initialized
DEBUG - 2013-04-13 08:50:34 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:34 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:34 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 08:50:34 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:34 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:34 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:34 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:50:34 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-13 08:50:34 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-13 08:50:34 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:50:34 --> Final output sent to browser
DEBUG - 2013-04-13 08:50:34 --> Total execution time: 0.0302
DEBUG - 2013-04-13 08:50:35 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:35 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:50:35 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:50:35 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:50:35 --> URI Class Initialized
DEBUG - 2013-04-13 08:50:35 --> Router Class Initialized
DEBUG - 2013-04-13 08:50:35 --> Output Class Initialized
DEBUG - 2013-04-13 08:50:35 --> Security Class Initialized
DEBUG - 2013-04-13 08:50:35 --> Input Class Initialized
DEBUG - 2013-04-13 08:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:50:35 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:35 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:35 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:50:35 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:50:35 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:50:35 --> Session Class Initialized
DEBUG - 2013-04-13 08:50:35 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:50:35 --> Session routines successfully run
DEBUG - 2013-04-13 08:50:35 --> Controller Class Initialized
DEBUG - 2013-04-13 08:50:35 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:35 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:35 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-13 08:50:35 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:35 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:35 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:35 --> Database Driver Class Initialized
DEBUG - 2013-04-13 08:50:35 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-13 08:50:35 --> File loaded: ../application/admin/modules/usuarios/views/usuarios.php
DEBUG - 2013-04-13 08:50:35 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:50:35 --> Final output sent to browser
DEBUG - 2013-04-13 08:50:35 --> Total execution time: 0.0259
DEBUG - 2013-04-13 08:50:37 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:50:37 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:50:37 --> URI Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Router Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Output Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Security Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Input Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:50:37 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:50:37 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:50:37 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:50:37 --> Session Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:50:37 --> Session routines successfully run
DEBUG - 2013-04-13 08:50:37 --> Controller Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-13 08:50:37 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Database Driver Class Initialized
ERROR - 2013-04-13 08:50:37 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-13 08:50:37 --> Pagination Class Initialized
DEBUG - 2013-04-13 08:50:37 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:37 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-13 08:50:37 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-13 08:50:37 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:50:37 --> Final output sent to browser
DEBUG - 2013-04-13 08:50:37 --> Total execution time: 0.0320
DEBUG - 2013-04-13 08:50:40 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:50:40 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:50:40 --> URI Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Router Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Output Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Security Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Input Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:50:40 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:50:40 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:50:40 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:50:40 --> Session Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:50:40 --> Session routines successfully run
DEBUG - 2013-04-13 08:50:40 --> Controller Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-13 08:50:40 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Database Driver Class Initialized
ERROR - 2013-04-13 08:50:40 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-13 08:50:40 --> Pagination Class Initialized
DEBUG - 2013-04-13 08:50:40 --> Model Class Initialized
DEBUG - 2013-04-13 08:50:40 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-13 08:50:40 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-13 08:50:40 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:50:40 --> Final output sent to browser
DEBUG - 2013-04-13 08:50:40 --> Total execution time: 0.0315
DEBUG - 2013-04-13 08:50:44 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:44 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:50:44 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:50:44 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:50:44 --> URI Class Initialized
DEBUG - 2013-04-13 08:50:44 --> Router Class Initialized
DEBUG - 2013-04-13 08:50:44 --> Output Class Initialized
DEBUG - 2013-04-13 08:50:44 --> Security Class Initialized
DEBUG - 2013-04-13 08:50:44 --> Input Class Initialized
DEBUG - 2013-04-13 08:50:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:50:44 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:44 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:44 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:50:44 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:50:44 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:50:44 --> Session Class Initialized
DEBUG - 2013-04-13 08:50:44 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:50:44 --> Session routines successfully run
DEBUG - 2013-04-13 08:50:44 --> Controller Class Initialized
DEBUG - 2013-04-13 08:50:44 --> Language Class Initialized
DEBUG - 2013-04-13 08:50:44 --> Config Class Initialized
DEBUG - 2013-04-13 08:50:44 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 08:50:44 --> Loader Class Initialized
DEBUG - 2013-04-13 08:50:44 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 08:50:44 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:50:44 --> Final output sent to browser
DEBUG - 2013-04-13 08:50:44 --> Total execution time: 0.0176
DEBUG - 2013-04-13 08:52:17 --> Config Class Initialized
DEBUG - 2013-04-13 08:52:17 --> Hooks Class Initialized
DEBUG - 2013-04-13 08:52:17 --> Utf8 Class Initialized
DEBUG - 2013-04-13 08:52:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 08:52:17 --> URI Class Initialized
DEBUG - 2013-04-13 08:52:17 --> Router Class Initialized
DEBUG - 2013-04-13 08:52:17 --> Output Class Initialized
DEBUG - 2013-04-13 08:52:17 --> Security Class Initialized
DEBUG - 2013-04-13 08:52:17 --> Input Class Initialized
DEBUG - 2013-04-13 08:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 08:52:17 --> Language Class Initialized
DEBUG - 2013-04-13 08:52:17 --> Loader Class Initialized
DEBUG - 2013-04-13 08:52:17 --> Helper loaded: url_helper
DEBUG - 2013-04-13 08:52:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 08:52:17 --> Helper loaded: text_helper
DEBUG - 2013-04-13 08:52:17 --> Session Class Initialized
DEBUG - 2013-04-13 08:52:17 --> Helper loaded: string_helper
DEBUG - 2013-04-13 08:52:17 --> Session routines successfully run
DEBUG - 2013-04-13 08:52:17 --> Controller Class Initialized
DEBUG - 2013-04-13 08:52:17 --> Language Class Initialized
DEBUG - 2013-04-13 08:52:17 --> Config Class Initialized
DEBUG - 2013-04-13 08:52:17 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 08:52:17 --> Loader Class Initialized
DEBUG - 2013-04-13 08:52:17 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 08:52:17 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 08:52:17 --> Final output sent to browser
DEBUG - 2013-04-13 08:52:17 --> Total execution time: 0.0212
DEBUG - 2013-04-13 09:20:37 --> Config Class Initialized
DEBUG - 2013-04-13 09:20:37 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:20:37 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:20:37 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:20:37 --> URI Class Initialized
DEBUG - 2013-04-13 09:20:37 --> Router Class Initialized
DEBUG - 2013-04-13 09:20:37 --> Output Class Initialized
DEBUG - 2013-04-13 09:20:37 --> Security Class Initialized
DEBUG - 2013-04-13 09:20:37 --> Input Class Initialized
DEBUG - 2013-04-13 09:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:20:37 --> Language Class Initialized
DEBUG - 2013-04-13 09:20:37 --> Loader Class Initialized
DEBUG - 2013-04-13 09:20:37 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:20:37 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:20:37 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:20:37 --> Session Class Initialized
DEBUG - 2013-04-13 09:20:37 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:20:37 --> Session routines successfully run
DEBUG - 2013-04-13 09:20:37 --> Controller Class Initialized
DEBUG - 2013-04-13 09:20:37 --> Language Class Initialized
DEBUG - 2013-04-13 09:20:37 --> Config Class Initialized
DEBUG - 2013-04-13 09:20:37 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:20:37 --> Loader Class Initialized
DEBUG - 2013-04-13 09:20:37 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 09:20:37 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 09:20:37 --> Final output sent to browser
DEBUG - 2013-04-13 09:20:37 --> Total execution time: 0.0153
DEBUG - 2013-04-13 09:20:38 --> Config Class Initialized
DEBUG - 2013-04-13 09:20:38 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:20:38 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:20:38 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:20:38 --> URI Class Initialized
DEBUG - 2013-04-13 09:20:38 --> Router Class Initialized
DEBUG - 2013-04-13 09:20:38 --> Output Class Initialized
DEBUG - 2013-04-13 09:20:38 --> Security Class Initialized
DEBUG - 2013-04-13 09:20:38 --> Input Class Initialized
DEBUG - 2013-04-13 09:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:20:38 --> Language Class Initialized
DEBUG - 2013-04-13 09:20:38 --> Loader Class Initialized
DEBUG - 2013-04-13 09:20:38 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:20:38 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:20:38 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:20:38 --> Session Class Initialized
DEBUG - 2013-04-13 09:20:38 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:20:38 --> Session routines successfully run
DEBUG - 2013-04-13 09:20:38 --> Controller Class Initialized
DEBUG - 2013-04-13 09:20:38 --> Language Class Initialized
DEBUG - 2013-04-13 09:20:38 --> Config Class Initialized
DEBUG - 2013-04-13 09:20:38 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 09:20:38 --> Loader Class Initialized
DEBUG - 2013-04-13 09:20:38 --> Model Class Initialized
DEBUG - 2013-04-13 09:20:38 --> Model Class Initialized
DEBUG - 2013-04-13 09:20:38 --> Database Driver Class Initialized
DEBUG - 2013-04-13 09:20:38 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-13 09:20:38 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-13 09:20:38 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 09:20:38 --> Final output sent to browser
DEBUG - 2013-04-13 09:20:38 --> Total execution time: 0.0238
DEBUG - 2013-04-13 09:20:39 --> Config Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:20:39 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:20:39 --> URI Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Router Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Output Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Security Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Input Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:20:39 --> Language Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Loader Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:20:39 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:20:39 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:20:39 --> Session Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:20:39 --> Session routines successfully run
DEBUG - 2013-04-13 09:20:39 --> Controller Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Language Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Config Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 09:20:39 --> Loader Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Model Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Model Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Database Driver Class Initialized
DEBUG - 2013-04-13 09:20:39 --> Model Class Initialized
DEBUG - 2013-04-13 09:20:39 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-13 09:20:39 --> File loaded: ../application/admin/modules/configuracao/views/metas-analytics.php
DEBUG - 2013-04-13 09:20:39 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 09:20:39 --> Final output sent to browser
DEBUG - 2013-04-13 09:20:39 --> Total execution time: 0.0270
DEBUG - 2013-04-13 09:20:41 --> Config Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:20:41 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:20:41 --> URI Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Router Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Output Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Security Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Input Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:20:41 --> Language Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Loader Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:20:41 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:20:41 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:20:41 --> Session Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:20:41 --> Session routines successfully run
DEBUG - 2013-04-13 09:20:41 --> Controller Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Language Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Config Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 09:20:41 --> Loader Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Model Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Model Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Database Driver Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Model Class Initialized
DEBUG - 2013-04-13 09:20:41 --> Final output sent to browser
DEBUG - 2013-04-13 09:20:41 --> Total execution time: 0.0249
DEBUG - 2013-04-13 09:20:43 --> Config Class Initialized
DEBUG - 2013-04-13 09:20:43 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:20:43 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:20:43 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:20:43 --> URI Class Initialized
DEBUG - 2013-04-13 09:20:43 --> Router Class Initialized
DEBUG - 2013-04-13 09:20:43 --> Output Class Initialized
DEBUG - 2013-04-13 09:20:43 --> Security Class Initialized
DEBUG - 2013-04-13 09:20:43 --> Input Class Initialized
DEBUG - 2013-04-13 09:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:20:43 --> Language Class Initialized
DEBUG - 2013-04-13 09:20:43 --> Loader Class Initialized
DEBUG - 2013-04-13 09:20:43 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:20:43 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:20:43 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:20:43 --> Session Class Initialized
DEBUG - 2013-04-13 09:20:43 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:20:43 --> Session routines successfully run
DEBUG - 2013-04-13 09:20:43 --> Controller Class Initialized
DEBUG - 2013-04-13 09:20:43 --> Language Class Initialized
DEBUG - 2013-04-13 09:20:43 --> Config Class Initialized
DEBUG - 2013-04-13 09:20:43 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-13 09:20:43 --> Loader Class Initialized
DEBUG - 2013-04-13 09:20:43 --> Model Class Initialized
DEBUG - 2013-04-13 09:20:43 --> Model Class Initialized
DEBUG - 2013-04-13 09:20:43 --> Database Driver Class Initialized
DEBUG - 2013-04-13 09:20:43 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-13 09:20:43 --> File loaded: ../application/admin/modules/usuarios/views/usuarios.php
DEBUG - 2013-04-13 09:20:43 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 09:20:43 --> Final output sent to browser
DEBUG - 2013-04-13 09:20:43 --> Total execution time: 0.0268
DEBUG - 2013-04-13 09:20:44 --> Config Class Initialized
DEBUG - 2013-04-13 09:20:44 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:20:44 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:20:44 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:20:44 --> URI Class Initialized
DEBUG - 2013-04-13 09:20:44 --> Router Class Initialized
DEBUG - 2013-04-13 09:20:44 --> Output Class Initialized
DEBUG - 2013-04-13 09:20:44 --> Security Class Initialized
DEBUG - 2013-04-13 09:20:44 --> Input Class Initialized
DEBUG - 2013-04-13 09:20:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:20:44 --> Language Class Initialized
DEBUG - 2013-04-13 09:20:44 --> Loader Class Initialized
DEBUG - 2013-04-13 09:20:44 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:20:44 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:20:44 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:20:44 --> Session Class Initialized
DEBUG - 2013-04-13 09:20:45 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:20:45 --> Session routines successfully run
DEBUG - 2013-04-13 09:20:45 --> Controller Class Initialized
DEBUG - 2013-04-13 09:20:45 --> Language Class Initialized
DEBUG - 2013-04-13 09:20:45 --> Config Class Initialized
DEBUG - 2013-04-13 09:20:45 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-13 09:20:45 --> Loader Class Initialized
DEBUG - 2013-04-13 09:20:45 --> Model Class Initialized
DEBUG - 2013-04-13 09:20:45 --> Model Class Initialized
DEBUG - 2013-04-13 09:20:45 --> Database Driver Class Initialized
ERROR - 2013-04-13 09:20:45 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-13 09:20:45 --> Pagination Class Initialized
DEBUG - 2013-04-13 09:20:45 --> Model Class Initialized
DEBUG - 2013-04-13 09:20:45 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-13 09:20:45 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-13 09:20:45 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 09:20:45 --> Final output sent to browser
DEBUG - 2013-04-13 09:20:45 --> Total execution time: 0.0279
DEBUG - 2013-04-13 09:40:02 --> Config Class Initialized
DEBUG - 2013-04-13 09:40:02 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:40:02 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:40:02 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:40:02 --> URI Class Initialized
DEBUG - 2013-04-13 09:40:02 --> Router Class Initialized
DEBUG - 2013-04-13 09:40:02 --> Output Class Initialized
DEBUG - 2013-04-13 09:40:02 --> Security Class Initialized
DEBUG - 2013-04-13 09:40:02 --> Input Class Initialized
DEBUG - 2013-04-13 09:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:40:02 --> Language Class Initialized
DEBUG - 2013-04-13 09:40:02 --> Loader Class Initialized
DEBUG - 2013-04-13 09:40:02 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:40:02 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:40:02 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:40:02 --> Session Class Initialized
DEBUG - 2013-04-13 09:40:02 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:40:02 --> Session routines successfully run
DEBUG - 2013-04-13 09:40:02 --> Controller Class Initialized
DEBUG - 2013-04-13 09:40:02 --> Language Class Initialized
DEBUG - 2013-04-13 09:40:02 --> Config Class Initialized
DEBUG - 2013-04-13 09:40:02 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:40:02 --> Loader Class Initialized
DEBUG - 2013-04-13 09:40:02 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 09:40:02 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 09:40:02 --> Final output sent to browser
DEBUG - 2013-04-13 09:40:02 --> Total execution time: 0.0153
DEBUG - 2013-04-13 09:40:04 --> Config Class Initialized
DEBUG - 2013-04-13 09:40:04 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:40:04 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:40:04 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:40:04 --> URI Class Initialized
DEBUG - 2013-04-13 09:40:04 --> Router Class Initialized
DEBUG - 2013-04-13 09:40:04 --> Output Class Initialized
DEBUG - 2013-04-13 09:40:04 --> Security Class Initialized
DEBUG - 2013-04-13 09:40:04 --> Input Class Initialized
DEBUG - 2013-04-13 09:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:40:04 --> Language Class Initialized
DEBUG - 2013-04-13 09:40:04 --> Loader Class Initialized
DEBUG - 2013-04-13 09:40:04 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:40:04 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:40:04 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:40:04 --> Session Class Initialized
DEBUG - 2013-04-13 09:40:04 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:40:04 --> Session routines successfully run
DEBUG - 2013-04-13 09:40:04 --> Controller Class Initialized
DEBUG - 2013-04-13 09:40:04 --> Language Class Initialized
DEBUG - 2013-04-13 09:40:04 --> Config Class Initialized
DEBUG - 2013-04-13 09:40:04 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-13 09:40:04 --> Loader Class Initialized
DEBUG - 2013-04-13 09:40:04 --> Model Class Initialized
DEBUG - 2013-04-13 09:40:04 --> Model Class Initialized
DEBUG - 2013-04-13 09:40:04 --> Database Driver Class Initialized
DEBUG - 2013-04-13 09:40:04 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-13 09:40:04 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-13 09:40:04 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 09:40:04 --> Final output sent to browser
DEBUG - 2013-04-13 09:40:04 --> Total execution time: 0.0254
DEBUG - 2013-04-13 09:40:05 --> Config Class Initialized
DEBUG - 2013-04-13 09:40:05 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:40:05 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:40:05 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:40:05 --> URI Class Initialized
DEBUG - 2013-04-13 09:40:05 --> Router Class Initialized
DEBUG - 2013-04-13 09:40:05 --> Output Class Initialized
DEBUG - 2013-04-13 09:40:05 --> Security Class Initialized
DEBUG - 2013-04-13 09:40:05 --> Input Class Initialized
DEBUG - 2013-04-13 09:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:40:05 --> Language Class Initialized
DEBUG - 2013-04-13 09:40:05 --> Loader Class Initialized
DEBUG - 2013-04-13 09:40:05 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:40:05 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:40:05 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:40:05 --> Session Class Initialized
DEBUG - 2013-04-13 09:40:05 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:40:05 --> Session routines successfully run
DEBUG - 2013-04-13 09:40:05 --> Controller Class Initialized
DEBUG - 2013-04-13 09:40:05 --> Language Class Initialized
DEBUG - 2013-04-13 09:40:05 --> Config Class Initialized
DEBUG - 2013-04-13 09:40:05 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-13 09:40:05 --> Loader Class Initialized
DEBUG - 2013-04-13 09:40:05 --> Model Class Initialized
DEBUG - 2013-04-13 09:40:05 --> Model Class Initialized
DEBUG - 2013-04-13 09:40:05 --> Database Driver Class Initialized
DEBUG - 2013-04-13 09:40:05 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-13 09:40:05 --> File loaded: ../application/admin/modules/usuarios/views/usuarios.php
DEBUG - 2013-04-13 09:40:05 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 09:40:05 --> Final output sent to browser
DEBUG - 2013-04-13 09:40:05 --> Total execution time: 0.0250
DEBUG - 2013-04-13 09:40:33 --> Config Class Initialized
DEBUG - 2013-04-13 09:40:33 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:40:33 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:40:33 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:40:33 --> URI Class Initialized
DEBUG - 2013-04-13 09:40:33 --> Router Class Initialized
DEBUG - 2013-04-13 09:40:33 --> Output Class Initialized
DEBUG - 2013-04-13 09:40:33 --> Security Class Initialized
DEBUG - 2013-04-13 09:40:33 --> Input Class Initialized
DEBUG - 2013-04-13 09:40:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:40:33 --> Language Class Initialized
DEBUG - 2013-04-13 09:40:33 --> Loader Class Initialized
DEBUG - 2013-04-13 09:40:33 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:40:33 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:40:33 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:40:33 --> Session Class Initialized
DEBUG - 2013-04-13 09:40:33 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:40:33 --> Session routines successfully run
DEBUG - 2013-04-13 09:40:33 --> Controller Class Initialized
DEBUG - 2013-04-13 09:40:33 --> Language Class Initialized
DEBUG - 2013-04-13 09:40:33 --> Config Class Initialized
DEBUG - 2013-04-13 09:40:33 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:40:33 --> Loader Class Initialized
DEBUG - 2013-04-13 09:40:33 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 09:40:33 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 09:40:33 --> Final output sent to browser
DEBUG - 2013-04-13 09:40:33 --> Total execution time: 0.0177
DEBUG - 2013-04-13 09:41:43 --> Config Class Initialized
DEBUG - 2013-04-13 09:41:43 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:41:43 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:41:43 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:41:43 --> URI Class Initialized
DEBUG - 2013-04-13 09:41:43 --> Router Class Initialized
DEBUG - 2013-04-13 09:41:43 --> Output Class Initialized
DEBUG - 2013-04-13 09:41:43 --> Security Class Initialized
DEBUG - 2013-04-13 09:41:43 --> Input Class Initialized
DEBUG - 2013-04-13 09:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:41:43 --> Language Class Initialized
DEBUG - 2013-04-13 09:41:43 --> Loader Class Initialized
DEBUG - 2013-04-13 09:41:43 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:41:43 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:41:43 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:41:43 --> Session Class Initialized
DEBUG - 2013-04-13 09:41:43 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:41:43 --> Session routines successfully run
DEBUG - 2013-04-13 09:41:43 --> Controller Class Initialized
DEBUG - 2013-04-13 09:41:43 --> Language Class Initialized
DEBUG - 2013-04-13 09:41:43 --> Config Class Initialized
DEBUG - 2013-04-13 09:41:43 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:41:43 --> Loader Class Initialized
DEBUG - 2013-04-13 09:41:43 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 09:41:43 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 09:41:43 --> Final output sent to browser
DEBUG - 2013-04-13 09:41:43 --> Total execution time: 0.0235
DEBUG - 2013-04-13 09:42:52 --> Config Class Initialized
DEBUG - 2013-04-13 09:42:52 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:42:52 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:42:52 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:42:52 --> URI Class Initialized
DEBUG - 2013-04-13 09:42:52 --> Router Class Initialized
DEBUG - 2013-04-13 09:42:52 --> Output Class Initialized
DEBUG - 2013-04-13 09:42:52 --> Security Class Initialized
DEBUG - 2013-04-13 09:42:52 --> Input Class Initialized
DEBUG - 2013-04-13 09:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:42:52 --> Language Class Initialized
DEBUG - 2013-04-13 09:42:52 --> Loader Class Initialized
DEBUG - 2013-04-13 09:42:52 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:42:52 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:42:52 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:42:52 --> Session Class Initialized
DEBUG - 2013-04-13 09:42:52 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:42:52 --> Session routines successfully run
DEBUG - 2013-04-13 09:42:52 --> Controller Class Initialized
DEBUG - 2013-04-13 09:42:52 --> Language Class Initialized
DEBUG - 2013-04-13 09:42:52 --> Config Class Initialized
DEBUG - 2013-04-13 09:42:52 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:42:52 --> Loader Class Initialized
DEBUG - 2013-04-13 09:42:52 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 09:42:52 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 09:42:52 --> Final output sent to browser
DEBUG - 2013-04-13 09:42:52 --> Total execution time: 0.0192
DEBUG - 2013-04-13 09:43:13 --> Config Class Initialized
DEBUG - 2013-04-13 09:43:13 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:43:13 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:43:13 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:43:13 --> URI Class Initialized
DEBUG - 2013-04-13 09:43:13 --> Router Class Initialized
DEBUG - 2013-04-13 09:43:13 --> Output Class Initialized
DEBUG - 2013-04-13 09:43:13 --> Security Class Initialized
DEBUG - 2013-04-13 09:43:13 --> Input Class Initialized
DEBUG - 2013-04-13 09:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:43:13 --> Language Class Initialized
DEBUG - 2013-04-13 09:43:13 --> Loader Class Initialized
DEBUG - 2013-04-13 09:43:13 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:43:13 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:43:13 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:43:13 --> Session Class Initialized
DEBUG - 2013-04-13 09:43:13 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:43:13 --> Session routines successfully run
DEBUG - 2013-04-13 09:43:13 --> Controller Class Initialized
DEBUG - 2013-04-13 09:43:13 --> Language Class Initialized
DEBUG - 2013-04-13 09:43:13 --> Config Class Initialized
DEBUG - 2013-04-13 09:43:13 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:43:13 --> Loader Class Initialized
DEBUG - 2013-04-13 09:43:13 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 09:43:13 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 09:43:13 --> Final output sent to browser
DEBUG - 2013-04-13 09:43:13 --> Total execution time: 0.0163
DEBUG - 2013-04-13 09:43:18 --> Config Class Initialized
DEBUG - 2013-04-13 09:43:18 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:43:18 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:43:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:43:18 --> URI Class Initialized
DEBUG - 2013-04-13 09:43:18 --> Router Class Initialized
DEBUG - 2013-04-13 09:43:18 --> Output Class Initialized
DEBUG - 2013-04-13 09:43:18 --> Security Class Initialized
DEBUG - 2013-04-13 09:43:18 --> Input Class Initialized
DEBUG - 2013-04-13 09:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:43:18 --> Language Class Initialized
DEBUG - 2013-04-13 09:43:18 --> Loader Class Initialized
DEBUG - 2013-04-13 09:43:18 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:43:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:43:18 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:43:18 --> Session Class Initialized
DEBUG - 2013-04-13 09:43:18 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:43:18 --> Session routines successfully run
DEBUG - 2013-04-13 09:43:18 --> Controller Class Initialized
DEBUG - 2013-04-13 09:43:18 --> Language Class Initialized
DEBUG - 2013-04-13 09:43:18 --> Config Class Initialized
DEBUG - 2013-04-13 09:43:18 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:43:18 --> Loader Class Initialized
DEBUG - 2013-04-13 09:43:18 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 09:43:18 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 09:43:18 --> Final output sent to browser
DEBUG - 2013-04-13 09:43:18 --> Total execution time: 0.0180
DEBUG - 2013-04-13 09:44:20 --> Config Class Initialized
DEBUG - 2013-04-13 09:44:20 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:44:20 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:44:20 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:44:20 --> URI Class Initialized
DEBUG - 2013-04-13 09:44:20 --> Router Class Initialized
DEBUG - 2013-04-13 09:44:20 --> Output Class Initialized
DEBUG - 2013-04-13 09:44:20 --> Security Class Initialized
DEBUG - 2013-04-13 09:44:20 --> Input Class Initialized
DEBUG - 2013-04-13 09:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:44:20 --> Language Class Initialized
DEBUG - 2013-04-13 09:44:20 --> Loader Class Initialized
DEBUG - 2013-04-13 09:44:20 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:44:20 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:44:20 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:44:20 --> Session Class Initialized
DEBUG - 2013-04-13 09:44:20 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:44:20 --> Session routines successfully run
DEBUG - 2013-04-13 09:44:20 --> Controller Class Initialized
DEBUG - 2013-04-13 09:44:20 --> Language Class Initialized
DEBUG - 2013-04-13 09:44:20 --> Config Class Initialized
DEBUG - 2013-04-13 09:44:20 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:44:20 --> Loader Class Initialized
DEBUG - 2013-04-13 09:44:20 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 09:44:20 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 09:44:20 --> Final output sent to browser
DEBUG - 2013-04-13 09:44:20 --> Total execution time: 0.0248
DEBUG - 2013-04-13 09:45:04 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:04 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:45:04 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:45:04 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:45:04 --> URI Class Initialized
DEBUG - 2013-04-13 09:45:04 --> Router Class Initialized
DEBUG - 2013-04-13 09:45:04 --> Output Class Initialized
DEBUG - 2013-04-13 09:45:04 --> Security Class Initialized
DEBUG - 2013-04-13 09:45:04 --> Input Class Initialized
DEBUG - 2013-04-13 09:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:45:04 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:04 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:04 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:45:04 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:45:04 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:45:04 --> Session Class Initialized
DEBUG - 2013-04-13 09:45:04 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:45:04 --> Session routines successfully run
DEBUG - 2013-04-13 09:45:04 --> Controller Class Initialized
DEBUG - 2013-04-13 09:45:04 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:04 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:04 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:45:04 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:04 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 09:45:04 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 09:45:04 --> Final output sent to browser
DEBUG - 2013-04-13 09:45:04 --> Total execution time: 0.0215
DEBUG - 2013-04-13 09:45:16 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:16 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:45:16 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:45:16 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:45:16 --> URI Class Initialized
DEBUG - 2013-04-13 09:45:16 --> Router Class Initialized
DEBUG - 2013-04-13 09:45:16 --> Output Class Initialized
DEBUG - 2013-04-13 09:45:16 --> Security Class Initialized
DEBUG - 2013-04-13 09:45:16 --> Input Class Initialized
DEBUG - 2013-04-13 09:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:45:16 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:16 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:16 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:45:16 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:45:16 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:45:16 --> Session Class Initialized
DEBUG - 2013-04-13 09:45:16 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:45:16 --> Session routines successfully run
DEBUG - 2013-04-13 09:45:16 --> Controller Class Initialized
DEBUG - 2013-04-13 09:45:16 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:16 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:16 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:45:16 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:16 --> Final output sent to browser
DEBUG - 2013-04-13 09:45:16 --> Total execution time: 0.0162
DEBUG - 2013-04-13 09:45:17 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:45:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:45:17 --> URI Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Router Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Output Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Security Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Input Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:45:17 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:45:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:45:17 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:45:17 --> Session Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:45:17 --> Session routines successfully run
DEBUG - 2013-04-13 09:45:17 --> Controller Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:45:17 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Final output sent to browser
DEBUG - 2013-04-13 09:45:17 --> Total execution time: 0.0196
DEBUG - 2013-04-13 09:45:17 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:45:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:45:17 --> URI Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Router Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Output Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Security Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Input Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:45:17 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:45:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:45:17 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:45:17 --> Session Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:45:17 --> Session routines successfully run
DEBUG - 2013-04-13 09:45:17 --> Controller Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:45:17 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Final output sent to browser
DEBUG - 2013-04-13 09:45:17 --> Total execution time: 0.0151
DEBUG - 2013-04-13 09:45:17 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:45:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:45:17 --> URI Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Router Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Output Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Security Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Input Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:45:17 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:45:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:45:17 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:45:17 --> Session Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:45:17 --> Session routines successfully run
DEBUG - 2013-04-13 09:45:17 --> Controller Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:45:17 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:17 --> Final output sent to browser
DEBUG - 2013-04-13 09:45:17 --> Total execution time: 0.0174
DEBUG - 2013-04-13 09:45:18 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:45:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:45:18 --> URI Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Router Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Output Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Security Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Input Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:45:18 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:45:18 --> Session Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:45:18 --> Session routines successfully run
DEBUG - 2013-04-13 09:45:18 --> Controller Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:45:18 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Final output sent to browser
DEBUG - 2013-04-13 09:45:18 --> Total execution time: 0.0187
DEBUG - 2013-04-13 09:45:18 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:45:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:45:18 --> URI Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Router Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Output Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Security Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Input Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:45:18 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:45:18 --> Session Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:45:18 --> Session routines successfully run
DEBUG - 2013-04-13 09:45:18 --> Controller Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:45:18 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Final output sent to browser
DEBUG - 2013-04-13 09:45:18 --> Total execution time: 0.0154
DEBUG - 2013-04-13 09:45:18 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:45:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:45:18 --> URI Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Router Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Output Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Security Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Input Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:45:18 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:45:18 --> Session Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:45:18 --> Session routines successfully run
DEBUG - 2013-04-13 09:45:18 --> Controller Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:45:18 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Final output sent to browser
DEBUG - 2013-04-13 09:45:18 --> Total execution time: 0.0229
DEBUG - 2013-04-13 09:45:18 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:45:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:45:18 --> URI Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Router Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Output Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Security Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Input Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:45:18 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:45:18 --> Session Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:45:18 --> Session routines successfully run
DEBUG - 2013-04-13 09:45:18 --> Controller Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:45:18 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Final output sent to browser
DEBUG - 2013-04-13 09:45:18 --> Total execution time: 0.0177
DEBUG - 2013-04-13 09:45:18 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:45:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:45:18 --> URI Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Router Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Output Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Security Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Input Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:45:18 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:45:18 --> Session Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:45:18 --> Session routines successfully run
DEBUG - 2013-04-13 09:45:18 --> Controller Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:45:18 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:18 --> Final output sent to browser
DEBUG - 2013-04-13 09:45:18 --> Total execution time: 0.0175
DEBUG - 2013-04-13 09:45:19 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:19 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:45:19 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:45:19 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:45:19 --> URI Class Initialized
DEBUG - 2013-04-13 09:45:19 --> Router Class Initialized
DEBUG - 2013-04-13 09:45:19 --> Output Class Initialized
DEBUG - 2013-04-13 09:45:19 --> Security Class Initialized
DEBUG - 2013-04-13 09:45:19 --> Input Class Initialized
DEBUG - 2013-04-13 09:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:45:19 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:19 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:19 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:45:19 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:45:19 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:45:19 --> Session Class Initialized
DEBUG - 2013-04-13 09:45:19 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:45:19 --> Session routines successfully run
DEBUG - 2013-04-13 09:45:19 --> Controller Class Initialized
DEBUG - 2013-04-13 09:45:19 --> Language Class Initialized
DEBUG - 2013-04-13 09:45:19 --> Config Class Initialized
DEBUG - 2013-04-13 09:45:19 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:45:19 --> Loader Class Initialized
DEBUG - 2013-04-13 09:45:19 --> Final output sent to browser
DEBUG - 2013-04-13 09:45:19 --> Total execution time: 0.0175
DEBUG - 2013-04-13 09:46:38 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:38 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:46:38 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:46:38 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:46:38 --> URI Class Initialized
DEBUG - 2013-04-13 09:46:38 --> Router Class Initialized
DEBUG - 2013-04-13 09:46:38 --> Output Class Initialized
DEBUG - 2013-04-13 09:46:38 --> Security Class Initialized
DEBUG - 2013-04-13 09:46:38 --> Input Class Initialized
DEBUG - 2013-04-13 09:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:46:38 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:38 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:38 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:46:38 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:46:38 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:46:38 --> Session Class Initialized
DEBUG - 2013-04-13 09:46:38 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:46:38 --> Session routines successfully run
DEBUG - 2013-04-13 09:46:38 --> Controller Class Initialized
DEBUG - 2013-04-13 09:46:38 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:38 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:38 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:46:38 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:38 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 09:46:38 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 09:46:38 --> Final output sent to browser
DEBUG - 2013-04-13 09:46:38 --> Total execution time: 0.0210
DEBUG - 2013-04-13 09:46:39 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:39 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:46:39 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:46:39 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:46:39 --> URI Class Initialized
DEBUG - 2013-04-13 09:46:39 --> Router Class Initialized
DEBUG - 2013-04-13 09:46:39 --> Output Class Initialized
DEBUG - 2013-04-13 09:46:39 --> Security Class Initialized
DEBUG - 2013-04-13 09:46:39 --> Input Class Initialized
DEBUG - 2013-04-13 09:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:46:39 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:39 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:39 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:46:39 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:46:39 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:46:39 --> Session Class Initialized
DEBUG - 2013-04-13 09:46:39 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:46:39 --> Session routines successfully run
DEBUG - 2013-04-13 09:46:39 --> Controller Class Initialized
DEBUG - 2013-04-13 09:46:39 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:39 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:39 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:46:39 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:39 --> Final output sent to browser
DEBUG - 2013-04-13 09:46:39 --> Total execution time: 0.0184
DEBUG - 2013-04-13 09:46:40 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:46:40 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:46:40 --> URI Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Router Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Output Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Security Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Input Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:46:40 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:46:40 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:46:40 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:46:40 --> Session Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:46:40 --> Session routines successfully run
DEBUG - 2013-04-13 09:46:40 --> Controller Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:46:40 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Final output sent to browser
DEBUG - 2013-04-13 09:46:40 --> Total execution time: 0.0196
DEBUG - 2013-04-13 09:46:40 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:46:40 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:46:40 --> URI Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Router Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Output Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Security Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Input Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:46:40 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:46:40 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:46:40 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:46:40 --> Session Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:46:40 --> Session routines successfully run
DEBUG - 2013-04-13 09:46:40 --> Controller Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:46:40 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Final output sent to browser
DEBUG - 2013-04-13 09:46:40 --> Total execution time: 0.0194
DEBUG - 2013-04-13 09:46:40 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:46:40 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:46:40 --> URI Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Router Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Output Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Security Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Input Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:46:40 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:46:40 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:46:40 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:46:40 --> Session Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:46:40 --> Session routines successfully run
DEBUG - 2013-04-13 09:46:40 --> Controller Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:46:40 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:40 --> Final output sent to browser
DEBUG - 2013-04-13 09:46:40 --> Total execution time: 0.0188
DEBUG - 2013-04-13 09:46:41 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:46:41 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:46:41 --> URI Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Router Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Output Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Security Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Input Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:46:41 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:46:41 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:46:41 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:46:41 --> Session Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:46:41 --> Session routines successfully run
DEBUG - 2013-04-13 09:46:41 --> Controller Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:46:41 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Final output sent to browser
DEBUG - 2013-04-13 09:46:41 --> Total execution time: 0.0161
DEBUG - 2013-04-13 09:46:41 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:46:41 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:46:41 --> URI Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Router Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Output Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Security Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Input Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:46:41 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:46:41 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:46:41 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:46:41 --> Session Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:46:41 --> Session routines successfully run
DEBUG - 2013-04-13 09:46:41 --> Controller Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:46:41 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Final output sent to browser
DEBUG - 2013-04-13 09:46:41 --> Total execution time: 0.0159
DEBUG - 2013-04-13 09:46:41 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:46:41 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:46:41 --> URI Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Router Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Output Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Security Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Input Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:46:41 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:46:41 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:46:41 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:46:41 --> Session Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:46:41 --> Session routines successfully run
DEBUG - 2013-04-13 09:46:41 --> Controller Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:46:41 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Final output sent to browser
DEBUG - 2013-04-13 09:46:41 --> Total execution time: 0.0250
DEBUG - 2013-04-13 09:46:41 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:46:41 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:46:41 --> URI Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Router Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Output Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Security Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Input Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:46:41 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:46:41 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:46:41 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:46:41 --> Session Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:46:41 --> Session routines successfully run
DEBUG - 2013-04-13 09:46:41 --> Controller Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:46:41 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:41 --> Final output sent to browser
DEBUG - 2013-04-13 09:46:41 --> Total execution time: 0.0166
DEBUG - 2013-04-13 09:46:42 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:46:42 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:46:42 --> URI Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Router Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Output Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Security Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Input Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:46:42 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:46:42 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:46:42 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:46:42 --> Session Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:46:42 --> Session routines successfully run
DEBUG - 2013-04-13 09:46:42 --> Controller Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:46:42 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Final output sent to browser
DEBUG - 2013-04-13 09:46:42 --> Total execution time: 0.0181
DEBUG - 2013-04-13 09:46:42 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Hooks Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Utf8 Class Initialized
DEBUG - 2013-04-13 09:46:42 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 09:46:42 --> URI Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Router Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Output Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Security Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Input Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 09:46:42 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Helper loaded: url_helper
DEBUG - 2013-04-13 09:46:42 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 09:46:42 --> Helper loaded: text_helper
DEBUG - 2013-04-13 09:46:42 --> Session Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Helper loaded: string_helper
DEBUG - 2013-04-13 09:46:42 --> Session routines successfully run
DEBUG - 2013-04-13 09:46:42 --> Controller Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Language Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Config Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 09:46:42 --> Loader Class Initialized
DEBUG - 2013-04-13 09:46:42 --> Final output sent to browser
DEBUG - 2013-04-13 09:46:42 --> Total execution time: 0.0154
DEBUG - 2013-04-13 10:23:33 --> Config Class Initialized
DEBUG - 2013-04-13 10:23:33 --> Hooks Class Initialized
DEBUG - 2013-04-13 10:23:33 --> Utf8 Class Initialized
DEBUG - 2013-04-13 10:23:33 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 10:23:33 --> URI Class Initialized
DEBUG - 2013-04-13 10:23:33 --> Router Class Initialized
DEBUG - 2013-04-13 10:23:33 --> Output Class Initialized
DEBUG - 2013-04-13 10:23:33 --> Security Class Initialized
DEBUG - 2013-04-13 10:23:33 --> Input Class Initialized
DEBUG - 2013-04-13 10:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 10:23:33 --> Language Class Initialized
DEBUG - 2013-04-13 10:23:33 --> Loader Class Initialized
DEBUG - 2013-04-13 10:23:33 --> Helper loaded: url_helper
DEBUG - 2013-04-13 10:23:33 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 10:23:33 --> Helper loaded: text_helper
DEBUG - 2013-04-13 10:23:33 --> Session Class Initialized
DEBUG - 2013-04-13 10:23:33 --> Helper loaded: string_helper
DEBUG - 2013-04-13 10:23:33 --> Session routines successfully run
DEBUG - 2013-04-13 10:23:33 --> Controller Class Initialized
DEBUG - 2013-04-13 10:23:33 --> Language Class Initialized
DEBUG - 2013-04-13 10:23:33 --> Config Class Initialized
DEBUG - 2013-04-13 10:23:33 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 10:23:33 --> Loader Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Config Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Hooks Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Utf8 Class Initialized
DEBUG - 2013-04-13 10:24:06 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 10:24:06 --> URI Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Router Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Output Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Security Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Input Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 10:24:06 --> Language Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Loader Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Helper loaded: url_helper
DEBUG - 2013-04-13 10:24:06 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 10:24:06 --> Helper loaded: text_helper
DEBUG - 2013-04-13 10:24:06 --> Session Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Helper loaded: string_helper
DEBUG - 2013-04-13 10:24:06 --> Session routines successfully run
DEBUG - 2013-04-13 10:24:06 --> Controller Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Language Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Config Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 10:24:06 --> Loader Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Model Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Model Class Initialized
DEBUG - 2013-04-13 10:24:06 --> Database Driver Class Initialized
DEBUG - 2013-04-13 10:24:10 --> Config Class Initialized
DEBUG - 2013-04-13 10:24:10 --> Hooks Class Initialized
DEBUG - 2013-04-13 10:24:10 --> Utf8 Class Initialized
DEBUG - 2013-04-13 10:24:10 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 10:24:10 --> URI Class Initialized
DEBUG - 2013-04-13 10:24:10 --> Router Class Initialized
DEBUG - 2013-04-13 10:24:10 --> No URI present. Default controller set.
DEBUG - 2013-04-13 10:24:10 --> Output Class Initialized
DEBUG - 2013-04-13 10:24:10 --> Security Class Initialized
DEBUG - 2013-04-13 10:24:10 --> Input Class Initialized
DEBUG - 2013-04-13 10:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 10:24:10 --> Language Class Initialized
DEBUG - 2013-04-13 10:24:10 --> Loader Class Initialized
DEBUG - 2013-04-13 10:24:10 --> Helper loaded: url_helper
DEBUG - 2013-04-13 10:24:10 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 10:24:10 --> Helper loaded: text_helper
DEBUG - 2013-04-13 10:24:10 --> Session Class Initialized
DEBUG - 2013-04-13 10:24:10 --> Helper loaded: string_helper
DEBUG - 2013-04-13 10:24:10 --> Session routines successfully run
DEBUG - 2013-04-13 10:24:10 --> Controller Class Initialized
DEBUG - 2013-04-13 10:24:10 --> Language Class Initialized
DEBUG - 2013-04-13 10:24:10 --> Config Class Initialized
DEBUG - 2013-04-13 10:24:10 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-13 10:24:10 --> Loader Class Initialized
DEBUG - 2013-04-13 10:24:10 --> File loaded: ../application/admin/modules/autenticacao/views/login.php
DEBUG - 2013-04-13 10:24:10 --> Final output sent to browser
DEBUG - 2013-04-13 10:24:10 --> Total execution time: 0.0182
DEBUG - 2013-04-13 10:31:55 --> Config Class Initialized
DEBUG - 2013-04-13 10:31:55 --> Hooks Class Initialized
DEBUG - 2013-04-13 10:31:55 --> Utf8 Class Initialized
DEBUG - 2013-04-13 10:31:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-13 10:31:55 --> URI Class Initialized
DEBUG - 2013-04-13 10:31:55 --> Router Class Initialized
DEBUG - 2013-04-13 10:31:55 --> Output Class Initialized
DEBUG - 2013-04-13 10:31:55 --> Security Class Initialized
DEBUG - 2013-04-13 10:31:55 --> Input Class Initialized
DEBUG - 2013-04-13 10:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-13 10:31:55 --> Language Class Initialized
DEBUG - 2013-04-13 10:31:55 --> Loader Class Initialized
DEBUG - 2013-04-13 10:31:55 --> Helper loaded: url_helper
DEBUG - 2013-04-13 10:31:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-13 10:31:55 --> Helper loaded: text_helper
DEBUG - 2013-04-13 10:31:55 --> Session Class Initialized
DEBUG - 2013-04-13 10:31:55 --> Helper loaded: string_helper
DEBUG - 2013-04-13 10:31:55 --> Session routines successfully run
DEBUG - 2013-04-13 10:31:55 --> Controller Class Initialized
DEBUG - 2013-04-13 10:31:55 --> Language Class Initialized
DEBUG - 2013-04-13 10:31:55 --> Config Class Initialized
DEBUG - 2013-04-13 10:31:55 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-13 10:31:55 --> Loader Class Initialized
DEBUG - 2013-04-13 10:31:55 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-13 10:31:55 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-13 10:31:55 --> Final output sent to browser
DEBUG - 2013-04-13 10:31:55 --> Total execution time: 0.0175
