<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-04-11 13:22:16 --> Config Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:22:16 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:22:16 --> URI Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Router Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Output Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Security Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Input Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:22:16 --> Language Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Loader Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:22:16 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:22:16 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:22:16 --> Session Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:22:16 --> Session routines successfully run
DEBUG - 2013-04-11 13:22:16 --> Controller Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Language Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Config Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:22:16 --> Loader Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Model Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Model Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:22:16 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:22:16 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:22:16 --> Model Class Initialized
DEBUG - 2013-04-11 13:22:16 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:22:16 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:22:16 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:22:16 --> Final output sent to browser
DEBUG - 2013-04-11 13:22:16 --> Total execution time: 0.0276
DEBUG - 2013-04-11 13:22:48 --> Config Class Initialized
DEBUG - 2013-04-11 13:22:48 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:22:48 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:22:48 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:22:48 --> URI Class Initialized
DEBUG - 2013-04-11 13:22:48 --> Router Class Initialized
DEBUG - 2013-04-11 13:22:48 --> Output Class Initialized
DEBUG - 2013-04-11 13:22:48 --> Security Class Initialized
DEBUG - 2013-04-11 13:22:48 --> Input Class Initialized
DEBUG - 2013-04-11 13:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:22:48 --> Language Class Initialized
DEBUG - 2013-04-11 13:22:48 --> Loader Class Initialized
DEBUG - 2013-04-11 13:22:48 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:22:48 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:22:48 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:22:48 --> Session Class Initialized
DEBUG - 2013-04-11 13:22:48 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:22:48 --> Session routines successfully run
DEBUG - 2013-04-11 13:22:48 --> Controller Class Initialized
DEBUG - 2013-04-11 13:22:48 --> Language Class Initialized
DEBUG - 2013-04-11 13:22:48 --> Config Class Initialized
DEBUG - 2013-04-11 13:22:48 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:22:48 --> Loader Class Initialized
DEBUG - 2013-04-11 13:22:48 --> Model Class Initialized
DEBUG - 2013-04-11 13:22:48 --> Model Class Initialized
DEBUG - 2013-04-11 13:22:48 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:22:48 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:22:48 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 13:22:48 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:22:48 --> Final output sent to browser
DEBUG - 2013-04-11 13:22:48 --> Total execution time: 0.0233
DEBUG - 2013-04-11 13:22:55 --> Config Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:22:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:22:55 --> URI Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Router Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Output Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Security Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Input Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:22:55 --> Language Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Loader Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:22:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:22:55 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:22:55 --> Session Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:22:55 --> Session routines successfully run
DEBUG - 2013-04-11 13:22:55 --> Controller Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Language Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Config Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:22:55 --> Loader Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Model Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Model Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:22:55 --> Model Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Config Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:25:29 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:25:29 --> URI Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Router Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Output Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Security Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Input Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:25:29 --> Language Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Loader Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:25:29 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:25:29 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:25:29 --> Session Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:25:29 --> Session routines successfully run
DEBUG - 2013-04-11 13:25:29 --> Controller Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Language Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Config Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:25:29 --> Loader Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Model Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Model Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Model Class Initialized
DEBUG - 2013-04-11 13:25:29 --> Final output sent to browser
DEBUG - 2013-04-11 13:25:29 --> Total execution time: 0.0271
DEBUG - 2013-04-11 13:26:02 --> Config Class Initialized
DEBUG - 2013-04-11 13:26:02 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:26:02 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:26:02 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:26:02 --> URI Class Initialized
DEBUG - 2013-04-11 13:26:03 --> Router Class Initialized
DEBUG - 2013-04-11 13:26:03 --> Output Class Initialized
DEBUG - 2013-04-11 13:26:03 --> Security Class Initialized
DEBUG - 2013-04-11 13:26:03 --> Input Class Initialized
DEBUG - 2013-04-11 13:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:26:03 --> Language Class Initialized
DEBUG - 2013-04-11 13:26:03 --> Loader Class Initialized
DEBUG - 2013-04-11 13:26:03 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:26:03 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:26:03 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:26:03 --> Session Class Initialized
DEBUG - 2013-04-11 13:26:03 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:26:03 --> Session routines successfully run
DEBUG - 2013-04-11 13:26:03 --> Controller Class Initialized
DEBUG - 2013-04-11 13:26:03 --> Language Class Initialized
DEBUG - 2013-04-11 13:26:03 --> Config Class Initialized
DEBUG - 2013-04-11 13:26:03 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:26:03 --> Loader Class Initialized
DEBUG - 2013-04-11 13:26:03 --> Model Class Initialized
DEBUG - 2013-04-11 13:26:03 --> Model Class Initialized
DEBUG - 2013-04-11 13:26:03 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:26:03 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:26:03 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:26:03 --> Model Class Initialized
DEBUG - 2013-04-11 13:26:03 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:26:03 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:26:03 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:26:03 --> Final output sent to browser
DEBUG - 2013-04-11 13:26:03 --> Total execution time: 0.0307
DEBUG - 2013-04-11 13:27:09 --> Config Class Initialized
DEBUG - 2013-04-11 13:27:09 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:27:09 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:27:09 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:27:09 --> URI Class Initialized
DEBUG - 2013-04-11 13:27:09 --> Router Class Initialized
DEBUG - 2013-04-11 13:27:09 --> Output Class Initialized
DEBUG - 2013-04-11 13:27:09 --> Security Class Initialized
DEBUG - 2013-04-11 13:27:09 --> Input Class Initialized
DEBUG - 2013-04-11 13:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:27:09 --> Language Class Initialized
DEBUG - 2013-04-11 13:27:09 --> Loader Class Initialized
DEBUG - 2013-04-11 13:27:09 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:27:09 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:27:09 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:27:09 --> Session Class Initialized
DEBUG - 2013-04-11 13:27:09 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:27:09 --> Session routines successfully run
DEBUG - 2013-04-11 13:27:09 --> Controller Class Initialized
DEBUG - 2013-04-11 13:27:09 --> Language Class Initialized
DEBUG - 2013-04-11 13:27:09 --> Config Class Initialized
DEBUG - 2013-04-11 13:27:09 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:27:09 --> Loader Class Initialized
DEBUG - 2013-04-11 13:27:09 --> Model Class Initialized
DEBUG - 2013-04-11 13:27:09 --> Model Class Initialized
DEBUG - 2013-04-11 13:27:09 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:27:09 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:27:09 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 13:27:09 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:27:09 --> Final output sent to browser
DEBUG - 2013-04-11 13:27:09 --> Total execution time: 0.0283
DEBUG - 2013-04-11 13:27:17 --> Config Class Initialized
DEBUG - 2013-04-11 13:27:17 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:27:17 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:27:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:27:17 --> URI Class Initialized
DEBUG - 2013-04-11 13:27:17 --> Router Class Initialized
DEBUG - 2013-04-11 13:27:17 --> Output Class Initialized
DEBUG - 2013-04-11 13:27:17 --> Security Class Initialized
DEBUG - 2013-04-11 13:27:17 --> Input Class Initialized
DEBUG - 2013-04-11 13:27:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:27:17 --> Language Class Initialized
DEBUG - 2013-04-11 13:27:17 --> Loader Class Initialized
DEBUG - 2013-04-11 13:27:17 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:27:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:27:17 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:27:17 --> Session Class Initialized
DEBUG - 2013-04-11 13:27:17 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:27:17 --> Session routines successfully run
DEBUG - 2013-04-11 13:27:17 --> Controller Class Initialized
DEBUG - 2013-04-11 13:27:17 --> Language Class Initialized
DEBUG - 2013-04-11 13:27:17 --> Config Class Initialized
DEBUG - 2013-04-11 13:27:17 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:27:17 --> Loader Class Initialized
DEBUG - 2013-04-11 13:27:17 --> Model Class Initialized
DEBUG - 2013-04-11 13:27:17 --> Model Class Initialized
DEBUG - 2013-04-11 13:27:17 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:27:17 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:27:17 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 13:27:17 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:27:17 --> Final output sent to browser
DEBUG - 2013-04-11 13:27:17 --> Total execution time: 0.0242
DEBUG - 2013-04-11 13:27:23 --> Config Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:27:23 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:27:23 --> URI Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Router Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Output Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Security Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Input Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:27:23 --> Language Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Loader Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:27:23 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:27:23 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:27:23 --> Session Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:27:23 --> Session routines successfully run
DEBUG - 2013-04-11 13:27:23 --> Controller Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Language Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Config Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:27:23 --> Loader Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Model Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Model Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Model Class Initialized
DEBUG - 2013-04-11 13:27:23 --> Final output sent to browser
DEBUG - 2013-04-11 13:27:23 --> Total execution time: 0.0274
DEBUG - 2013-04-11 13:27:28 --> Config Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:27:28 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:27:28 --> URI Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Router Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Output Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Security Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Input Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:27:28 --> Language Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Loader Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:27:28 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:27:28 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:27:28 --> Session Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:27:28 --> Session routines successfully run
DEBUG - 2013-04-11 13:27:28 --> Controller Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Language Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Config Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:27:28 --> Loader Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Model Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Model Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:27:28 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:27:28 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:27:28 --> Model Class Initialized
DEBUG - 2013-04-11 13:27:28 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:27:28 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:27:28 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:27:28 --> Final output sent to browser
DEBUG - 2013-04-11 13:27:28 --> Total execution time: 0.0287
DEBUG - 2013-04-11 13:28:01 --> Config Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:28:01 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:28:01 --> URI Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Router Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Output Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Security Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Input Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:28:01 --> Language Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Loader Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:28:01 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:28:01 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:28:01 --> Session Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:28:01 --> Session routines successfully run
DEBUG - 2013-04-11 13:28:01 --> Controller Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Language Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Config Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:28:01 --> Loader Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Model Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Model Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:28:01 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:28:01 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:28:01 --> Model Class Initialized
DEBUG - 2013-04-11 13:28:01 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:28:01 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:28:01 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:28:01 --> Final output sent to browser
DEBUG - 2013-04-11 13:28:01 --> Total execution time: 0.0377
DEBUG - 2013-04-11 13:28:03 --> Config Class Initialized
DEBUG - 2013-04-11 13:28:03 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:28:03 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:28:03 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:28:03 --> URI Class Initialized
DEBUG - 2013-04-11 13:28:03 --> Router Class Initialized
DEBUG - 2013-04-11 13:28:03 --> Output Class Initialized
DEBUG - 2013-04-11 13:28:03 --> Security Class Initialized
DEBUG - 2013-04-11 13:28:03 --> Input Class Initialized
DEBUG - 2013-04-11 13:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:28:03 --> Language Class Initialized
DEBUG - 2013-04-11 13:28:03 --> Loader Class Initialized
DEBUG - 2013-04-11 13:28:03 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:28:03 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:28:03 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:28:03 --> Session Class Initialized
DEBUG - 2013-04-11 13:28:03 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:28:03 --> Session routines successfully run
DEBUG - 2013-04-11 13:28:03 --> Controller Class Initialized
DEBUG - 2013-04-11 13:28:03 --> Language Class Initialized
DEBUG - 2013-04-11 13:28:03 --> Config Class Initialized
DEBUG - 2013-04-11 13:28:03 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:28:03 --> Loader Class Initialized
DEBUG - 2013-04-11 13:28:03 --> Model Class Initialized
DEBUG - 2013-04-11 13:28:03 --> Model Class Initialized
DEBUG - 2013-04-11 13:28:03 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:28:03 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:28:03 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 13:28:03 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:28:03 --> Final output sent to browser
DEBUG - 2013-04-11 13:28:03 --> Total execution time: 0.0254
DEBUG - 2013-04-11 13:28:09 --> Config Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:28:09 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:28:09 --> URI Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Router Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Output Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Security Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Input Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:28:09 --> Language Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Loader Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:28:09 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:28:09 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:28:09 --> Session Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:28:09 --> Session routines successfully run
DEBUG - 2013-04-11 13:28:09 --> Controller Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Language Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Config Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:28:09 --> Loader Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Model Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Model Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Model Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Final output sent to browser
DEBUG - 2013-04-11 13:28:09 --> Total execution time: 0.0349
DEBUG - 2013-04-11 13:28:09 --> Config Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:28:09 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:28:09 --> URI Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Router Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Output Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Security Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Input Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:28:09 --> Language Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Loader Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:28:09 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:28:09 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:28:09 --> Session Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:28:09 --> Session routines successfully run
DEBUG - 2013-04-11 13:28:09 --> Controller Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Language Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Config Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:28:09 --> Loader Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Model Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Model Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:28:09 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:28:09 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:28:09 --> Model Class Initialized
DEBUG - 2013-04-11 13:28:09 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:28:09 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:28:09 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:28:09 --> Final output sent to browser
DEBUG - 2013-04-11 13:28:09 --> Total execution time: 0.0268
DEBUG - 2013-04-11 13:28:16 --> Config Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:28:16 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:28:16 --> URI Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Router Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Output Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Security Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Input Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:28:16 --> Language Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Loader Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:28:16 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:28:16 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:28:16 --> Session Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:28:16 --> Session routines successfully run
DEBUG - 2013-04-11 13:28:16 --> Controller Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Language Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Config Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:28:16 --> Loader Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Model Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Model Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:28:16 --> Model Class Initialized
DEBUG - 2013-04-11 13:28:16 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:28:16 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-11 13:28:16 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:28:16 --> Final output sent to browser
DEBUG - 2013-04-11 13:28:16 --> Total execution time: 0.0291
DEBUG - 2013-04-11 13:31:28 --> Config Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:31:28 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:31:28 --> URI Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Router Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Output Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Security Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Input Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:31:28 --> Language Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Loader Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:31:28 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:31:28 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:31:28 --> Session Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:31:28 --> Session routines successfully run
DEBUG - 2013-04-11 13:31:28 --> Controller Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Language Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Config Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:31:28 --> Loader Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Model Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Model Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:31:28 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:31:28 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:31:28 --> Model Class Initialized
DEBUG - 2013-04-11 13:31:28 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:31:28 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:31:28 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:31:28 --> Final output sent to browser
DEBUG - 2013-04-11 13:31:28 --> Total execution time: 0.0320
DEBUG - 2013-04-11 13:31:34 --> Config Class Initialized
DEBUG - 2013-04-11 13:31:34 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:31:34 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:31:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:31:34 --> URI Class Initialized
DEBUG - 2013-04-11 13:31:34 --> Router Class Initialized
DEBUG - 2013-04-11 13:31:34 --> Output Class Initialized
DEBUG - 2013-04-11 13:31:34 --> Security Class Initialized
DEBUG - 2013-04-11 13:31:34 --> Input Class Initialized
DEBUG - 2013-04-11 13:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:31:34 --> Language Class Initialized
DEBUG - 2013-04-11 13:31:34 --> Loader Class Initialized
DEBUG - 2013-04-11 13:31:34 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:31:34 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:31:34 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:31:34 --> Session Class Initialized
DEBUG - 2013-04-11 13:31:34 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:31:34 --> Session routines successfully run
DEBUG - 2013-04-11 13:31:34 --> Controller Class Initialized
DEBUG - 2013-04-11 13:31:34 --> Language Class Initialized
DEBUG - 2013-04-11 13:31:34 --> Config Class Initialized
DEBUG - 2013-04-11 13:31:34 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:31:34 --> Loader Class Initialized
DEBUG - 2013-04-11 13:31:34 --> Model Class Initialized
DEBUG - 2013-04-11 13:31:34 --> Model Class Initialized
DEBUG - 2013-04-11 13:31:34 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:31:34 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:31:34 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 13:31:34 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:31:34 --> Final output sent to browser
DEBUG - 2013-04-11 13:31:34 --> Total execution time: 0.0256
DEBUG - 2013-04-11 13:31:38 --> Config Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:31:38 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:31:38 --> URI Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Router Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Output Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Security Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Input Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:31:38 --> Language Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Loader Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:31:38 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:31:38 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:31:38 --> Session Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:31:38 --> Session routines successfully run
DEBUG - 2013-04-11 13:31:38 --> Controller Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Language Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Config Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:31:38 --> Loader Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Model Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Model Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:31:38 --> Model Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Config Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:31:46 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:31:46 --> URI Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Router Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Output Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Security Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Input Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:31:46 --> Language Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Loader Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:31:46 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:31:46 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:31:46 --> Session Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:31:46 --> Session routines successfully run
DEBUG - 2013-04-11 13:31:46 --> Controller Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Language Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Config Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:31:46 --> Loader Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Model Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Model Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:31:46 --> Model Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Config Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:33:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:33:50 --> URI Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Router Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Output Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Security Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Input Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:33:50 --> Language Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Loader Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:33:50 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:33:50 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:33:50 --> Session Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:33:50 --> Session routines successfully run
DEBUG - 2013-04-11 13:33:50 --> Controller Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Language Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Config Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:33:50 --> Loader Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Model Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Model Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:33:50 --> Model Class Initialized
DEBUG - 2013-04-11 13:34:24 --> Config Class Initialized
DEBUG - 2013-04-11 13:34:24 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:34:24 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:34:24 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:34:24 --> URI Class Initialized
DEBUG - 2013-04-11 13:34:24 --> Router Class Initialized
DEBUG - 2013-04-11 13:34:24 --> Output Class Initialized
DEBUG - 2013-04-11 13:34:24 --> Security Class Initialized
DEBUG - 2013-04-11 13:34:24 --> Input Class Initialized
DEBUG - 2013-04-11 13:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:34:24 --> Language Class Initialized
DEBUG - 2013-04-11 13:34:24 --> Loader Class Initialized
DEBUG - 2013-04-11 13:34:25 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:34:25 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:34:25 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:34:25 --> Session Class Initialized
DEBUG - 2013-04-11 13:34:25 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:34:25 --> Session routines successfully run
DEBUG - 2013-04-11 13:34:25 --> Controller Class Initialized
DEBUG - 2013-04-11 13:34:25 --> Language Class Initialized
DEBUG - 2013-04-11 13:34:25 --> Config Class Initialized
DEBUG - 2013-04-11 13:34:25 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:34:25 --> Loader Class Initialized
DEBUG - 2013-04-11 13:34:25 --> Model Class Initialized
DEBUG - 2013-04-11 13:34:25 --> Model Class Initialized
DEBUG - 2013-04-11 13:34:25 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:34:25 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:34:25 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 13:34:25 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:34:25 --> Final output sent to browser
DEBUG - 2013-04-11 13:34:25 --> Total execution time: 0.0257
DEBUG - 2013-04-11 13:34:30 --> Config Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:34:30 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:34:30 --> URI Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Router Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Output Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Security Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Input Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:34:30 --> Language Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Loader Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:34:30 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:34:30 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:34:30 --> Session Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:34:30 --> Session routines successfully run
DEBUG - 2013-04-11 13:34:30 --> Controller Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Language Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Config Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:34:30 --> Loader Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Model Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Model Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:34:30 --> Model Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Config Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:34:36 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:34:36 --> URI Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Router Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Output Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Security Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Input Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:34:36 --> Language Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Loader Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:34:36 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:34:36 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:34:36 --> Session Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:34:36 --> Session routines successfully run
DEBUG - 2013-04-11 13:34:36 --> Controller Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Language Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Config Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:34:36 --> Loader Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Model Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Model Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:34:36 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:34:36 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:34:36 --> Model Class Initialized
DEBUG - 2013-04-11 13:34:36 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:34:36 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:34:36 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:34:36 --> Final output sent to browser
DEBUG - 2013-04-11 13:34:36 --> Total execution time: 0.0326
DEBUG - 2013-04-11 13:34:46 --> Config Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:34:46 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:34:46 --> URI Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Router Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Output Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Security Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Input Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:34:46 --> Language Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Loader Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:34:46 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:34:46 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:34:46 --> Session Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:34:46 --> Session routines successfully run
DEBUG - 2013-04-11 13:34:46 --> Controller Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Language Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Config Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:34:46 --> Loader Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Model Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Model Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:34:46 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:34:46 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:34:46 --> Model Class Initialized
DEBUG - 2013-04-11 13:34:46 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:34:46 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:34:46 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:34:46 --> Final output sent to browser
DEBUG - 2013-04-11 13:34:46 --> Total execution time: 0.0374
DEBUG - 2013-04-11 13:38:20 --> Config Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:38:20 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:38:20 --> URI Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Router Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Output Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Security Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Input Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:38:20 --> Language Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Loader Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:38:20 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:38:20 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:38:20 --> Session Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:38:20 --> Session routines successfully run
DEBUG - 2013-04-11 13:38:20 --> Controller Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Language Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Config Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:38:20 --> Loader Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Model Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Model Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:38:20 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:38:20 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:38:20 --> Model Class Initialized
DEBUG - 2013-04-11 13:38:20 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:38:20 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:38:20 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:38:20 --> Final output sent to browser
DEBUG - 2013-04-11 13:38:20 --> Total execution time: 0.0379
DEBUG - 2013-04-11 13:38:25 --> Config Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:38:25 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:38:25 --> URI Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Router Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Output Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Security Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Input Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:38:25 --> Language Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Loader Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:38:25 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:38:25 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:38:25 --> Session Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:38:25 --> Session routines successfully run
DEBUG - 2013-04-11 13:38:25 --> Controller Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Language Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Config Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:38:25 --> Loader Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Model Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Model Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:38:25 --> Final output sent to browser
DEBUG - 2013-04-11 13:38:25 --> Total execution time: 0.0221
DEBUG - 2013-04-11 13:39:46 --> Config Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:39:46 --> URI Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Router Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Output Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Security Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Input Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:39:46 --> Language Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Loader Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:39:46 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:39:46 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:39:46 --> Session Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:39:46 --> Session routines successfully run
DEBUG - 2013-04-11 13:39:46 --> Controller Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Language Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Config Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:39:46 --> Loader Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Model Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Model Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:39:46 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:39:46 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:39:46 --> Model Class Initialized
DEBUG - 2013-04-11 13:39:46 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:39:46 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:39:46 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:39:46 --> Final output sent to browser
DEBUG - 2013-04-11 13:39:46 --> Total execution time: 0.0281
DEBUG - 2013-04-11 13:39:50 --> Config Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:39:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:39:50 --> URI Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Router Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Output Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Security Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Input Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:39:50 --> Language Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Loader Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:39:50 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:39:50 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:39:50 --> Session Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:39:50 --> Session routines successfully run
DEBUG - 2013-04-11 13:39:50 --> Controller Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Language Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Config Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:39:50 --> Loader Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Model Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Model Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:39:50 --> Final output sent to browser
DEBUG - 2013-04-11 13:39:50 --> Total execution time: 0.0261
DEBUG - 2013-04-11 13:39:54 --> Config Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:39:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:39:54 --> URI Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Router Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Output Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Security Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Input Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:39:54 --> Language Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Loader Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:39:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:39:54 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:39:54 --> Session Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:39:54 --> Session routines successfully run
DEBUG - 2013-04-11 13:39:54 --> Controller Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Language Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Config Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:39:54 --> Loader Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Model Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Model Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:39:54 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:39:54 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:39:54 --> Model Class Initialized
DEBUG - 2013-04-11 13:39:54 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:39:54 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:39:54 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:39:54 --> Final output sent to browser
DEBUG - 2013-04-11 13:39:54 --> Total execution time: 0.0287
DEBUG - 2013-04-11 13:40:25 --> Config Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:40:25 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:40:25 --> URI Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Router Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Output Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Security Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Input Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:40:25 --> Language Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Loader Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:40:25 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:40:25 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:40:25 --> Session Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:40:25 --> Session routines successfully run
DEBUG - 2013-04-11 13:40:25 --> Controller Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Language Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Config Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:40:25 --> Loader Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Model Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Model Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:40:25 --> Final output sent to browser
DEBUG - 2013-04-11 13:40:25 --> Total execution time: 0.0355
DEBUG - 2013-04-11 13:40:28 --> Config Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:40:28 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:40:28 --> URI Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Router Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Output Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Security Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Input Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:40:28 --> Language Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Loader Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:40:28 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:40:28 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:40:28 --> Session Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:40:28 --> Session routines successfully run
DEBUG - 2013-04-11 13:40:28 --> Controller Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Language Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Config Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:40:28 --> Loader Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Model Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Model Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:40:28 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:40:28 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:40:28 --> Model Class Initialized
DEBUG - 2013-04-11 13:40:28 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:40:28 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:40:28 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:40:28 --> Final output sent to browser
DEBUG - 2013-04-11 13:40:28 --> Total execution time: 0.0284
DEBUG - 2013-04-11 13:41:41 --> Config Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:41:41 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:41:41 --> URI Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Router Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Output Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Security Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Input Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:41:41 --> Language Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Loader Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:41:41 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:41:41 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:41:41 --> Session Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:41:41 --> Session routines successfully run
DEBUG - 2013-04-11 13:41:41 --> Controller Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Language Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Config Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:41:41 --> Loader Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Model Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Model Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:41:41 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:41:41 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:41:41 --> Model Class Initialized
DEBUG - 2013-04-11 13:41:41 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:41:41 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:41:41 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:41:41 --> Final output sent to browser
DEBUG - 2013-04-11 13:41:41 --> Total execution time: 0.0263
DEBUG - 2013-04-11 13:41:45 --> Config Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:41:45 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:41:45 --> URI Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Router Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Output Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Security Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Input Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:41:45 --> Language Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Loader Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:41:45 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:41:45 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:41:45 --> Session Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:41:45 --> Session routines successfully run
DEBUG - 2013-04-11 13:41:45 --> Controller Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Language Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Config Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:41:45 --> Loader Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Model Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Model Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Final output sent to browser
DEBUG - 2013-04-11 13:41:45 --> Total execution time: 0.0250
DEBUG - 2013-04-11 13:41:45 --> Config Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:41:45 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:41:45 --> URI Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Router Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Output Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Security Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Input Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:41:45 --> Language Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Loader Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:41:45 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:41:45 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:41:45 --> Session Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:41:45 --> Session routines successfully run
DEBUG - 2013-04-11 13:41:45 --> Controller Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Language Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Config Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:41:45 --> Loader Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Model Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Model Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:41:45 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:41:45 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:41:45 --> Model Class Initialized
DEBUG - 2013-04-11 13:41:45 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:41:45 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:41:45 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:41:45 --> Final output sent to browser
DEBUG - 2013-04-11 13:41:45 --> Total execution time: 0.0255
DEBUG - 2013-04-11 13:43:17 --> Config Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:43:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:43:17 --> URI Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Router Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Output Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Security Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Input Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:43:17 --> Language Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Loader Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:43:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:43:17 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:43:17 --> Session Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:43:17 --> Session routines successfully run
DEBUG - 2013-04-11 13:43:17 --> Controller Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Language Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Config Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:43:17 --> Loader Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Model Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Model Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Final output sent to browser
DEBUG - 2013-04-11 13:43:17 --> Total execution time: 0.0324
DEBUG - 2013-04-11 13:43:17 --> Config Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:43:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:43:17 --> URI Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Router Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Output Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Security Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Input Class Initialized
DEBUG - 2013-04-11 13:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:43:17 --> Language Class Initialized
DEBUG - 2013-04-11 13:43:18 --> Loader Class Initialized
DEBUG - 2013-04-11 13:43:18 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:43:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:43:18 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:43:18 --> Session Class Initialized
DEBUG - 2013-04-11 13:43:18 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:43:18 --> Session routines successfully run
DEBUG - 2013-04-11 13:43:18 --> Controller Class Initialized
DEBUG - 2013-04-11 13:43:18 --> Language Class Initialized
DEBUG - 2013-04-11 13:43:18 --> Config Class Initialized
DEBUG - 2013-04-11 13:43:18 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:43:18 --> Loader Class Initialized
DEBUG - 2013-04-11 13:43:18 --> Model Class Initialized
DEBUG - 2013-04-11 13:43:18 --> Model Class Initialized
DEBUG - 2013-04-11 13:43:18 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:43:18 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:43:18 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:43:18 --> Model Class Initialized
DEBUG - 2013-04-11 13:43:18 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:43:18 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:43:18 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:43:18 --> Final output sent to browser
DEBUG - 2013-04-11 13:43:18 --> Total execution time: 0.0265
DEBUG - 2013-04-11 13:43:23 --> Config Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:43:23 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:43:23 --> URI Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Router Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Output Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Security Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Input Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:43:23 --> Language Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Loader Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:43:23 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:43:23 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:43:23 --> Session Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:43:23 --> Session routines successfully run
DEBUG - 2013-04-11 13:43:23 --> Controller Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Language Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Config Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:43:23 --> Loader Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Model Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Model Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:43:23 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:43:23 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:43:23 --> Model Class Initialized
DEBUG - 2013-04-11 13:43:23 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:43:23 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:43:23 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:43:23 --> Final output sent to browser
DEBUG - 2013-04-11 13:43:23 --> Total execution time: 0.0363
DEBUG - 2013-04-11 13:43:27 --> Config Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:43:27 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:43:27 --> URI Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Router Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Output Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Security Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Input Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:43:27 --> Language Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Loader Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:43:27 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:43:27 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:43:27 --> Session Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:43:27 --> Session routines successfully run
DEBUG - 2013-04-11 13:43:27 --> Controller Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Language Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Config Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:43:27 --> Loader Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Model Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Model Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:43:27 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:43:27 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:43:27 --> Model Class Initialized
DEBUG - 2013-04-11 13:43:27 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:43:27 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:43:27 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:43:27 --> Final output sent to browser
DEBUG - 2013-04-11 13:43:27 --> Total execution time: 0.0276
DEBUG - 2013-04-11 13:46:06 --> Config Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:46:06 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:46:06 --> URI Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Router Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Output Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Security Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Input Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:46:06 --> Language Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Loader Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:46:06 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:46:06 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:46:06 --> Session Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:46:06 --> Session routines successfully run
DEBUG - 2013-04-11 13:46:06 --> Controller Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Language Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Config Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:46:06 --> Loader Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Model Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Model Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:46:06 --> Model Class Initialized
DEBUG - 2013-04-11 13:46:06 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:46:06 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-11 13:46:06 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:46:06 --> Final output sent to browser
DEBUG - 2013-04-11 13:46:06 --> Total execution time: 0.0372
DEBUG - 2013-04-11 13:46:25 --> Config Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:46:25 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:46:25 --> URI Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Router Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Output Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Security Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Input Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:46:25 --> Language Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Loader Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:46:25 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:46:25 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:46:25 --> Session Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:46:25 --> Session routines successfully run
DEBUG - 2013-04-11 13:46:25 --> Controller Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Language Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Config Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:46:25 --> Loader Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Model Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Model Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Model Class Initialized
ERROR - 2013-04-11 13:46:25 --> Severity: Notice  --> Trying to get property of non-object /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 358
INFO  - 2013-04-11 13:46:25 --> O usuario cadastrou um novo usuário: Luiz Picolo
DEBUG - 2013-04-11 13:46:25 --> Final output sent to browser
DEBUG - 2013-04-11 13:46:25 --> Total execution time: 0.0375
DEBUG - 2013-04-11 13:46:25 --> Config Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:46:25 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:46:25 --> URI Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Router Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Output Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Security Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Input Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:46:25 --> Language Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Loader Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:46:25 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:46:25 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:46:25 --> Session Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:46:25 --> Session routines successfully run
DEBUG - 2013-04-11 13:46:25 --> Controller Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Language Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Config Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:46:25 --> Loader Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Model Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Model Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:46:25 --> Model Class Initialized
DEBUG - 2013-04-11 13:46:25 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:46:25 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-11 13:46:25 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:46:25 --> Final output sent to browser
DEBUG - 2013-04-11 13:46:25 --> Total execution time: 0.0297
DEBUG - 2013-04-11 13:46:28 --> Config Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:46:28 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:46:28 --> URI Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Router Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Output Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Security Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Input Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:46:28 --> Language Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Loader Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:46:28 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:46:28 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:46:28 --> Session Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:46:28 --> Session routines successfully run
DEBUG - 2013-04-11 13:46:28 --> Controller Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Language Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Config Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:46:28 --> Loader Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Model Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Model Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:46:28 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:46:28 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:46:28 --> Model Class Initialized
DEBUG - 2013-04-11 13:46:28 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:46:28 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:46:28 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:46:28 --> Final output sent to browser
DEBUG - 2013-04-11 13:46:28 --> Total execution time: 0.0295
DEBUG - 2013-04-11 13:46:30 --> Config Class Initialized
DEBUG - 2013-04-11 13:46:30 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:46:30 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:46:30 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:46:30 --> URI Class Initialized
DEBUG - 2013-04-11 13:46:30 --> Router Class Initialized
DEBUG - 2013-04-11 13:46:30 --> Output Class Initialized
DEBUG - 2013-04-11 13:46:30 --> Security Class Initialized
DEBUG - 2013-04-11 13:46:30 --> Input Class Initialized
DEBUG - 2013-04-11 13:46:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:46:30 --> Language Class Initialized
DEBUG - 2013-04-11 13:46:30 --> Loader Class Initialized
DEBUG - 2013-04-11 13:46:30 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:46:30 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:46:30 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:46:30 --> Session Class Initialized
DEBUG - 2013-04-11 13:46:30 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:46:30 --> Session routines successfully run
DEBUG - 2013-04-11 13:46:30 --> Controller Class Initialized
DEBUG - 2013-04-11 13:46:30 --> Language Class Initialized
DEBUG - 2013-04-11 13:46:30 --> Config Class Initialized
DEBUG - 2013-04-11 13:46:30 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:46:30 --> Loader Class Initialized
DEBUG - 2013-04-11 13:46:30 --> Model Class Initialized
DEBUG - 2013-04-11 13:46:30 --> Model Class Initialized
DEBUG - 2013-04-11 13:46:30 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:46:30 --> Severity: Notice  --> Undefined property: CI::$crud /home/w3case/public_html/target-git/application/admin/third_party/MX/Controller.php 57
DEBUG - 2013-04-11 13:47:22 --> Config Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:47:22 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:47:22 --> URI Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Router Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Output Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Security Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Input Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:47:22 --> Language Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Loader Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:47:22 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:47:22 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:47:22 --> Session Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:47:22 --> Session routines successfully run
DEBUG - 2013-04-11 13:47:22 --> Controller Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Language Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Config Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:47:22 --> Loader Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Model Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Model Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Model Class Initialized
ERROR - 2013-04-11 13:47:22 --> Severity: Notice  --> Undefined index: id /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 479
DEBUG - 2013-04-11 13:47:22 --> Final output sent to browser
DEBUG - 2013-04-11 13:47:22 --> Total execution time: 0.0342
DEBUG - 2013-04-11 13:47:22 --> Config Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:47:22 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:47:22 --> URI Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Router Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Output Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Security Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Input Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:47:22 --> Language Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Loader Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:47:22 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:47:22 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:47:22 --> Session Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:47:22 --> Session routines successfully run
DEBUG - 2013-04-11 13:47:22 --> Controller Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Language Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Config Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:47:22 --> Loader Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Model Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Model Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:47:22 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:47:22 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:47:22 --> Model Class Initialized
DEBUG - 2013-04-11 13:47:22 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:47:22 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:47:22 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:47:22 --> Final output sent to browser
DEBUG - 2013-04-11 13:47:22 --> Total execution time: 0.0279
DEBUG - 2013-04-11 13:48:54 --> Config Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:48:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:48:54 --> URI Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Router Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Output Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Security Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Input Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:48:54 --> Language Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Loader Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:48:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:48:54 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:48:54 --> Session Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:48:54 --> Session routines successfully run
DEBUG - 2013-04-11 13:48:54 --> Controller Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Language Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Config Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:48:54 --> Loader Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Model Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Model Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:48:54 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:48:54 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:48:54 --> Model Class Initialized
DEBUG - 2013-04-11 13:48:54 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:48:54 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:48:54 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:48:54 --> Final output sent to browser
DEBUG - 2013-04-11 13:48:54 --> Total execution time: 0.0398
DEBUG - 2013-04-11 13:50:41 --> Config Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:50:41 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:50:41 --> URI Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Router Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Output Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Security Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Input Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:50:41 --> Language Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Loader Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:50:41 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:50:41 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:50:41 --> Session Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:50:41 --> Session routines successfully run
DEBUG - 2013-04-11 13:50:41 --> Controller Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Language Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Config Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:50:41 --> Loader Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Model Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Model Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:50:41 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:50:41 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:50:41 --> Model Class Initialized
DEBUG - 2013-04-11 13:50:41 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:50:41 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:50:41 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:50:41 --> Final output sent to browser
DEBUG - 2013-04-11 13:50:41 --> Total execution time: 0.0344
DEBUG - 2013-04-11 13:50:50 --> Config Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:50:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:50:50 --> URI Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Router Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Output Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Security Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Input Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:50:50 --> Language Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Loader Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:50:50 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:50:50 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:50:50 --> Session Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:50:50 --> Session routines successfully run
DEBUG - 2013-04-11 13:50:50 --> Controller Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Language Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Config Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:50:50 --> Loader Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Model Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Model Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Database Driver Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Model Class Initialized
ERROR - 2013-04-11 13:50:50 --> Severity: Notice  --> Undefined index: id /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 475
DEBUG - 2013-04-11 13:50:50 --> Final output sent to browser
DEBUG - 2013-04-11 13:50:50 --> Total execution time: 0.0344
DEBUG - 2013-04-11 13:50:50 --> Config Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Hooks Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Utf8 Class Initialized
DEBUG - 2013-04-11 13:50:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 13:50:50 --> URI Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Router Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Output Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Security Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Input Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 13:50:50 --> Language Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Loader Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Helper loaded: url_helper
DEBUG - 2013-04-11 13:50:50 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 13:50:50 --> Helper loaded: text_helper
DEBUG - 2013-04-11 13:50:50 --> Session Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Helper loaded: string_helper
DEBUG - 2013-04-11 13:50:50 --> Session routines successfully run
DEBUG - 2013-04-11 13:50:50 --> Controller Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Language Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Config Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 13:50:50 --> Loader Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Model Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Model Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Database Driver Class Initialized
ERROR - 2013-04-11 13:50:50 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 13:50:50 --> Pagination Class Initialized
DEBUG - 2013-04-11 13:50:50 --> Model Class Initialized
DEBUG - 2013-04-11 13:50:50 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 13:50:50 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 13:50:50 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 13:50:50 --> Final output sent to browser
DEBUG - 2013-04-11 13:50:50 --> Total execution time: 0.0274
DEBUG - 2013-04-11 14:04:07 --> Config Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:04:07 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:04:07 --> URI Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Router Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Output Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Security Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Input Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:04:07 --> Language Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Loader Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:04:07 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:04:07 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:04:07 --> Session Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:04:07 --> Session routines successfully run
DEBUG - 2013-04-11 14:04:07 --> Controller Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Language Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Config Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:04:07 --> Loader Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Model Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Model Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:04:07 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:04:07 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:04:07 --> Model Class Initialized
DEBUG - 2013-04-11 14:04:07 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:04:07 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:04:07 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:04:07 --> Final output sent to browser
DEBUG - 2013-04-11 14:04:07 --> Total execution time: 0.0380
DEBUG - 2013-04-11 14:05:19 --> Config Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:05:19 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:05:19 --> URI Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Router Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Output Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Security Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Input Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:05:19 --> Language Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Loader Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:05:19 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:05:19 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:05:19 --> Session Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:05:19 --> Session routines successfully run
DEBUG - 2013-04-11 14:05:19 --> Controller Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Language Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Config Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:05:19 --> Loader Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Model Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Model Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:05:19 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:05:19 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:05:19 --> Model Class Initialized
DEBUG - 2013-04-11 14:05:19 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:05:19 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:05:19 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:05:19 --> Final output sent to browser
DEBUG - 2013-04-11 14:05:19 --> Total execution time: 0.0379
DEBUG - 2013-04-11 14:05:51 --> Config Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:05:51 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:05:51 --> URI Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Router Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Output Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Security Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Input Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:05:51 --> Language Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Loader Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:05:51 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:05:51 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:05:51 --> Session Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:05:51 --> Session routines successfully run
DEBUG - 2013-04-11 14:05:51 --> Controller Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Language Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Config Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:05:51 --> Loader Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Model Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Model Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:05:51 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:05:51 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:05:51 --> Model Class Initialized
DEBUG - 2013-04-11 14:05:51 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:05:51 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:05:51 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:05:51 --> Final output sent to browser
DEBUG - 2013-04-11 14:05:51 --> Total execution time: 0.0301
DEBUG - 2013-04-11 14:05:59 --> Config Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:05:59 --> URI Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Router Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Output Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Security Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Input Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:05:59 --> Language Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Loader Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:05:59 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:05:59 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:05:59 --> Session Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:05:59 --> Session routines successfully run
DEBUG - 2013-04-11 14:05:59 --> Controller Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Language Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Config Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:05:59 --> Loader Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Model Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Model Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Model Class Initialized
ERROR - 2013-04-11 14:05:59 --> Severity: Notice  --> Undefined index: id /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 475
DEBUG - 2013-04-11 14:05:59 --> Final output sent to browser
DEBUG - 2013-04-11 14:05:59 --> Total execution time: 0.0286
DEBUG - 2013-04-11 14:05:59 --> Config Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:05:59 --> URI Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Router Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Output Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Security Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Input Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:05:59 --> Language Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Loader Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:05:59 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:05:59 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:05:59 --> Session Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:05:59 --> Session routines successfully run
DEBUG - 2013-04-11 14:05:59 --> Controller Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Language Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Config Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:05:59 --> Loader Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Model Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Model Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:05:59 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:05:59 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:05:59 --> Model Class Initialized
DEBUG - 2013-04-11 14:05:59 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:05:59 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:05:59 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:05:59 --> Final output sent to browser
DEBUG - 2013-04-11 14:05:59 --> Total execution time: 0.0290
DEBUG - 2013-04-11 14:07:02 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:07:02 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:07:02 --> URI Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Router Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Output Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Security Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Input Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:07:02 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:07:02 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:07:02 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:07:02 --> Session Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:07:02 --> Session routines successfully run
DEBUG - 2013-04-11 14:07:02 --> Controller Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:07:02 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:07:02 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:07:02 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:07:02 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:02 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:07:02 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:07:02 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:07:02 --> Final output sent to browser
DEBUG - 2013-04-11 14:07:02 --> Total execution time: 0.0300
DEBUG - 2013-04-11 14:07:05 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:07:05 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:07:05 --> URI Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Router Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Output Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Security Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Input Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:07:05 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:07:05 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:07:05 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:07:05 --> Session Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:07:05 --> Session routines successfully run
DEBUG - 2013-04-11 14:07:05 --> Controller Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:07:05 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Final output sent to browser
DEBUG - 2013-04-11 14:07:05 --> Total execution time: 0.0258
DEBUG - 2013-04-11 14:07:05 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:07:05 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:07:05 --> URI Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Router Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Output Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Security Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Input Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:07:05 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:07:05 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:07:05 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:07:05 --> Session Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:07:05 --> Session routines successfully run
DEBUG - 2013-04-11 14:07:05 --> Controller Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:07:05 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:07:05 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:07:05 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:07:05 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:05 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:07:05 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:07:05 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:07:05 --> Final output sent to browser
DEBUG - 2013-04-11 14:07:05 --> Total execution time: 0.0280
DEBUG - 2013-04-11 14:07:09 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:07:09 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:07:09 --> URI Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Router Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Output Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Security Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Input Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:07:09 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:07:09 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:07:09 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:07:09 --> Session Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:07:09 --> Session routines successfully run
DEBUG - 2013-04-11 14:07:09 --> Controller Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:07:09 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Final output sent to browser
DEBUG - 2013-04-11 14:07:09 --> Total execution time: 0.0269
DEBUG - 2013-04-11 14:07:09 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:07:09 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:07:09 --> URI Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Router Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Output Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Security Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Input Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:07:09 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:07:09 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:07:09 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:07:09 --> Session Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:07:09 --> Session routines successfully run
DEBUG - 2013-04-11 14:07:09 --> Controller Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:07:09 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:07:09 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:07:09 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:07:09 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:09 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:07:09 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:07:09 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:07:09 --> Final output sent to browser
DEBUG - 2013-04-11 14:07:09 --> Total execution time: 0.0272
DEBUG - 2013-04-11 14:07:25 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:07:25 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:07:25 --> URI Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Router Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Output Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Security Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Input Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:07:25 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:07:25 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:07:25 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:07:25 --> Session Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:07:25 --> Session routines successfully run
DEBUG - 2013-04-11 14:07:25 --> Controller Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:07:25 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Final output sent to browser
DEBUG - 2013-04-11 14:07:25 --> Total execution time: 0.0238
DEBUG - 2013-04-11 14:07:25 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:07:25 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:07:25 --> URI Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Router Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Output Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Security Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Input Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:07:25 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:07:25 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:07:25 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:07:25 --> Session Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:07:25 --> Session routines successfully run
DEBUG - 2013-04-11 14:07:25 --> Controller Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:07:25 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:07:25 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:07:25 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:07:25 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:25 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:07:25 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:07:25 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:07:25 --> Final output sent to browser
DEBUG - 2013-04-11 14:07:25 --> Total execution time: 0.0263
DEBUG - 2013-04-11 14:07:47 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:07:47 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:07:47 --> URI Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Router Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Output Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Security Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Input Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:07:47 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:07:47 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:07:47 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:07:47 --> Session Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:07:47 --> Session routines successfully run
DEBUG - 2013-04-11 14:07:47 --> Controller Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:07:47 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Final output sent to browser
DEBUG - 2013-04-11 14:07:47 --> Total execution time: 0.0309
DEBUG - 2013-04-11 14:07:47 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:07:47 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:07:47 --> URI Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Router Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Output Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Security Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Input Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:07:47 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:07:47 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:07:47 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:07:47 --> Session Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:07:47 --> Session routines successfully run
DEBUG - 2013-04-11 14:07:47 --> Controller Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Language Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Config Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:07:47 --> Loader Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:07:47 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:07:47 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:07:47 --> Model Class Initialized
DEBUG - 2013-04-11 14:07:47 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:07:47 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:07:47 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:07:47 --> Final output sent to browser
DEBUG - 2013-04-11 14:07:47 --> Total execution time: 0.0301
DEBUG - 2013-04-11 14:13:50 --> Config Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:13:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:13:50 --> URI Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Router Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Output Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Security Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Input Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:13:50 --> Language Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Loader Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:13:50 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:13:50 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:13:50 --> Session Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:13:50 --> Session routines successfully run
DEBUG - 2013-04-11 14:13:50 --> Controller Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Language Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Config Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:13:50 --> Loader Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Model Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Model Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Config Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:13:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:13:50 --> URI Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Router Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Output Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Security Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Input Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:13:50 --> Language Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Loader Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:13:50 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:13:50 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:13:50 --> Session Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:13:50 --> Session routines successfully run
DEBUG - 2013-04-11 14:13:50 --> Controller Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Language Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Config Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:13:50 --> Loader Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Model Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Model Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:13:50 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:13:50 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:13:50 --> Model Class Initialized
DEBUG - 2013-04-11 14:13:50 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:13:50 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:13:50 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:13:50 --> Final output sent to browser
DEBUG - 2013-04-11 14:13:50 --> Total execution time: 0.0264
DEBUG - 2013-04-11 14:13:52 --> Config Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:13:52 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:13:52 --> URI Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Router Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Output Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Security Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Input Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:13:52 --> Language Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Loader Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:13:52 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:13:52 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:13:52 --> Session Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:13:52 --> Session routines successfully run
DEBUG - 2013-04-11 14:13:52 --> Controller Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Language Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Config Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:13:52 --> Loader Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Model Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Model Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Model Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Final output sent to browser
DEBUG - 2013-04-11 14:13:52 --> Total execution time: 0.0270
DEBUG - 2013-04-11 14:13:52 --> Config Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:13:52 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:13:52 --> URI Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Router Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Output Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Security Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Input Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:13:52 --> Language Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Loader Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:13:52 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:13:52 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:13:52 --> Session Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:13:52 --> Session routines successfully run
DEBUG - 2013-04-11 14:13:52 --> Controller Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Language Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Config Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:13:52 --> Loader Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Model Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Model Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:13:52 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:13:52 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:13:52 --> Model Class Initialized
DEBUG - 2013-04-11 14:13:52 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:13:52 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:13:52 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:13:52 --> Final output sent to browser
DEBUG - 2013-04-11 14:13:52 --> Total execution time: 0.0311
DEBUG - 2013-04-11 14:15:27 --> Config Class Initialized
DEBUG - 2013-04-11 14:15:27 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:15:27 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:15:27 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:15:27 --> URI Class Initialized
DEBUG - 2013-04-11 14:15:27 --> Router Class Initialized
DEBUG - 2013-04-11 14:15:27 --> Output Class Initialized
DEBUG - 2013-04-11 14:15:27 --> Security Class Initialized
DEBUG - 2013-04-11 14:15:27 --> Input Class Initialized
DEBUG - 2013-04-11 14:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:15:27 --> Language Class Initialized
DEBUG - 2013-04-11 14:15:27 --> Loader Class Initialized
DEBUG - 2013-04-11 14:15:27 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:15:27 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:15:27 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:15:27 --> Session Class Initialized
DEBUG - 2013-04-11 14:15:27 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:15:27 --> Session routines successfully run
DEBUG - 2013-04-11 14:15:27 --> Controller Class Initialized
DEBUG - 2013-04-11 14:15:27 --> Language Class Initialized
DEBUG - 2013-04-11 14:15:27 --> Config Class Initialized
DEBUG - 2013-04-11 14:15:27 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:15:27 --> Loader Class Initialized
DEBUG - 2013-04-11 14:15:27 --> Model Class Initialized
DEBUG - 2013-04-11 14:15:27 --> Model Class Initialized
DEBUG - 2013-04-11 14:15:27 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:15:27 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:15:27 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 14:15:27 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:15:27 --> Final output sent to browser
DEBUG - 2013-04-11 14:15:27 --> Total execution time: 0.0427
DEBUG - 2013-04-11 14:15:34 --> Config Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:15:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:15:34 --> URI Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Router Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Output Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Security Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Input Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:15:34 --> Language Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Loader Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:15:34 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:15:34 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:15:34 --> Session Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:15:34 --> Session routines successfully run
DEBUG - 2013-04-11 14:15:34 --> Controller Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Language Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Config Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:15:34 --> Loader Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Model Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Model Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:15:34 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:15:34 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:15:34 --> Model Class Initialized
DEBUG - 2013-04-11 14:15:34 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:15:34 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:15:34 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:15:34 --> Final output sent to browser
DEBUG - 2013-04-11 14:15:34 --> Total execution time: 0.0411
DEBUG - 2013-04-11 14:15:35 --> Config Class Initialized
DEBUG - 2013-04-11 14:15:35 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:15:35 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:15:35 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:15:35 --> URI Class Initialized
DEBUG - 2013-04-11 14:15:35 --> Router Class Initialized
DEBUG - 2013-04-11 14:15:35 --> Output Class Initialized
DEBUG - 2013-04-11 14:15:35 --> Security Class Initialized
DEBUG - 2013-04-11 14:15:35 --> Input Class Initialized
DEBUG - 2013-04-11 14:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:15:35 --> Language Class Initialized
DEBUG - 2013-04-11 14:15:35 --> Loader Class Initialized
DEBUG - 2013-04-11 14:15:35 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:15:35 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:15:35 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:15:35 --> Session Class Initialized
DEBUG - 2013-04-11 14:15:35 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:15:35 --> Session routines successfully run
DEBUG - 2013-04-11 14:15:35 --> Controller Class Initialized
DEBUG - 2013-04-11 14:15:35 --> Language Class Initialized
DEBUG - 2013-04-11 14:15:35 --> Config Class Initialized
DEBUG - 2013-04-11 14:15:35 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:15:35 --> Loader Class Initialized
DEBUG - 2013-04-11 14:15:35 --> Model Class Initialized
DEBUG - 2013-04-11 14:15:35 --> Model Class Initialized
DEBUG - 2013-04-11 14:15:35 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:15:35 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:15:35 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 14:15:35 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:15:35 --> Final output sent to browser
DEBUG - 2013-04-11 14:15:35 --> Total execution time: 0.0265
DEBUG - 2013-04-11 14:19:25 --> Config Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:19:25 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:19:25 --> URI Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Router Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Output Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Security Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Input Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:19:25 --> Language Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Loader Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:19:25 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:19:25 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:19:25 --> Session Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:19:25 --> Session routines successfully run
DEBUG - 2013-04-11 14:19:25 --> Controller Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Language Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Config Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:19:25 --> Loader Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Model Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Model Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:19:25 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 14:19:25 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:19:25 --> Model Class Initialized
DEBUG - 2013-04-11 14:19:25 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:19:25 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 14:19:25 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:19:25 --> Final output sent to browser
DEBUG - 2013-04-11 14:19:25 --> Total execution time: 0.0288
DEBUG - 2013-04-11 14:19:27 --> Config Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:19:27 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:19:27 --> URI Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Router Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Output Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Security Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Input Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:19:27 --> Language Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Loader Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:19:27 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:19:27 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:19:27 --> Session Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:19:27 --> Session routines successfully run
DEBUG - 2013-04-11 14:19:27 --> Controller Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Language Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Config Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:19:27 --> Loader Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Model Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Model Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:19:27 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 14:19:27 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:19:27 --> Model Class Initialized
DEBUG - 2013-04-11 14:19:27 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:19:27 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 14:19:27 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:19:27 --> Final output sent to browser
DEBUG - 2013-04-11 14:19:27 --> Total execution time: 0.0284
DEBUG - 2013-04-11 14:19:29 --> Config Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:19:29 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:19:29 --> URI Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Router Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Output Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Security Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Input Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:19:29 --> Language Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Loader Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:19:29 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:19:29 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:19:29 --> Session Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:19:29 --> Session routines successfully run
DEBUG - 2013-04-11 14:19:29 --> Controller Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Language Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Config Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:19:29 --> Loader Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Model Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Model Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:19:29 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:19:29 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:19:29 --> Model Class Initialized
DEBUG - 2013-04-11 14:19:29 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:19:29 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:19:29 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:19:29 --> Final output sent to browser
DEBUG - 2013-04-11 14:19:29 --> Total execution time: 0.0304
DEBUG - 2013-04-11 14:19:30 --> Config Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:19:30 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:19:30 --> URI Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Router Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Output Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Security Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Input Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:19:30 --> Language Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Loader Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:19:30 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:19:30 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:19:30 --> Session Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:19:30 --> Session routines successfully run
DEBUG - 2013-04-11 14:19:30 --> Controller Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Language Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Config Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:19:30 --> Loader Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Model Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Model Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:19:30 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 14:19:30 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:19:30 --> Model Class Initialized
DEBUG - 2013-04-11 14:19:30 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:19:30 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 14:19:30 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:19:30 --> Final output sent to browser
DEBUG - 2013-04-11 14:19:30 --> Total execution time: 0.0282
DEBUG - 2013-04-11 14:29:17 --> Config Class Initialized
DEBUG - 2013-04-11 14:29:17 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:29:17 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:29:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:29:17 --> URI Class Initialized
DEBUG - 2013-04-11 14:29:17 --> Router Class Initialized
DEBUG - 2013-04-11 14:29:17 --> Output Class Initialized
DEBUG - 2013-04-11 14:29:17 --> Security Class Initialized
DEBUG - 2013-04-11 14:29:17 --> Input Class Initialized
DEBUG - 2013-04-11 14:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:29:17 --> Language Class Initialized
DEBUG - 2013-04-11 14:29:17 --> Loader Class Initialized
DEBUG - 2013-04-11 14:29:17 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:29:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:29:17 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:29:17 --> Session Class Initialized
DEBUG - 2013-04-11 14:29:17 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:29:17 --> Session routines successfully run
DEBUG - 2013-04-11 14:29:17 --> Controller Class Initialized
DEBUG - 2013-04-11 14:29:17 --> Language Class Initialized
DEBUG - 2013-04-11 14:29:17 --> Config Class Initialized
DEBUG - 2013-04-11 14:29:17 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:29:17 --> Loader Class Initialized
DEBUG - 2013-04-11 14:29:17 --> Model Class Initialized
DEBUG - 2013-04-11 14:29:17 --> Model Class Initialized
DEBUG - 2013-04-11 14:29:18 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:29:18 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:29:18 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:29:18 --> Model Class Initialized
DEBUG - 2013-04-11 14:29:18 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:29:18 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:29:18 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:29:18 --> Final output sent to browser
DEBUG - 2013-04-11 14:29:18 --> Total execution time: 0.0298
DEBUG - 2013-04-11 14:32:24 --> Config Class Initialized
DEBUG - 2013-04-11 14:32:24 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:32:24 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:32:24 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:32:24 --> URI Class Initialized
DEBUG - 2013-04-11 14:32:24 --> Router Class Initialized
DEBUG - 2013-04-11 14:32:24 --> Output Class Initialized
DEBUG - 2013-04-11 14:32:24 --> Security Class Initialized
DEBUG - 2013-04-11 14:32:24 --> Input Class Initialized
DEBUG - 2013-04-11 14:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:32:24 --> Language Class Initialized
DEBUG - 2013-04-11 14:32:24 --> Loader Class Initialized
DEBUG - 2013-04-11 14:32:24 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:32:24 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:32:24 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:32:24 --> Session Class Initialized
DEBUG - 2013-04-11 14:32:24 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:32:24 --> Session routines successfully run
DEBUG - 2013-04-11 14:32:24 --> Controller Class Initialized
DEBUG - 2013-04-11 14:32:24 --> Language Class Initialized
DEBUG - 2013-04-11 14:32:24 --> Config Class Initialized
DEBUG - 2013-04-11 14:32:24 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:32:24 --> Loader Class Initialized
DEBUG - 2013-04-11 14:32:24 --> Model Class Initialized
DEBUG - 2013-04-11 14:32:24 --> Model Class Initialized
DEBUG - 2013-04-11 14:32:24 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:32:24 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:32:24 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 14:32:24 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:32:24 --> Final output sent to browser
DEBUG - 2013-04-11 14:32:24 --> Total execution time: 0.0241
DEBUG - 2013-04-11 14:36:28 --> Config Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:36:28 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:36:28 --> URI Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Router Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Output Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Security Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Input Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:36:28 --> Language Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Loader Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:36:28 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:36:28 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:36:28 --> Session Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:36:28 --> Session routines successfully run
DEBUG - 2013-04-11 14:36:28 --> Controller Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Language Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Config Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:36:28 --> Loader Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Model Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Model Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:36:28 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:36:28 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:36:28 --> Model Class Initialized
DEBUG - 2013-04-11 14:36:28 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:36:28 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:36:28 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:36:28 --> Final output sent to browser
DEBUG - 2013-04-11 14:36:28 --> Total execution time: 0.0307
DEBUG - 2013-04-11 14:36:35 --> Config Class Initialized
DEBUG - 2013-04-11 14:36:35 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:36:35 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:36:35 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:36:35 --> URI Class Initialized
DEBUG - 2013-04-11 14:36:35 --> Router Class Initialized
DEBUG - 2013-04-11 14:36:35 --> Output Class Initialized
DEBUG - 2013-04-11 14:36:35 --> Security Class Initialized
DEBUG - 2013-04-11 14:36:35 --> Input Class Initialized
DEBUG - 2013-04-11 14:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:36:35 --> Language Class Initialized
DEBUG - 2013-04-11 14:36:35 --> Loader Class Initialized
DEBUG - 2013-04-11 14:36:35 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:36:35 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:36:35 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:36:35 --> Session Class Initialized
DEBUG - 2013-04-11 14:36:35 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:36:35 --> Session routines successfully run
DEBUG - 2013-04-11 14:36:35 --> Controller Class Initialized
DEBUG - 2013-04-11 14:36:35 --> Language Class Initialized
DEBUG - 2013-04-11 14:36:35 --> Config Class Initialized
DEBUG - 2013-04-11 14:36:35 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:36:35 --> Loader Class Initialized
DEBUG - 2013-04-11 14:36:35 --> Model Class Initialized
DEBUG - 2013-04-11 14:36:35 --> Model Class Initialized
DEBUG - 2013-04-11 14:36:35 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:36:35 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:36:35 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 14:36:35 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:36:35 --> Final output sent to browser
DEBUG - 2013-04-11 14:36:35 --> Total execution time: 0.0338
DEBUG - 2013-04-11 14:36:39 --> Config Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:36:39 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:36:39 --> URI Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Router Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Output Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Security Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Input Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:36:39 --> Language Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Loader Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:36:39 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:36:39 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:36:39 --> Session Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:36:39 --> Session routines successfully run
DEBUG - 2013-04-11 14:36:39 --> Controller Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Language Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Config Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:36:39 --> Loader Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Model Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Model Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:36:39 --> Model Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Config Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:36:44 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:36:44 --> URI Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Router Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Output Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Security Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Input Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:36:44 --> Language Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Loader Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:36:44 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:36:44 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:36:44 --> Session Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:36:44 --> Session routines successfully run
DEBUG - 2013-04-11 14:36:44 --> Controller Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Language Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Config Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:36:44 --> Loader Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Model Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Model Class Initialized
DEBUG - 2013-04-11 14:36:44 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:36:44 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:36:44 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 14:36:44 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:36:44 --> Final output sent to browser
DEBUG - 2013-04-11 14:36:44 --> Total execution time: 0.0258
DEBUG - 2013-04-11 14:36:46 --> Config Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:36:46 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:36:46 --> URI Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Router Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Output Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Security Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Input Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:36:46 --> Language Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Loader Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:36:46 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:36:46 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:36:46 --> Session Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:36:46 --> Session routines successfully run
DEBUG - 2013-04-11 14:36:46 --> Controller Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Language Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Config Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:36:46 --> Loader Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Model Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Model Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:36:46 --> Model Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Config Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:36:52 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:36:52 --> URI Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Router Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Output Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Security Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Input Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:36:52 --> Language Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Loader Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:36:52 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:36:52 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:36:52 --> Session Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:36:52 --> Session routines successfully run
DEBUG - 2013-04-11 14:36:52 --> Controller Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Language Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Config Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:36:52 --> Loader Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Model Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Model Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:36:52 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 14:36:52 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:36:52 --> Model Class Initialized
DEBUG - 2013-04-11 14:36:52 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:36:52 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 14:36:52 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:36:52 --> Final output sent to browser
DEBUG - 2013-04-11 14:36:52 --> Total execution time: 0.0399
DEBUG - 2013-04-11 14:37:44 --> Config Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:37:44 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:37:44 --> URI Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Router Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Output Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Security Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Input Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:37:44 --> Language Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Loader Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:37:44 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:37:44 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:37:44 --> Session Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:37:44 --> Session routines successfully run
DEBUG - 2013-04-11 14:37:44 --> Controller Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Language Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Config Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:37:44 --> Loader Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Model Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Model Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:37:44 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 14:37:44 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:37:44 --> Model Class Initialized
DEBUG - 2013-04-11 14:37:44 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:37:44 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 14:37:44 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:37:44 --> Final output sent to browser
DEBUG - 2013-04-11 14:37:44 --> Total execution time: 0.0385
DEBUG - 2013-04-11 14:38:01 --> Config Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:38:01 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:38:01 --> URI Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Router Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Output Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Security Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Input Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:38:01 --> Language Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Loader Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:38:01 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:38:01 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:38:01 --> Session Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:38:01 --> Session routines successfully run
DEBUG - 2013-04-11 14:38:01 --> Controller Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Language Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Config Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:38:01 --> Loader Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:38:01 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 14:38:01 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:38:01 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:01 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:38:01 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 14:38:01 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:38:01 --> Final output sent to browser
DEBUG - 2013-04-11 14:38:01 --> Total execution time: 0.0273
DEBUG - 2013-04-11 14:38:04 --> Config Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:38:04 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:38:04 --> URI Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Router Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Output Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Security Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Input Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:38:04 --> Language Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Loader Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:38:04 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:38:04 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:38:04 --> Session Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:38:04 --> Session routines successfully run
DEBUG - 2013-04-11 14:38:04 --> Controller Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Language Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Config Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:38:04 --> Loader Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:38:04 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:38:04 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:38:04 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:04 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:38:04 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:38:04 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:38:04 --> Final output sent to browser
DEBUG - 2013-04-11 14:38:04 --> Total execution time: 0.0276
DEBUG - 2013-04-11 14:38:05 --> Config Class Initialized
DEBUG - 2013-04-11 14:38:05 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:38:05 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:38:05 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:38:05 --> URI Class Initialized
DEBUG - 2013-04-11 14:38:05 --> Router Class Initialized
DEBUG - 2013-04-11 14:38:05 --> Output Class Initialized
DEBUG - 2013-04-11 14:38:05 --> Security Class Initialized
DEBUG - 2013-04-11 14:38:05 --> Input Class Initialized
DEBUG - 2013-04-11 14:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:38:05 --> Language Class Initialized
DEBUG - 2013-04-11 14:38:05 --> Loader Class Initialized
DEBUG - 2013-04-11 14:38:05 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:38:05 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:38:05 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:38:05 --> Session Class Initialized
DEBUG - 2013-04-11 14:38:05 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:38:05 --> Session routines successfully run
DEBUG - 2013-04-11 14:38:05 --> Controller Class Initialized
DEBUG - 2013-04-11 14:38:05 --> Language Class Initialized
DEBUG - 2013-04-11 14:38:05 --> Config Class Initialized
DEBUG - 2013-04-11 14:38:05 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:38:05 --> Loader Class Initialized
DEBUG - 2013-04-11 14:38:05 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:05 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:05 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:38:05 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:38:05 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 14:38:05 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:38:05 --> Final output sent to browser
DEBUG - 2013-04-11 14:38:05 --> Total execution time: 0.0234
DEBUG - 2013-04-11 14:38:09 --> Config Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:38:09 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:38:09 --> URI Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Router Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Output Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Security Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Input Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:38:09 --> Language Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Loader Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:38:09 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:38:09 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:38:09 --> Session Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:38:09 --> Session routines successfully run
DEBUG - 2013-04-11 14:38:09 --> Controller Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Language Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Config Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:38:09 --> Loader Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Final output sent to browser
DEBUG - 2013-04-11 14:38:09 --> Total execution time: 0.0264
DEBUG - 2013-04-11 14:38:09 --> Config Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:38:09 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:38:09 --> URI Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Router Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Output Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Security Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Input Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:38:09 --> Language Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Loader Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:38:09 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:38:09 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:38:09 --> Session Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:38:09 --> Session routines successfully run
DEBUG - 2013-04-11 14:38:09 --> Controller Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Language Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Config Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:38:09 --> Loader Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:38:09 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:38:09 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:38:09 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:09 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:38:09 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:38:09 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:38:09 --> Final output sent to browser
DEBUG - 2013-04-11 14:38:09 --> Total execution time: 0.0263
DEBUG - 2013-04-11 14:38:16 --> Config Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:38:16 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:38:16 --> URI Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Router Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Output Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Security Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Input Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:38:16 --> Language Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Loader Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:38:16 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:38:16 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:38:16 --> Session Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:38:16 --> Session routines successfully run
DEBUG - 2013-04-11 14:38:16 --> Controller Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Language Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Config Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:38:16 --> Loader Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:38:16 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:38:16 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:38:16 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:16 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:38:16 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:38:16 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:38:16 --> Final output sent to browser
DEBUG - 2013-04-11 14:38:16 --> Total execution time: 0.0289
DEBUG - 2013-04-11 14:38:19 --> Config Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:38:19 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:38:19 --> URI Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Router Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Output Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Security Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Input Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:38:19 --> Language Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Loader Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:38:19 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:38:19 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:38:19 --> Session Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:38:19 --> Session routines successfully run
DEBUG - 2013-04-11 14:38:19 --> Controller Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Language Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Config Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:38:19 --> Loader Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:38:19 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 14:38:19 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:38:19 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:19 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:38:19 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 14:38:19 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:38:19 --> Final output sent to browser
DEBUG - 2013-04-11 14:38:19 --> Total execution time: 0.0302
DEBUG - 2013-04-11 14:38:21 --> Config Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:38:21 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:38:21 --> URI Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Router Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Output Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Security Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Input Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:38:21 --> Language Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Loader Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:38:21 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:38:21 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:38:21 --> Session Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:38:21 --> Session routines successfully run
DEBUG - 2013-04-11 14:38:21 --> Controller Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Language Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Config Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:38:21 --> Loader Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:38:21 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:38:21 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:38:21 --> Model Class Initialized
DEBUG - 2013-04-11 14:38:21 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:38:21 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:38:21 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:38:21 --> Final output sent to browser
DEBUG - 2013-04-11 14:38:21 --> Total execution time: 0.0298
DEBUG - 2013-04-11 14:39:29 --> Config Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:39:29 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:39:29 --> URI Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Router Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Output Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Security Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Input Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:39:29 --> Language Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Loader Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:39:29 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:39:29 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:39:29 --> Session Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:39:29 --> Session routines successfully run
DEBUG - 2013-04-11 14:39:29 --> Controller Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Language Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Config Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:39:29 --> Loader Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Model Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Model Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:39:29 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:39:29 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:39:29 --> Model Class Initialized
DEBUG - 2013-04-11 14:39:29 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:39:29 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:39:29 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:39:29 --> Final output sent to browser
DEBUG - 2013-04-11 14:39:29 --> Total execution time: 0.0321
DEBUG - 2013-04-11 14:39:31 --> Config Class Initialized
DEBUG - 2013-04-11 14:39:31 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:39:31 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:39:31 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:39:31 --> URI Class Initialized
DEBUG - 2013-04-11 14:39:31 --> Router Class Initialized
DEBUG - 2013-04-11 14:39:31 --> Output Class Initialized
DEBUG - 2013-04-11 14:39:31 --> Security Class Initialized
DEBUG - 2013-04-11 14:39:31 --> Input Class Initialized
DEBUG - 2013-04-11 14:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:39:31 --> Language Class Initialized
DEBUG - 2013-04-11 14:39:31 --> Loader Class Initialized
DEBUG - 2013-04-11 14:39:31 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:39:31 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:39:31 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:39:31 --> Session Class Initialized
DEBUG - 2013-04-11 14:39:31 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:39:31 --> Session routines successfully run
DEBUG - 2013-04-11 14:39:31 --> Controller Class Initialized
DEBUG - 2013-04-11 14:39:31 --> Language Class Initialized
DEBUG - 2013-04-11 14:39:31 --> Config Class Initialized
DEBUG - 2013-04-11 14:39:31 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:39:31 --> Loader Class Initialized
DEBUG - 2013-04-11 14:39:31 --> Model Class Initialized
DEBUG - 2013-04-11 14:39:31 --> Model Class Initialized
DEBUG - 2013-04-11 14:39:31 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:39:31 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:39:31 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 14:39:31 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:39:31 --> Final output sent to browser
DEBUG - 2013-04-11 14:39:31 --> Total execution time: 0.0251
DEBUG - 2013-04-11 14:44:24 --> Config Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:44:24 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:44:24 --> URI Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Router Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Output Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Security Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Input Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:44:24 --> Language Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Loader Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:44:24 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:44:24 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:44:24 --> Session Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:44:24 --> Session routines successfully run
DEBUG - 2013-04-11 14:44:24 --> Controller Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Language Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Config Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:44:24 --> Loader Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Model Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Model Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:44:24 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:44:24 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:44:24 --> Model Class Initialized
DEBUG - 2013-04-11 14:44:24 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:44:24 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:44:24 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:44:24 --> Final output sent to browser
DEBUG - 2013-04-11 14:44:24 --> Total execution time: 0.0275
DEBUG - 2013-04-11 14:44:56 --> Config Class Initialized
DEBUG - 2013-04-11 14:44:56 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:44:56 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:44:56 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:44:56 --> URI Class Initialized
DEBUG - 2013-04-11 14:44:56 --> Router Class Initialized
DEBUG - 2013-04-11 14:44:56 --> Output Class Initialized
DEBUG - 2013-04-11 14:44:56 --> Security Class Initialized
DEBUG - 2013-04-11 14:44:56 --> Input Class Initialized
DEBUG - 2013-04-11 14:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:44:56 --> Language Class Initialized
DEBUG - 2013-04-11 14:44:56 --> Loader Class Initialized
DEBUG - 2013-04-11 14:44:56 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:44:56 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:44:56 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:44:56 --> Session Class Initialized
DEBUG - 2013-04-11 14:44:56 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:44:56 --> Session routines successfully run
DEBUG - 2013-04-11 14:44:56 --> Controller Class Initialized
DEBUG - 2013-04-11 14:44:56 --> Language Class Initialized
DEBUG - 2013-04-11 14:44:56 --> Config Class Initialized
DEBUG - 2013-04-11 14:44:56 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:44:56 --> Loader Class Initialized
DEBUG - 2013-04-11 14:44:56 --> Model Class Initialized
DEBUG - 2013-04-11 14:44:56 --> Model Class Initialized
DEBUG - 2013-04-11 14:44:56 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:44:56 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:44:56 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 14:44:56 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:44:56 --> Final output sent to browser
DEBUG - 2013-04-11 14:44:56 --> Total execution time: 0.0292
DEBUG - 2013-04-11 14:45:00 --> Config Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:45:00 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:45:00 --> URI Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Router Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Output Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Security Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Input Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:45:00 --> Language Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Loader Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:45:00 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:45:00 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:45:00 --> Session Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:45:00 --> Session routines successfully run
DEBUG - 2013-04-11 14:45:00 --> Controller Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Language Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Config Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:45:00 --> Loader Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Final output sent to browser
DEBUG - 2013-04-11 14:45:00 --> Total execution time: 0.0283
DEBUG - 2013-04-11 14:45:00 --> Config Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:45:00 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:45:00 --> URI Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Router Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Output Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Security Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Input Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:45:00 --> Language Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Loader Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:45:00 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:45:00 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:45:00 --> Session Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:45:00 --> Session routines successfully run
DEBUG - 2013-04-11 14:45:00 --> Controller Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Language Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Config Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:45:00 --> Loader Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:45:00 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:45:00 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:45:00 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:00 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:45:00 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:45:00 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:45:00 --> Final output sent to browser
DEBUG - 2013-04-11 14:45:00 --> Total execution time: 0.0313
DEBUG - 2013-04-11 14:45:03 --> Config Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:45:03 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:45:03 --> URI Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Router Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Output Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Security Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Input Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:45:03 --> Language Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Loader Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:45:03 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:45:03 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:45:03 --> Session Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:45:03 --> Session routines successfully run
DEBUG - 2013-04-11 14:45:03 --> Controller Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Language Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Config Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:45:03 --> Loader Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:45:03 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:45:03 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:45:03 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:03 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:45:03 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:45:03 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:45:03 --> Final output sent to browser
DEBUG - 2013-04-11 14:45:03 --> Total execution time: 0.0298
DEBUG - 2013-04-11 14:45:13 --> Config Class Initialized
DEBUG - 2013-04-11 14:45:13 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:45:13 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:45:13 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:45:13 --> URI Class Initialized
DEBUG - 2013-04-11 14:45:13 --> Router Class Initialized
DEBUG - 2013-04-11 14:45:13 --> Output Class Initialized
DEBUG - 2013-04-11 14:45:13 --> Security Class Initialized
DEBUG - 2013-04-11 14:45:13 --> Input Class Initialized
DEBUG - 2013-04-11 14:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:45:13 --> Language Class Initialized
DEBUG - 2013-04-11 14:45:13 --> Loader Class Initialized
DEBUG - 2013-04-11 14:45:13 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:45:13 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:45:13 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:45:13 --> Session Class Initialized
DEBUG - 2013-04-11 14:45:13 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:45:13 --> Session routines successfully run
DEBUG - 2013-04-11 14:45:13 --> Controller Class Initialized
DEBUG - 2013-04-11 14:45:13 --> Language Class Initialized
DEBUG - 2013-04-11 14:45:13 --> Config Class Initialized
DEBUG - 2013-04-11 14:45:13 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:45:13 --> Loader Class Initialized
DEBUG - 2013-04-11 14:45:13 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:13 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:13 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:45:13 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:45:13 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 14:45:13 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:45:13 --> Final output sent to browser
DEBUG - 2013-04-11 14:45:13 --> Total execution time: 0.0314
DEBUG - 2013-04-11 14:45:17 --> Config Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:45:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:45:17 --> URI Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Router Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Output Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Security Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Input Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:45:17 --> Language Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Loader Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:45:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:45:17 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:45:17 --> Session Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:45:17 --> Session routines successfully run
DEBUG - 2013-04-11 14:45:17 --> Controller Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Language Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Config Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:45:17 --> Loader Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Final output sent to browser
DEBUG - 2013-04-11 14:45:17 --> Total execution time: 0.0260
DEBUG - 2013-04-11 14:45:17 --> Config Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:45:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:45:17 --> URI Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Router Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Output Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Security Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Input Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:45:17 --> Language Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Loader Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:45:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:45:17 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:45:17 --> Session Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:45:17 --> Session routines successfully run
DEBUG - 2013-04-11 14:45:17 --> Controller Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Language Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Config Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:45:17 --> Loader Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:45:17 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:45:17 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:45:17 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:17 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:45:17 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:45:17 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:45:17 --> Final output sent to browser
DEBUG - 2013-04-11 14:45:17 --> Total execution time: 0.0276
DEBUG - 2013-04-11 14:45:19 --> Config Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:45:19 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:45:19 --> URI Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Router Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Output Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Security Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Input Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:45:19 --> Language Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Loader Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:45:19 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:45:19 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:45:19 --> Session Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:45:19 --> Session routines successfully run
DEBUG - 2013-04-11 14:45:19 --> Controller Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Language Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Config Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:45:19 --> Loader Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:45:19 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 14:45:19 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:45:19 --> Model Class Initialized
DEBUG - 2013-04-11 14:45:19 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:45:19 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 14:45:19 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:45:19 --> Final output sent to browser
DEBUG - 2013-04-11 14:45:19 --> Total execution time: 0.0301
DEBUG - 2013-04-11 14:48:34 --> Config Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:48:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:48:34 --> URI Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Router Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Output Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Security Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Input Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:48:34 --> Language Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Loader Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:48:34 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:48:34 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:48:34 --> Session Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:48:34 --> Session routines successfully run
DEBUG - 2013-04-11 14:48:34 --> Controller Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Language Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Config Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:48:34 --> Loader Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Model Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Model Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:48:34 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 14:48:34 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:48:34 --> Model Class Initialized
DEBUG - 2013-04-11 14:48:34 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:48:34 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 14:48:34 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:48:34 --> Final output sent to browser
DEBUG - 2013-04-11 14:48:34 --> Total execution time: 0.0350
DEBUG - 2013-04-11 14:48:46 --> Config Class Initialized
DEBUG - 2013-04-11 14:48:46 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:48:46 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:48:46 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:48:46 --> URI Class Initialized
DEBUG - 2013-04-11 14:48:46 --> Router Class Initialized
DEBUG - 2013-04-11 14:48:46 --> Output Class Initialized
DEBUG - 2013-04-11 14:48:46 --> Security Class Initialized
DEBUG - 2013-04-11 14:48:46 --> Input Class Initialized
DEBUG - 2013-04-11 14:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:48:46 --> Language Class Initialized
DEBUG - 2013-04-11 14:48:46 --> Loader Class Initialized
DEBUG - 2013-04-11 14:48:46 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:48:46 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:48:46 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:48:46 --> Session Class Initialized
DEBUG - 2013-04-11 14:48:46 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:48:46 --> Session routines successfully run
DEBUG - 2013-04-11 14:48:46 --> Controller Class Initialized
DEBUG - 2013-04-11 14:48:46 --> Language Class Initialized
DEBUG - 2013-04-11 14:48:46 --> Config Class Initialized
DEBUG - 2013-04-11 14:48:46 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:48:46 --> Loader Class Initialized
DEBUG - 2013-04-11 14:48:46 --> Model Class Initialized
DEBUG - 2013-04-11 14:48:46 --> Model Class Initialized
DEBUG - 2013-04-11 14:48:46 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:48:46 --> 404 Page Not Found --> usuarios/excluirPermanente
DEBUG - 2013-04-11 14:49:01 --> Config Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:49:01 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:49:01 --> URI Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Router Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Output Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Security Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Input Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:49:01 --> Language Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Loader Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:49:01 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:49:01 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:49:01 --> Session Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:49:01 --> Session routines successfully run
DEBUG - 2013-04-11 14:49:01 --> Controller Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Language Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Config Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:49:01 --> Loader Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Model Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Model Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:49:01 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 14:49:01 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:49:01 --> Model Class Initialized
DEBUG - 2013-04-11 14:49:01 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:49:01 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 14:49:01 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:49:01 --> Final output sent to browser
DEBUG - 2013-04-11 14:49:01 --> Total execution time: 0.0303
DEBUG - 2013-04-11 14:49:06 --> Config Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:49:06 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:49:06 --> URI Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Router Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Output Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Security Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Input Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:49:06 --> Language Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Loader Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:49:06 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:49:06 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:49:06 --> Session Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:49:06 --> Session routines successfully run
DEBUG - 2013-04-11 14:49:06 --> Controller Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Language Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Config Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:49:06 --> Loader Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Model Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Model Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:49:06 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 14:49:06 --> Pagination Class Initialized
DEBUG - 2013-04-11 14:49:06 --> Model Class Initialized
DEBUG - 2013-04-11 14:49:06 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:49:06 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 14:49:06 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:49:06 --> Final output sent to browser
DEBUG - 2013-04-11 14:49:06 --> Total execution time: 0.0311
DEBUG - 2013-04-11 14:49:30 --> Config Class Initialized
DEBUG - 2013-04-11 14:49:30 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:49:30 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:49:30 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:49:30 --> URI Class Initialized
DEBUG - 2013-04-11 14:49:30 --> Router Class Initialized
DEBUG - 2013-04-11 14:49:30 --> Output Class Initialized
DEBUG - 2013-04-11 14:49:30 --> Security Class Initialized
DEBUG - 2013-04-11 14:49:30 --> Input Class Initialized
DEBUG - 2013-04-11 14:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:49:30 --> Language Class Initialized
DEBUG - 2013-04-11 14:49:30 --> Loader Class Initialized
DEBUG - 2013-04-11 14:49:30 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:49:30 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:49:30 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:49:30 --> Session Class Initialized
DEBUG - 2013-04-11 14:49:30 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:49:30 --> Session routines successfully run
DEBUG - 2013-04-11 14:49:30 --> Controller Class Initialized
DEBUG - 2013-04-11 14:49:30 --> Language Class Initialized
DEBUG - 2013-04-11 14:49:30 --> Config Class Initialized
DEBUG - 2013-04-11 14:49:30 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:49:30 --> Loader Class Initialized
DEBUG - 2013-04-11 14:49:30 --> Model Class Initialized
DEBUG - 2013-04-11 14:49:30 --> Model Class Initialized
DEBUG - 2013-04-11 14:49:30 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:49:30 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:49:30 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusaoPermanente.php
DEBUG - 2013-04-11 14:49:30 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:49:30 --> Final output sent to browser
DEBUG - 2013-04-11 14:49:30 --> Total execution time: 0.0242
DEBUG - 2013-04-11 14:50:16 --> Config Class Initialized
DEBUG - 2013-04-11 14:50:16 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:50:16 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:50:16 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:50:16 --> URI Class Initialized
DEBUG - 2013-04-11 14:50:16 --> Router Class Initialized
DEBUG - 2013-04-11 14:50:16 --> Output Class Initialized
DEBUG - 2013-04-11 14:50:16 --> Security Class Initialized
DEBUG - 2013-04-11 14:50:16 --> Input Class Initialized
DEBUG - 2013-04-11 14:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:50:16 --> Language Class Initialized
DEBUG - 2013-04-11 14:50:16 --> Loader Class Initialized
DEBUG - 2013-04-11 14:50:16 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:50:16 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:50:16 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:50:16 --> Session Class Initialized
DEBUG - 2013-04-11 14:50:16 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:50:16 --> Session routines successfully run
DEBUG - 2013-04-11 14:50:16 --> Controller Class Initialized
DEBUG - 2013-04-11 14:50:16 --> Language Class Initialized
DEBUG - 2013-04-11 14:50:16 --> Config Class Initialized
DEBUG - 2013-04-11 14:50:16 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:50:16 --> Loader Class Initialized
DEBUG - 2013-04-11 14:50:16 --> Model Class Initialized
DEBUG - 2013-04-11 14:50:16 --> Model Class Initialized
DEBUG - 2013-04-11 14:50:16 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:50:16 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:50:16 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusaoPermanente.php
DEBUG - 2013-04-11 14:50:16 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:50:16 --> Final output sent to browser
DEBUG - 2013-04-11 14:50:16 --> Total execution time: 0.0333
DEBUG - 2013-04-11 14:50:31 --> Config Class Initialized
DEBUG - 2013-04-11 14:50:31 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:50:31 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:50:31 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:50:31 --> URI Class Initialized
DEBUG - 2013-04-11 14:50:31 --> Router Class Initialized
DEBUG - 2013-04-11 14:50:31 --> Output Class Initialized
DEBUG - 2013-04-11 14:50:31 --> Security Class Initialized
DEBUG - 2013-04-11 14:50:31 --> Input Class Initialized
DEBUG - 2013-04-11 14:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:50:31 --> Language Class Initialized
DEBUG - 2013-04-11 14:50:31 --> Loader Class Initialized
DEBUG - 2013-04-11 14:50:31 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:50:31 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:50:31 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:50:31 --> Session Class Initialized
DEBUG - 2013-04-11 14:50:31 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:50:31 --> Session routines successfully run
DEBUG - 2013-04-11 14:50:31 --> Controller Class Initialized
DEBUG - 2013-04-11 14:50:31 --> Language Class Initialized
DEBUG - 2013-04-11 14:50:31 --> Config Class Initialized
DEBUG - 2013-04-11 14:50:31 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:50:31 --> Loader Class Initialized
DEBUG - 2013-04-11 14:50:31 --> Model Class Initialized
DEBUG - 2013-04-11 14:50:31 --> Model Class Initialized
DEBUG - 2013-04-11 14:50:31 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:50:31 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:50:31 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusaoPermanente.php
DEBUG - 2013-04-11 14:50:31 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:50:31 --> Final output sent to browser
DEBUG - 2013-04-11 14:50:31 --> Total execution time: 0.0240
DEBUG - 2013-04-11 14:50:44 --> Config Class Initialized
DEBUG - 2013-04-11 14:50:44 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:50:44 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:50:44 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:50:44 --> URI Class Initialized
DEBUG - 2013-04-11 14:50:44 --> Router Class Initialized
DEBUG - 2013-04-11 14:50:44 --> Output Class Initialized
DEBUG - 2013-04-11 14:50:44 --> Security Class Initialized
DEBUG - 2013-04-11 14:50:44 --> Input Class Initialized
DEBUG - 2013-04-11 14:50:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:50:44 --> Language Class Initialized
DEBUG - 2013-04-11 14:50:44 --> Loader Class Initialized
DEBUG - 2013-04-11 14:50:44 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:50:44 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:50:44 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:50:44 --> Session Class Initialized
DEBUG - 2013-04-11 14:50:44 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:50:44 --> Session routines successfully run
DEBUG - 2013-04-11 14:50:44 --> Controller Class Initialized
DEBUG - 2013-04-11 14:50:44 --> Language Class Initialized
DEBUG - 2013-04-11 14:50:44 --> Config Class Initialized
DEBUG - 2013-04-11 14:50:44 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:50:44 --> Loader Class Initialized
DEBUG - 2013-04-11 14:50:44 --> Model Class Initialized
DEBUG - 2013-04-11 14:50:44 --> Model Class Initialized
DEBUG - 2013-04-11 14:50:44 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:50:44 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:50:44 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusaoPermanente.php
DEBUG - 2013-04-11 14:50:44 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:50:44 --> Final output sent to browser
DEBUG - 2013-04-11 14:50:44 --> Total execution time: 0.0245
DEBUG - 2013-04-11 14:59:52 --> Config Class Initialized
DEBUG - 2013-04-11 14:59:52 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:59:52 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:59:52 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:59:52 --> URI Class Initialized
DEBUG - 2013-04-11 14:59:52 --> Router Class Initialized
DEBUG - 2013-04-11 14:59:52 --> Output Class Initialized
DEBUG - 2013-04-11 14:59:52 --> Security Class Initialized
DEBUG - 2013-04-11 14:59:52 --> Input Class Initialized
DEBUG - 2013-04-11 14:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:59:52 --> Language Class Initialized
DEBUG - 2013-04-11 14:59:52 --> Loader Class Initialized
DEBUG - 2013-04-11 14:59:52 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:59:52 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:59:52 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:59:52 --> Session Class Initialized
DEBUG - 2013-04-11 14:59:52 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:59:52 --> Session routines successfully run
DEBUG - 2013-04-11 14:59:52 --> Controller Class Initialized
DEBUG - 2013-04-11 14:59:52 --> Language Class Initialized
DEBUG - 2013-04-11 14:59:52 --> Config Class Initialized
DEBUG - 2013-04-11 14:59:52 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:59:52 --> Loader Class Initialized
DEBUG - 2013-04-11 14:59:52 --> Model Class Initialized
DEBUG - 2013-04-11 14:59:52 --> Model Class Initialized
DEBUG - 2013-04-11 14:59:52 --> Database Driver Class Initialized
DEBUG - 2013-04-11 14:59:52 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 14:59:52 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusaoPermanente.php
DEBUG - 2013-04-11 14:59:52 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 14:59:52 --> Final output sent to browser
DEBUG - 2013-04-11 14:59:52 --> Total execution time: 0.0360
DEBUG - 2013-04-11 14:59:54 --> Config Class Initialized
DEBUG - 2013-04-11 14:59:54 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:59:54 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:59:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:59:54 --> URI Class Initialized
DEBUG - 2013-04-11 14:59:54 --> Router Class Initialized
DEBUG - 2013-04-11 14:59:54 --> Output Class Initialized
DEBUG - 2013-04-11 14:59:54 --> Security Class Initialized
DEBUG - 2013-04-11 14:59:54 --> Input Class Initialized
DEBUG - 2013-04-11 14:59:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:59:54 --> Language Class Initialized
DEBUG - 2013-04-11 14:59:54 --> Loader Class Initialized
DEBUG - 2013-04-11 14:59:54 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:59:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:59:54 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:59:54 --> Session Class Initialized
DEBUG - 2013-04-11 14:59:54 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:59:54 --> Session routines successfully run
DEBUG - 2013-04-11 14:59:54 --> Controller Class Initialized
DEBUG - 2013-04-11 14:59:54 --> Language Class Initialized
DEBUG - 2013-04-11 14:59:54 --> Config Class Initialized
DEBUG - 2013-04-11 14:59:54 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:59:54 --> Loader Class Initialized
DEBUG - 2013-04-11 14:59:54 --> Model Class Initialized
DEBUG - 2013-04-11 14:59:54 --> Model Class Initialized
DEBUG - 2013-04-11 14:59:54 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:59:54 --> 404 Page Not Found --> usuarios/exclusaoPermanente
DEBUG - 2013-04-11 14:59:55 --> Config Class Initialized
DEBUG - 2013-04-11 14:59:55 --> Hooks Class Initialized
DEBUG - 2013-04-11 14:59:55 --> Utf8 Class Initialized
DEBUG - 2013-04-11 14:59:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 14:59:55 --> URI Class Initialized
DEBUG - 2013-04-11 14:59:55 --> Router Class Initialized
DEBUG - 2013-04-11 14:59:55 --> Output Class Initialized
DEBUG - 2013-04-11 14:59:55 --> Security Class Initialized
DEBUG - 2013-04-11 14:59:55 --> Input Class Initialized
DEBUG - 2013-04-11 14:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 14:59:55 --> Language Class Initialized
DEBUG - 2013-04-11 14:59:55 --> Loader Class Initialized
DEBUG - 2013-04-11 14:59:55 --> Helper loaded: url_helper
DEBUG - 2013-04-11 14:59:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 14:59:55 --> Helper loaded: text_helper
DEBUG - 2013-04-11 14:59:55 --> Session Class Initialized
DEBUG - 2013-04-11 14:59:55 --> Helper loaded: string_helper
DEBUG - 2013-04-11 14:59:55 --> Session routines successfully run
DEBUG - 2013-04-11 14:59:55 --> Controller Class Initialized
DEBUG - 2013-04-11 14:59:55 --> Language Class Initialized
DEBUG - 2013-04-11 14:59:55 --> Config Class Initialized
DEBUG - 2013-04-11 14:59:55 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 14:59:55 --> Loader Class Initialized
DEBUG - 2013-04-11 14:59:55 --> Model Class Initialized
DEBUG - 2013-04-11 14:59:55 --> Model Class Initialized
DEBUG - 2013-04-11 14:59:55 --> Database Driver Class Initialized
ERROR - 2013-04-11 14:59:55 --> 404 Page Not Found --> usuarios/exclusaoPermanente
DEBUG - 2013-04-11 15:00:25 --> Config Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:00:25 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:00:25 --> URI Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Router Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Output Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Security Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Input Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:00:25 --> Language Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Loader Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:00:25 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:00:25 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:00:25 --> Session Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:00:25 --> Session routines successfully run
DEBUG - 2013-04-11 15:00:25 --> Controller Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Language Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Config Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:00:25 --> Loader Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Model Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Model Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:00:25 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:00:25 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:00:25 --> Model Class Initialized
DEBUG - 2013-04-11 15:00:25 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:00:25 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:00:25 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:00:25 --> Final output sent to browser
DEBUG - 2013-04-11 15:00:25 --> Total execution time: 0.0287
DEBUG - 2013-04-11 15:02:13 --> Config Class Initialized
DEBUG - 2013-04-11 15:02:13 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:02:13 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:02:13 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:02:13 --> URI Class Initialized
DEBUG - 2013-04-11 15:02:13 --> Router Class Initialized
DEBUG - 2013-04-11 15:02:13 --> Output Class Initialized
DEBUG - 2013-04-11 15:02:13 --> Security Class Initialized
DEBUG - 2013-04-11 15:02:13 --> Input Class Initialized
DEBUG - 2013-04-11 15:02:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:02:13 --> Language Class Initialized
DEBUG - 2013-04-11 15:02:13 --> Loader Class Initialized
DEBUG - 2013-04-11 15:02:13 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:02:13 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:02:13 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:02:13 --> Session Class Initialized
DEBUG - 2013-04-11 15:02:13 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:02:13 --> Session routines successfully run
DEBUG - 2013-04-11 15:02:13 --> Controller Class Initialized
DEBUG - 2013-04-11 15:02:13 --> Language Class Initialized
DEBUG - 2013-04-11 15:02:13 --> Config Class Initialized
DEBUG - 2013-04-11 15:02:13 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:02:13 --> Loader Class Initialized
DEBUG - 2013-04-11 15:02:13 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:13 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:13 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:02:13 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:02:13 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusaoPermanente.php
DEBUG - 2013-04-11 15:02:13 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:02:13 --> Final output sent to browser
DEBUG - 2013-04-11 15:02:13 --> Total execution time: 0.0262
DEBUG - 2013-04-11 15:02:14 --> Config Class Initialized
DEBUG - 2013-04-11 15:02:14 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:02:14 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:02:14 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:02:14 --> URI Class Initialized
DEBUG - 2013-04-11 15:02:14 --> Router Class Initialized
DEBUG - 2013-04-11 15:02:14 --> Output Class Initialized
DEBUG - 2013-04-11 15:02:14 --> Security Class Initialized
DEBUG - 2013-04-11 15:02:14 --> Input Class Initialized
DEBUG - 2013-04-11 15:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:02:14 --> Language Class Initialized
DEBUG - 2013-04-11 15:02:14 --> Loader Class Initialized
DEBUG - 2013-04-11 15:02:14 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:02:14 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:02:14 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:02:14 --> Session Class Initialized
DEBUG - 2013-04-11 15:02:14 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:02:14 --> Session routines successfully run
DEBUG - 2013-04-11 15:02:14 --> Controller Class Initialized
DEBUG - 2013-04-11 15:02:14 --> Language Class Initialized
DEBUG - 2013-04-11 15:02:14 --> Config Class Initialized
DEBUG - 2013-04-11 15:02:14 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:02:14 --> Loader Class Initialized
DEBUG - 2013-04-11 15:02:14 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:14 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:14 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:02:14 --> 404 Page Not Found --> usuarios/exclusaoPermanente
DEBUG - 2013-04-11 15:02:40 --> Config Class Initialized
DEBUG - 2013-04-11 15:02:40 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:02:40 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:02:40 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:02:40 --> URI Class Initialized
DEBUG - 2013-04-11 15:02:40 --> Router Class Initialized
DEBUG - 2013-04-11 15:02:40 --> Output Class Initialized
DEBUG - 2013-04-11 15:02:40 --> Security Class Initialized
DEBUG - 2013-04-11 15:02:40 --> Input Class Initialized
DEBUG - 2013-04-11 15:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:02:40 --> Language Class Initialized
DEBUG - 2013-04-11 15:02:40 --> Loader Class Initialized
DEBUG - 2013-04-11 15:02:40 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:02:40 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:02:40 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:02:40 --> Session Class Initialized
DEBUG - 2013-04-11 15:02:40 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:02:40 --> Session routines successfully run
DEBUG - 2013-04-11 15:02:40 --> Controller Class Initialized
DEBUG - 2013-04-11 15:02:40 --> Language Class Initialized
DEBUG - 2013-04-11 15:02:40 --> Config Class Initialized
DEBUG - 2013-04-11 15:02:40 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:02:40 --> Loader Class Initialized
DEBUG - 2013-04-11 15:02:40 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:40 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:40 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:02:40 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:02:40 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusaoPermanente.php
DEBUG - 2013-04-11 15:02:40 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:02:40 --> Final output sent to browser
DEBUG - 2013-04-11 15:02:40 --> Total execution time: 0.0335
DEBUG - 2013-04-11 15:02:42 --> Config Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:02:42 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:02:42 --> URI Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Router Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Output Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Security Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Input Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:02:42 --> Language Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Loader Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:02:42 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:02:42 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:02:42 --> Session Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:02:42 --> Session routines successfully run
DEBUG - 2013-04-11 15:02:42 --> Controller Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Language Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Config Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:02:42 --> Loader Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:02:42 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Config Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:02:48 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:02:48 --> URI Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Router Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Output Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Security Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Input Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:02:48 --> Language Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Loader Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:02:48 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:02:48 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:02:48 --> Session Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:02:48 --> Session routines successfully run
DEBUG - 2013-04-11 15:02:48 --> Controller Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Language Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Config Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:02:48 --> Loader Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Final output sent to browser
DEBUG - 2013-04-11 15:02:48 --> Total execution time: 0.0274
DEBUG - 2013-04-11 15:02:48 --> Config Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:02:48 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:02:48 --> URI Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Router Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Output Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Security Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Input Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:02:48 --> Language Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Loader Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:02:48 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:02:48 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:02:48 --> Session Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:02:48 --> Session routines successfully run
DEBUG - 2013-04-11 15:02:48 --> Controller Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Language Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Config Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:02:48 --> Loader Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:02:48 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:02:48 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:02:48 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:48 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:02:48 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:02:48 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:02:48 --> Final output sent to browser
DEBUG - 2013-04-11 15:02:48 --> Total execution time: 0.0276
DEBUG - 2013-04-11 15:02:51 --> Config Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:02:51 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:02:51 --> URI Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Router Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Output Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Security Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Input Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:02:51 --> Language Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Loader Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:02:51 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:02:51 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:02:51 --> Session Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:02:51 --> Session routines successfully run
DEBUG - 2013-04-11 15:02:51 --> Controller Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Language Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Config Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:02:51 --> Loader Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:02:51 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:02:51 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:02:51 --> Model Class Initialized
DEBUG - 2013-04-11 15:02:51 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:02:51 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:02:51 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:02:51 --> Final output sent to browser
DEBUG - 2013-04-11 15:02:51 --> Total execution time: 0.0280
DEBUG - 2013-04-11 15:03:30 --> Config Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:03:30 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:03:30 --> URI Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Router Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Output Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Security Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Input Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:03:30 --> Language Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Loader Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:03:30 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:03:30 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:03:30 --> Session Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:03:30 --> Session routines successfully run
DEBUG - 2013-04-11 15:03:30 --> Controller Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Language Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Config Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:03:30 --> Loader Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Model Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Model Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:03:30 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:03:30 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:03:30 --> Model Class Initialized
DEBUG - 2013-04-11 15:03:30 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:03:30 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:03:30 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:03:30 --> Final output sent to browser
DEBUG - 2013-04-11 15:03:30 --> Total execution time: 0.0289
DEBUG - 2013-04-11 15:03:32 --> Config Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:03:32 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:03:32 --> URI Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Router Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Output Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Security Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Input Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:03:32 --> Language Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Loader Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:03:32 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:03:32 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:03:32 --> Session Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:03:32 --> Session routines successfully run
DEBUG - 2013-04-11 15:03:32 --> Controller Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Language Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Config Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:03:32 --> Loader Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Model Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Model Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:03:32 --> Model Class Initialized
DEBUG - 2013-04-11 15:03:32 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:03:32 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-11 15:03:32 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:03:32 --> Final output sent to browser
DEBUG - 2013-04-11 15:03:32 --> Total execution time: 0.0293
DEBUG - 2013-04-11 15:03:50 --> Config Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:03:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:03:50 --> URI Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Router Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Output Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Security Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Input Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:03:50 --> Language Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Loader Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:03:50 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:03:50 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:03:50 --> Session Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:03:50 --> Session routines successfully run
DEBUG - 2013-04-11 15:03:50 --> Controller Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Language Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Config Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:03:50 --> Loader Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Model Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Model Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:03:50 --> Model Class Initialized
ERROR - 2013-04-11 15:03:50 --> Severity: Notice  --> Trying to get property of non-object /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 487
INFO  - 2013-04-11 15:03:50 --> O usuario cadastrou um novo usuário: teste
DEBUG - 2013-04-11 15:03:50 --> Final output sent to browser
DEBUG - 2013-04-11 15:03:50 --> Total execution time: 0.0255
DEBUG - 2013-04-11 15:03:51 --> Config Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:03:51 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:03:51 --> URI Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Router Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Output Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Security Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Input Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:03:51 --> Language Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Loader Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:03:51 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:03:51 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:03:51 --> Session Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:03:51 --> Session routines successfully run
DEBUG - 2013-04-11 15:03:51 --> Controller Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Language Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Config Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:03:51 --> Loader Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Model Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Model Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:03:51 --> Model Class Initialized
DEBUG - 2013-04-11 15:03:51 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:03:51 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-11 15:03:51 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:03:51 --> Final output sent to browser
DEBUG - 2013-04-11 15:03:51 --> Total execution time: 0.0279
DEBUG - 2013-04-11 15:03:54 --> Config Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:03:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:03:54 --> URI Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Router Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Output Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Security Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Input Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:03:54 --> Language Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Loader Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:03:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:03:54 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:03:54 --> Session Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:03:54 --> Session routines successfully run
DEBUG - 2013-04-11 15:03:54 --> Controller Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Language Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Config Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:03:54 --> Loader Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Model Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Model Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:03:54 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:03:54 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:03:54 --> Model Class Initialized
DEBUG - 2013-04-11 15:03:54 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:03:54 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:03:54 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:03:54 --> Final output sent to browser
DEBUG - 2013-04-11 15:03:54 --> Total execution time: 0.0274
DEBUG - 2013-04-11 15:03:58 --> Config Class Initialized
DEBUG - 2013-04-11 15:03:58 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:03:58 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:03:58 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:03:58 --> URI Class Initialized
DEBUG - 2013-04-11 15:03:58 --> Router Class Initialized
DEBUG - 2013-04-11 15:03:58 --> Output Class Initialized
DEBUG - 2013-04-11 15:03:58 --> Security Class Initialized
DEBUG - 2013-04-11 15:03:58 --> Input Class Initialized
DEBUG - 2013-04-11 15:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:03:58 --> Language Class Initialized
DEBUG - 2013-04-11 15:03:58 --> Loader Class Initialized
DEBUG - 2013-04-11 15:03:58 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:03:58 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:03:58 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:03:58 --> Session Class Initialized
DEBUG - 2013-04-11 15:03:58 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:03:58 --> Session routines successfully run
DEBUG - 2013-04-11 15:03:58 --> Controller Class Initialized
DEBUG - 2013-04-11 15:03:58 --> Language Class Initialized
DEBUG - 2013-04-11 15:03:58 --> Config Class Initialized
DEBUG - 2013-04-11 15:03:58 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:03:58 --> Loader Class Initialized
DEBUG - 2013-04-11 15:03:58 --> Model Class Initialized
DEBUG - 2013-04-11 15:03:58 --> Model Class Initialized
DEBUG - 2013-04-11 15:03:58 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:03:58 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:03:58 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 15:03:58 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:03:58 --> Final output sent to browser
DEBUG - 2013-04-11 15:03:58 --> Total execution time: 0.0268
DEBUG - 2013-04-11 15:04:03 --> Config Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:04:03 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:04:03 --> URI Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Router Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Output Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Security Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Input Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:04:03 --> Language Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Loader Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:04:03 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:04:03 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:04:03 --> Session Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:04:03 --> Session routines successfully run
DEBUG - 2013-04-11 15:04:03 --> Controller Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Language Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Config Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:04:03 --> Loader Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Final output sent to browser
DEBUG - 2013-04-11 15:04:03 --> Total execution time: 0.0346
DEBUG - 2013-04-11 15:04:03 --> Config Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:04:03 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:04:03 --> URI Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Router Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Output Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Security Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Input Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:04:03 --> Language Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Loader Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:04:03 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:04:03 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:04:03 --> Session Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:04:03 --> Session routines successfully run
DEBUG - 2013-04-11 15:04:03 --> Controller Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Language Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Config Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:04:03 --> Loader Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:04:03 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:04:03 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:04:03 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:03 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:04:03 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:04:03 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:04:03 --> Final output sent to browser
DEBUG - 2013-04-11 15:04:03 --> Total execution time: 0.0268
DEBUG - 2013-04-11 15:04:08 --> Config Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:04:08 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:04:08 --> URI Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Router Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Output Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Security Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Input Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:04:08 --> Language Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Loader Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:04:08 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:04:08 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:04:08 --> Session Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:04:08 --> Session routines successfully run
DEBUG - 2013-04-11 15:04:08 --> Controller Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Language Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Config Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:04:08 --> Loader Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:04:08 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:04:08 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:04:08 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:08 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:04:08 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:04:08 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:04:08 --> Final output sent to browser
DEBUG - 2013-04-11 15:04:08 --> Total execution time: 0.0279
DEBUG - 2013-04-11 15:04:10 --> Config Class Initialized
DEBUG - 2013-04-11 15:04:10 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:04:10 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:04:10 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:04:10 --> URI Class Initialized
DEBUG - 2013-04-11 15:04:10 --> Router Class Initialized
DEBUG - 2013-04-11 15:04:10 --> Output Class Initialized
DEBUG - 2013-04-11 15:04:10 --> Security Class Initialized
DEBUG - 2013-04-11 15:04:10 --> Input Class Initialized
DEBUG - 2013-04-11 15:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:04:10 --> Language Class Initialized
DEBUG - 2013-04-11 15:04:10 --> Loader Class Initialized
DEBUG - 2013-04-11 15:04:10 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:04:10 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:04:10 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:04:10 --> Session Class Initialized
DEBUG - 2013-04-11 15:04:10 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:04:10 --> Session routines successfully run
DEBUG - 2013-04-11 15:04:10 --> Controller Class Initialized
DEBUG - 2013-04-11 15:04:10 --> Language Class Initialized
DEBUG - 2013-04-11 15:04:10 --> Config Class Initialized
DEBUG - 2013-04-11 15:04:10 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:04:10 --> Loader Class Initialized
DEBUG - 2013-04-11 15:04:10 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:10 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:10 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:04:10 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:04:10 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusaoPermanente.php
DEBUG - 2013-04-11 15:04:10 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:04:10 --> Final output sent to browser
DEBUG - 2013-04-11 15:04:10 --> Total execution time: 0.0270
DEBUG - 2013-04-11 15:04:16 --> Config Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:04:16 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:04:16 --> URI Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Router Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Output Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Security Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Input Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:04:16 --> Language Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Loader Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:04:16 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:04:16 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:04:16 --> Session Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:04:16 --> Session routines successfully run
DEBUG - 2013-04-11 15:04:16 --> Controller Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Language Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Config Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:04:16 --> Loader Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Final output sent to browser
DEBUG - 2013-04-11 15:04:16 --> Total execution time: 0.0247
DEBUG - 2013-04-11 15:04:16 --> Config Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:04:16 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:04:16 --> URI Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Router Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Output Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Security Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Input Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:04:16 --> Language Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Loader Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:04:16 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:04:16 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:04:16 --> Session Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:04:16 --> Session routines successfully run
DEBUG - 2013-04-11 15:04:16 --> Controller Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Language Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Config Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:04:16 --> Loader Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:04:16 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:04:16 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:04:16 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:16 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:04:16 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:04:16 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:04:16 --> Final output sent to browser
DEBUG - 2013-04-11 15:04:16 --> Total execution time: 0.0259
DEBUG - 2013-04-11 15:04:53 --> Config Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:04:53 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:04:53 --> URI Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Router Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Output Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Security Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Input Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:04:53 --> Language Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Loader Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:04:53 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:04:53 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:04:53 --> Session Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:04:53 --> Session routines successfully run
DEBUG - 2013-04-11 15:04:53 --> Controller Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Language Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Config Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:04:53 --> Loader Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:04:53 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:04:53 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:04:53 --> Model Class Initialized
DEBUG - 2013-04-11 15:04:53 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:04:53 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:04:53 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:04:53 --> Final output sent to browser
DEBUG - 2013-04-11 15:04:53 --> Total execution time: 0.0267
DEBUG - 2013-04-11 15:05:25 --> Config Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:05:25 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:05:25 --> URI Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Router Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Output Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Security Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Input Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:05:25 --> Language Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Loader Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:05:25 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:05:25 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:05:25 --> Session Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:05:25 --> Session routines successfully run
DEBUG - 2013-04-11 15:05:25 --> Controller Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Language Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Config Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:05:25 --> Loader Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Model Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Model Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:05:25 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:05:25 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:05:25 --> Model Class Initialized
DEBUG - 2013-04-11 15:05:25 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:05:25 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:05:25 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:05:25 --> Final output sent to browser
DEBUG - 2013-04-11 15:05:25 --> Total execution time: 0.0263
DEBUG - 2013-04-11 15:05:28 --> Config Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:05:28 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:05:28 --> URI Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Router Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Output Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Security Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Input Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:05:28 --> Language Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Loader Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:05:28 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:05:28 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:05:28 --> Session Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:05:28 --> Session routines successfully run
DEBUG - 2013-04-11 15:05:28 --> Controller Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Language Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Config Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:05:28 --> Loader Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Model Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Model Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:05:28 --> Model Class Initialized
DEBUG - 2013-04-11 15:05:28 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:05:28 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-11 15:05:28 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:05:28 --> Final output sent to browser
DEBUG - 2013-04-11 15:05:28 --> Total execution time: 0.0292
DEBUG - 2013-04-11 15:05:54 --> Config Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:05:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:05:54 --> URI Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Router Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Output Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Security Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Input Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:05:54 --> Language Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Loader Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:05:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:05:54 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:05:54 --> Session Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:05:54 --> Session routines successfully run
DEBUG - 2013-04-11 15:05:54 --> Controller Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Language Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Config Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:05:54 --> Loader Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Model Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Model Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Model Class Initialized
ERROR - 2013-04-11 15:05:54 --> Severity: Notice  --> Trying to get property of non-object /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 487
INFO  - 2013-04-11 15:05:54 --> O usuario cadastrou um novo usuário: teste
DEBUG - 2013-04-11 15:05:54 --> Final output sent to browser
DEBUG - 2013-04-11 15:05:54 --> Total execution time: 0.0279
DEBUG - 2013-04-11 15:05:54 --> Config Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:05:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:05:54 --> URI Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Router Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Output Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Security Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Input Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:05:54 --> Language Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Loader Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:05:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:05:54 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:05:54 --> Session Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:05:54 --> Session routines successfully run
DEBUG - 2013-04-11 15:05:54 --> Controller Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Language Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Config Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:05:54 --> Loader Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Model Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Model Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:05:54 --> Model Class Initialized
DEBUG - 2013-04-11 15:05:54 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:05:54 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-11 15:05:54 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:05:54 --> Final output sent to browser
DEBUG - 2013-04-11 15:05:54 --> Total execution time: 0.0270
DEBUG - 2013-04-11 15:06:02 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:06:02 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:06:02 --> URI Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Router Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Output Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Security Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Input Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:06:02 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:06:02 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:06:02 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:06:02 --> Session Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:06:02 --> Session routines successfully run
DEBUG - 2013-04-11 15:06:02 --> Controller Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:06:02 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:06:02 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:06:02 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:06:02 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:02 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:06:02 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:06:02 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:06:02 --> Final output sent to browser
DEBUG - 2013-04-11 15:06:02 --> Total execution time: 0.0265
DEBUG - 2013-04-11 15:06:04 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:06:04 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:06:04 --> URI Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Router Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Output Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Security Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Input Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:06:04 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:06:04 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:06:04 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:06:04 --> Session Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:06:04 --> Session routines successfully run
DEBUG - 2013-04-11 15:06:04 --> Controller Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:06:04 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Final output sent to browser
DEBUG - 2013-04-11 15:06:04 --> Total execution time: 0.0229
DEBUG - 2013-04-11 15:06:04 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:06:04 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:06:04 --> URI Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Router Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Output Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Security Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Input Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:06:04 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:06:04 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:06:04 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:06:04 --> Session Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:06:04 --> Session routines successfully run
DEBUG - 2013-04-11 15:06:04 --> Controller Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:06:04 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:06:04 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:06:04 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:06:04 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:04 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:06:04 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:06:04 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:06:04 --> Final output sent to browser
DEBUG - 2013-04-11 15:06:04 --> Total execution time: 0.0316
DEBUG - 2013-04-11 15:06:08 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:06:08 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:06:08 --> URI Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Router Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Output Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Security Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Input Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:06:08 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:06:08 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:06:08 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:06:08 --> Session Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:06:08 --> Session routines successfully run
DEBUG - 2013-04-11 15:06:08 --> Controller Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:06:08 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Final output sent to browser
DEBUG - 2013-04-11 15:06:08 --> Total execution time: 0.0233
DEBUG - 2013-04-11 15:06:08 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:06:08 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:06:08 --> URI Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Router Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Output Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Security Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Input Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:06:08 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:06:08 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:06:08 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:06:08 --> Session Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:06:08 --> Session routines successfully run
DEBUG - 2013-04-11 15:06:08 --> Controller Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:06:08 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:06:08 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:06:08 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:06:08 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:08 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:06:08 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:06:08 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:06:08 --> Final output sent to browser
DEBUG - 2013-04-11 15:06:08 --> Total execution time: 0.0283
DEBUG - 2013-04-11 15:06:10 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:10 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:06:10 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:06:10 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:06:10 --> URI Class Initialized
DEBUG - 2013-04-11 15:06:10 --> Router Class Initialized
DEBUG - 2013-04-11 15:06:10 --> Output Class Initialized
DEBUG - 2013-04-11 15:06:10 --> Security Class Initialized
DEBUG - 2013-04-11 15:06:10 --> Input Class Initialized
DEBUG - 2013-04-11 15:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:06:10 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:10 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:10 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:06:10 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:06:10 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:06:10 --> Session Class Initialized
DEBUG - 2013-04-11 15:06:10 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:06:10 --> Session routines successfully run
DEBUG - 2013-04-11 15:06:10 --> Controller Class Initialized
DEBUG - 2013-04-11 15:06:10 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:10 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:10 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:06:10 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:10 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:10 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:10 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:06:10 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:06:10 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 15:06:10 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:06:10 --> Final output sent to browser
DEBUG - 2013-04-11 15:06:10 --> Total execution time: 0.0267
DEBUG - 2013-04-11 15:06:16 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:06:16 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:06:16 --> URI Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Router Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Output Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Security Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Input Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:06:16 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:06:16 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:06:16 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:06:16 --> Session Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:06:16 --> Session routines successfully run
DEBUG - 2013-04-11 15:06:16 --> Controller Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:06:16 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Final output sent to browser
DEBUG - 2013-04-11 15:06:16 --> Total execution time: 0.0269
DEBUG - 2013-04-11 15:06:16 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:06:16 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:06:16 --> URI Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Router Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Output Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Security Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Input Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:06:16 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:06:16 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:06:16 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:06:16 --> Session Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:06:16 --> Session routines successfully run
DEBUG - 2013-04-11 15:06:16 --> Controller Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:06:16 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:06:16 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:06:16 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:06:16 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:16 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:06:16 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:06:16 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:06:16 --> Final output sent to browser
DEBUG - 2013-04-11 15:06:16 --> Total execution time: 0.0274
DEBUG - 2013-04-11 15:06:18 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:06:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:06:18 --> URI Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Router Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Output Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Security Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Input Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:06:18 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:06:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:06:18 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:06:18 --> Session Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:06:18 --> Session routines successfully run
DEBUG - 2013-04-11 15:06:18 --> Controller Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:06:18 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:06:18 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:06:18 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:06:18 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:18 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:06:18 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:06:18 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:06:18 --> Final output sent to browser
DEBUG - 2013-04-11 15:06:18 --> Total execution time: 0.0299
DEBUG - 2013-04-11 15:06:21 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:21 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:06:21 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:06:21 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:06:21 --> URI Class Initialized
DEBUG - 2013-04-11 15:06:21 --> Router Class Initialized
DEBUG - 2013-04-11 15:06:21 --> Output Class Initialized
DEBUG - 2013-04-11 15:06:21 --> Security Class Initialized
DEBUG - 2013-04-11 15:06:21 --> Input Class Initialized
DEBUG - 2013-04-11 15:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:06:21 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:21 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:21 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:06:21 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:06:21 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:06:21 --> Session Class Initialized
DEBUG - 2013-04-11 15:06:21 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:06:21 --> Session routines successfully run
DEBUG - 2013-04-11 15:06:21 --> Controller Class Initialized
DEBUG - 2013-04-11 15:06:21 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:21 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:21 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:06:21 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:21 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:21 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:21 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:06:21 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:06:21 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusaoPermanente.php
DEBUG - 2013-04-11 15:06:21 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:06:21 --> Final output sent to browser
DEBUG - 2013-04-11 15:06:21 --> Total execution time: 0.0260
DEBUG - 2013-04-11 15:06:27 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:06:27 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:06:27 --> URI Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Router Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Output Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Security Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Input Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:06:27 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:06:27 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:06:27 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:06:27 --> Session Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:06:27 --> Session routines successfully run
DEBUG - 2013-04-11 15:06:27 --> Controller Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:06:27 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Final output sent to browser
DEBUG - 2013-04-11 15:06:27 --> Total execution time: 0.0265
DEBUG - 2013-04-11 15:06:27 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:06:27 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:06:27 --> URI Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Router Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Output Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Security Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Input Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:06:27 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:06:27 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:06:27 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:06:27 --> Session Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:06:27 --> Session routines successfully run
DEBUG - 2013-04-11 15:06:27 --> Controller Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:06:27 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:06:27 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:06:27 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:06:27 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:27 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:06:27 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:06:27 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:06:27 --> Final output sent to browser
DEBUG - 2013-04-11 15:06:27 --> Total execution time: 0.0261
DEBUG - 2013-04-11 15:06:31 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:06:31 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:06:31 --> URI Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Router Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Output Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Security Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Input Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:06:31 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:06:31 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:06:31 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:06:31 --> Session Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:06:31 --> Session routines successfully run
DEBUG - 2013-04-11 15:06:31 --> Controller Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:06:31 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:06:31 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:31 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:06:31 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-11 15:06:31 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:06:31 --> Final output sent to browser
DEBUG - 2013-04-11 15:06:31 --> Total execution time: 0.0292
DEBUG - 2013-04-11 15:06:34 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:06:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:06:34 --> URI Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Router Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Output Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Security Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Input Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:06:34 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:06:34 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:06:34 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:06:34 --> Session Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:06:34 --> Session routines successfully run
DEBUG - 2013-04-11 15:06:34 --> Controller Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:06:34 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:06:34 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:06:34 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:06:34 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:34 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:06:34 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:06:34 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:06:34 --> Final output sent to browser
DEBUG - 2013-04-11 15:06:34 --> Total execution time: 0.0303
DEBUG - 2013-04-11 15:06:38 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:06:38 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:06:38 --> URI Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Router Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Output Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Security Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Input Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:06:38 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:06:38 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:06:38 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:06:38 --> Session Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:06:38 --> Session routines successfully run
DEBUG - 2013-04-11 15:06:38 --> Controller Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Language Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Config Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:06:38 --> Loader Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:06:38 --> Model Class Initialized
DEBUG - 2013-04-11 15:06:38 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:06:38 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-11 15:06:38 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:06:38 --> Final output sent to browser
DEBUG - 2013-04-11 15:06:38 --> Total execution time: 0.0303
DEBUG - 2013-04-11 15:07:02 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:07:02 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:07:02 --> URI Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Router Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Output Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Security Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Input Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:07:02 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:07:02 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:07:02 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:07:02 --> Session Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:07:02 --> Session routines successfully run
DEBUG - 2013-04-11 15:07:02 --> Controller Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:07:02 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Model Class Initialized
ERROR - 2013-04-11 15:07:02 --> Severity: Notice  --> Trying to get property of non-object /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 487
INFO  - 2013-04-11 15:07:02 --> O usuario cadastrou um novo usuário: Luiz Picolo
DEBUG - 2013-04-11 15:07:02 --> Final output sent to browser
DEBUG - 2013-04-11 15:07:02 --> Total execution time: 0.0293
DEBUG - 2013-04-11 15:07:02 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:07:02 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:07:02 --> URI Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Router Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Output Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Security Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Input Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:07:02 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:07:02 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:07:02 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:07:02 --> Session Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:07:02 --> Session routines successfully run
DEBUG - 2013-04-11 15:07:02 --> Controller Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:07:02 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:07:02 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:02 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:07:02 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-11 15:07:02 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:07:02 --> Final output sent to browser
DEBUG - 2013-04-11 15:07:02 --> Total execution time: 0.0266
DEBUG - 2013-04-11 15:07:23 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:07:23 --> URI Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Router Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Output Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Security Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Input Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:07:23 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:07:23 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:07:23 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:07:23 --> Session Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:07:23 --> Session routines successfully run
DEBUG - 2013-04-11 15:07:23 --> Controller Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:07:23 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Model Class Initialized
ERROR - 2013-04-11 15:07:23 --> Severity: Notice  --> Trying to get property of non-object /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 487
INFO  - 2013-04-11 15:07:23 --> O usuario cadastrou um novo usuário: testetse
DEBUG - 2013-04-11 15:07:23 --> Final output sent to browser
DEBUG - 2013-04-11 15:07:23 --> Total execution time: 0.0277
DEBUG - 2013-04-11 15:07:23 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:07:23 --> URI Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Router Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Output Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Security Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Input Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:07:23 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:07:23 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:07:23 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:07:23 --> Session Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:07:23 --> Session routines successfully run
DEBUG - 2013-04-11 15:07:23 --> Controller Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:07:23 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:07:23 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:23 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:07:23 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-11 15:07:23 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:07:23 --> Final output sent to browser
DEBUG - 2013-04-11 15:07:23 --> Total execution time: 0.0308
DEBUG - 2013-04-11 15:07:30 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:07:30 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:07:30 --> URI Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Router Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Output Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Security Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Input Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:07:30 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:07:30 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:07:30 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:07:30 --> Session Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:07:30 --> Session routines successfully run
DEBUG - 2013-04-11 15:07:30 --> Controller Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:07:30 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:07:30 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:07:30 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:07:30 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:30 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:07:30 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:07:30 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:07:30 --> Final output sent to browser
DEBUG - 2013-04-11 15:07:30 --> Total execution time: 0.0293
DEBUG - 2013-04-11 15:07:33 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:33 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:07:33 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:07:33 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:07:33 --> URI Class Initialized
DEBUG - 2013-04-11 15:07:33 --> Router Class Initialized
DEBUG - 2013-04-11 15:07:33 --> Output Class Initialized
DEBUG - 2013-04-11 15:07:33 --> Security Class Initialized
DEBUG - 2013-04-11 15:07:33 --> Input Class Initialized
DEBUG - 2013-04-11 15:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:07:33 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:33 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:33 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:07:33 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:07:33 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:07:33 --> Session Class Initialized
DEBUG - 2013-04-11 15:07:33 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:07:33 --> Session routines successfully run
DEBUG - 2013-04-11 15:07:33 --> Controller Class Initialized
DEBUG - 2013-04-11 15:07:33 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:33 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:33 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:07:33 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:33 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:33 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:33 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:07:33 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:07:33 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 15:07:33 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:07:33 --> Final output sent to browser
DEBUG - 2013-04-11 15:07:33 --> Total execution time: 0.0262
DEBUG - 2013-04-11 15:07:37 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:07:37 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:07:37 --> URI Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Router Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Output Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Security Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Input Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:07:37 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:07:37 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:07:37 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:07:37 --> Session Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:07:37 --> Session routines successfully run
DEBUG - 2013-04-11 15:07:37 --> Controller Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:07:37 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Final output sent to browser
DEBUG - 2013-04-11 15:07:37 --> Total execution time: 0.0266
DEBUG - 2013-04-11 15:07:37 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:07:37 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:07:37 --> URI Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Router Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Output Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Security Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Input Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:07:37 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:07:37 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:07:37 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:07:37 --> Session Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:07:37 --> Session routines successfully run
DEBUG - 2013-04-11 15:07:37 --> Controller Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:07:37 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:07:37 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:07:37 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:07:37 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:37 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:07:37 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:07:37 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:07:37 --> Final output sent to browser
DEBUG - 2013-04-11 15:07:37 --> Total execution time: 0.0277
DEBUG - 2013-04-11 15:07:39 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:39 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:07:39 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:07:39 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:07:39 --> URI Class Initialized
DEBUG - 2013-04-11 15:07:39 --> Router Class Initialized
DEBUG - 2013-04-11 15:07:39 --> Output Class Initialized
DEBUG - 2013-04-11 15:07:39 --> Security Class Initialized
DEBUG - 2013-04-11 15:07:39 --> Input Class Initialized
DEBUG - 2013-04-11 15:07:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:07:39 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:39 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:39 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:07:39 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:07:39 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:07:39 --> Session Class Initialized
DEBUG - 2013-04-11 15:07:39 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:07:39 --> Session routines successfully run
DEBUG - 2013-04-11 15:07:39 --> Controller Class Initialized
DEBUG - 2013-04-11 15:07:39 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:39 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:39 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:07:39 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:39 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:39 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:39 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:07:39 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:07:39 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 15:07:39 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:07:39 --> Final output sent to browser
DEBUG - 2013-04-11 15:07:39 --> Total execution time: 0.0298
DEBUG - 2013-04-11 15:07:43 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:07:43 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:07:43 --> URI Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Router Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Output Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Security Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Input Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:07:43 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:07:43 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:07:43 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:07:43 --> Session Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:07:43 --> Session routines successfully run
DEBUG - 2013-04-11 15:07:43 --> Controller Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:07:43 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Final output sent to browser
DEBUG - 2013-04-11 15:07:43 --> Total execution time: 0.0274
DEBUG - 2013-04-11 15:07:43 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:07:43 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:07:43 --> URI Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Router Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Output Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Security Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Input Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:07:43 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:07:43 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:07:43 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:07:43 --> Session Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:07:43 --> Session routines successfully run
DEBUG - 2013-04-11 15:07:43 --> Controller Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:07:43 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:07:43 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:07:43 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:07:43 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:43 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:07:43 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:07:43 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:07:43 --> Final output sent to browser
DEBUG - 2013-04-11 15:07:43 --> Total execution time: 0.0263
DEBUG - 2013-04-11 15:07:56 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:07:56 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:07:56 --> URI Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Router Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Output Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Security Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Input Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:07:56 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:07:56 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:07:56 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:07:56 --> Session Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:07:56 --> Session routines successfully run
DEBUG - 2013-04-11 15:07:56 --> Controller Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Language Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Config Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:07:56 --> Loader Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:07:56 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:07:56 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:07:56 --> Model Class Initialized
DEBUG - 2013-04-11 15:07:56 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:07:56 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:07:56 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:07:56 --> Final output sent to browser
DEBUG - 2013-04-11 15:07:56 --> Total execution time: 0.0287
DEBUG - 2013-04-11 15:27:33 --> Config Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:27:33 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:27:33 --> URI Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Router Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Output Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Security Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Input Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:27:33 --> Language Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Loader Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:27:33 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:27:33 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:27:33 --> Session Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:27:33 --> Session routines successfully run
DEBUG - 2013-04-11 15:27:33 --> Controller Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Language Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Config Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:27:33 --> Loader Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Model Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Model Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:27:33 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:27:33 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:27:33 --> Model Class Initialized
DEBUG - 2013-04-11 15:27:33 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:27:33 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:27:33 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:27:33 --> Final output sent to browser
DEBUG - 2013-04-11 15:27:33 --> Total execution time: 0.0311
DEBUG - 2013-04-11 15:27:35 --> Config Class Initialized
DEBUG - 2013-04-11 15:27:35 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:27:35 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:27:35 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:27:35 --> URI Class Initialized
DEBUG - 2013-04-11 15:27:35 --> Router Class Initialized
DEBUG - 2013-04-11 15:27:35 --> No URI present. Default controller set.
DEBUG - 2013-04-11 15:27:35 --> Output Class Initialized
DEBUG - 2013-04-11 15:27:35 --> Security Class Initialized
DEBUG - 2013-04-11 15:27:35 --> Input Class Initialized
DEBUG - 2013-04-11 15:27:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:27:35 --> Language Class Initialized
DEBUG - 2013-04-11 15:27:35 --> Loader Class Initialized
DEBUG - 2013-04-11 15:27:35 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:27:35 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:27:35 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:27:35 --> Session Class Initialized
DEBUG - 2013-04-11 15:27:35 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:27:35 --> Session routines successfully run
DEBUG - 2013-04-11 15:27:35 --> Controller Class Initialized
DEBUG - 2013-04-11 15:27:35 --> Language Class Initialized
DEBUG - 2013-04-11 15:27:35 --> Config Class Initialized
DEBUG - 2013-04-11 15:27:35 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-11 15:27:35 --> Loader Class Initialized
DEBUG - 2013-04-11 15:27:35 --> File loaded: ../application/admin/modules/autenticacao/views/login.php
DEBUG - 2013-04-11 15:27:35 --> Final output sent to browser
DEBUG - 2013-04-11 15:27:35 --> Total execution time: 0.0179
DEBUG - 2013-04-11 15:27:40 --> Config Class Initialized
DEBUG - 2013-04-11 15:27:40 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:27:40 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:27:40 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:27:40 --> URI Class Initialized
DEBUG - 2013-04-11 15:27:40 --> Router Class Initialized
DEBUG - 2013-04-11 15:27:40 --> Output Class Initialized
DEBUG - 2013-04-11 15:27:40 --> Security Class Initialized
DEBUG - 2013-04-11 15:27:40 --> Input Class Initialized
DEBUG - 2013-04-11 15:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:27:40 --> Language Class Initialized
DEBUG - 2013-04-11 15:27:40 --> Loader Class Initialized
DEBUG - 2013-04-11 15:27:40 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:27:40 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:27:40 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:27:40 --> Session Class Initialized
DEBUG - 2013-04-11 15:27:40 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:27:40 --> Session routines successfully run
DEBUG - 2013-04-11 15:27:40 --> Controller Class Initialized
DEBUG - 2013-04-11 15:27:40 --> Language Class Initialized
DEBUG - 2013-04-11 15:27:40 --> Config Class Initialized
DEBUG - 2013-04-11 15:27:40 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-11 15:27:40 --> Loader Class Initialized
DEBUG - 2013-04-11 15:27:40 --> Model Class Initialized
DEBUG - 2013-04-11 15:27:40 --> Model Class Initialized
DEBUG - 2013-04-11 15:27:40 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:27:41 --> Model Class Initialized
ERROR - 2013-04-11 15:27:41 --> Severity: Notice  --> Undefined index: orlike /home/w3case/public_html/target-git/application/admin/models/crud.php 121
ERROR - 2013-04-11 15:27:41 --> Severity: Notice  --> Undefined index: orlike /home/w3case/public_html/target-git/application/admin/models/crud.php 121
DEBUG - 2013-04-11 15:27:41 --> Final output sent to browser
DEBUG - 2013-04-11 15:27:41 --> Total execution time: 1.2177
DEBUG - 2013-04-11 15:27:41 --> Config Class Initialized
DEBUG - 2013-04-11 15:27:41 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:27:41 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:27:41 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:27:41 --> URI Class Initialized
DEBUG - 2013-04-11 15:27:41 --> Router Class Initialized
DEBUG - 2013-04-11 15:27:41 --> Output Class Initialized
DEBUG - 2013-04-11 15:27:41 --> Security Class Initialized
DEBUG - 2013-04-11 15:27:41 --> Input Class Initialized
DEBUG - 2013-04-11 15:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:27:41 --> Language Class Initialized
DEBUG - 2013-04-11 15:27:41 --> Loader Class Initialized
DEBUG - 2013-04-11 15:27:41 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:27:41 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:27:41 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:27:41 --> Session Class Initialized
DEBUG - 2013-04-11 15:27:41 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:27:41 --> Session routines successfully run
DEBUG - 2013-04-11 15:27:41 --> Controller Class Initialized
DEBUG - 2013-04-11 15:27:41 --> Language Class Initialized
DEBUG - 2013-04-11 15:27:41 --> Config Class Initialized
DEBUG - 2013-04-11 15:27:41 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-11 15:27:41 --> Loader Class Initialized
DEBUG - 2013-04-11 15:27:41 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-11 15:27:41 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:27:41 --> Final output sent to browser
DEBUG - 2013-04-11 15:27:41 --> Total execution time: 0.0158
DEBUG - 2013-04-11 15:27:43 --> Config Class Initialized
DEBUG - 2013-04-11 15:27:43 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:27:43 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:27:43 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:27:43 --> URI Class Initialized
DEBUG - 2013-04-11 15:27:43 --> Router Class Initialized
DEBUG - 2013-04-11 15:27:43 --> Output Class Initialized
DEBUG - 2013-04-11 15:27:43 --> Security Class Initialized
DEBUG - 2013-04-11 15:27:43 --> Input Class Initialized
DEBUG - 2013-04-11 15:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:27:43 --> Language Class Initialized
DEBUG - 2013-04-11 15:27:43 --> Loader Class Initialized
DEBUG - 2013-04-11 15:27:43 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:27:43 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:27:43 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:27:43 --> Session Class Initialized
DEBUG - 2013-04-11 15:27:43 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:27:43 --> Session routines successfully run
DEBUG - 2013-04-11 15:27:43 --> Controller Class Initialized
DEBUG - 2013-04-11 15:27:43 --> Language Class Initialized
DEBUG - 2013-04-11 15:27:43 --> Config Class Initialized
DEBUG - 2013-04-11 15:27:43 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:27:43 --> Loader Class Initialized
DEBUG - 2013-04-11 15:27:43 --> Model Class Initialized
DEBUG - 2013-04-11 15:27:43 --> Model Class Initialized
DEBUG - 2013-04-11 15:27:43 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:27:43 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:27:43 --> File loaded: ../application/admin/modules/usuarios/views/usuarios.php
DEBUG - 2013-04-11 15:27:43 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:27:43 --> Final output sent to browser
DEBUG - 2013-04-11 15:27:43 --> Total execution time: 0.0228
DEBUG - 2013-04-11 15:27:44 --> Config Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:27:44 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:27:44 --> URI Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Router Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Output Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Security Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Input Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:27:44 --> Language Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Loader Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:27:44 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:27:44 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:27:44 --> Session Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:27:44 --> Session routines successfully run
DEBUG - 2013-04-11 15:27:44 --> Controller Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Language Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Config Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:27:44 --> Loader Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Model Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Model Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:27:44 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:27:44 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:27:44 --> Model Class Initialized
DEBUG - 2013-04-11 15:27:44 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:27:44 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:27:44 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:27:44 --> Final output sent to browser
DEBUG - 2013-04-11 15:27:44 --> Total execution time: 0.0274
DEBUG - 2013-04-11 15:27:46 --> Config Class Initialized
DEBUG - 2013-04-11 15:27:46 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:27:46 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:27:46 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:27:46 --> URI Class Initialized
DEBUG - 2013-04-11 15:27:46 --> Router Class Initialized
DEBUG - 2013-04-11 15:27:46 --> No URI present. Default controller set.
DEBUG - 2013-04-11 15:27:46 --> Output Class Initialized
DEBUG - 2013-04-11 15:27:46 --> Security Class Initialized
DEBUG - 2013-04-11 15:27:46 --> Input Class Initialized
DEBUG - 2013-04-11 15:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:27:46 --> Language Class Initialized
DEBUG - 2013-04-11 15:27:46 --> Loader Class Initialized
DEBUG - 2013-04-11 15:27:46 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:27:46 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:27:46 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:27:46 --> Session Class Initialized
DEBUG - 2013-04-11 15:27:46 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:27:46 --> Session routines successfully run
DEBUG - 2013-04-11 15:27:46 --> Controller Class Initialized
DEBUG - 2013-04-11 15:27:46 --> Language Class Initialized
DEBUG - 2013-04-11 15:27:46 --> Config Class Initialized
DEBUG - 2013-04-11 15:27:46 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-11 15:27:46 --> Loader Class Initialized
DEBUG - 2013-04-11 15:27:46 --> File loaded: ../application/admin/modules/autenticacao/views/login.php
DEBUG - 2013-04-11 15:27:46 --> Final output sent to browser
DEBUG - 2013-04-11 15:27:46 --> Total execution time: 0.0173
DEBUG - 2013-04-11 15:28:32 --> Config Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:28:32 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:28:32 --> URI Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Router Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Output Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Security Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Input Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:28:32 --> Language Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Loader Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:28:32 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:28:32 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:28:32 --> Session Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:28:32 --> Session routines successfully run
DEBUG - 2013-04-11 15:28:32 --> Controller Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Language Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Config Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:28:32 --> Loader Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Model Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Model Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:28:32 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:28:32 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:28:32 --> Model Class Initialized
DEBUG - 2013-04-11 15:28:32 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:28:32 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:28:32 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:28:32 --> Final output sent to browser
DEBUG - 2013-04-11 15:28:32 --> Total execution time: 0.0316
DEBUG - 2013-04-11 15:28:45 --> Config Class Initialized
DEBUG - 2013-04-11 15:28:45 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:28:45 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:28:45 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:28:45 --> URI Class Initialized
DEBUG - 2013-04-11 15:28:45 --> Router Class Initialized
DEBUG - 2013-04-11 15:28:45 --> Output Class Initialized
DEBUG - 2013-04-11 15:28:45 --> Security Class Initialized
DEBUG - 2013-04-11 15:28:45 --> Input Class Initialized
DEBUG - 2013-04-11 15:28:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:28:45 --> Language Class Initialized
DEBUG - 2013-04-11 15:28:45 --> Loader Class Initialized
DEBUG - 2013-04-11 15:28:45 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:28:45 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:28:45 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:28:45 --> Session Class Initialized
DEBUG - 2013-04-11 15:28:45 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:28:45 --> Session routines successfully run
DEBUG - 2013-04-11 15:28:45 --> Controller Class Initialized
DEBUG - 2013-04-11 15:28:45 --> Language Class Initialized
DEBUG - 2013-04-11 15:28:45 --> Config Class Initialized
DEBUG - 2013-04-11 15:28:45 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:28:45 --> Loader Class Initialized
DEBUG - 2013-04-11 15:28:45 --> Model Class Initialized
DEBUG - 2013-04-11 15:28:45 --> Model Class Initialized
DEBUG - 2013-04-11 15:28:45 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:28:45 --> Severity: Notice  --> Undefined property: CI::$crud /home/w3case/public_html/target-git/application/admin/third_party/MX/Controller.php 57
DEBUG - 2013-04-11 15:29:57 --> Config Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:29:57 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:29:57 --> URI Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Router Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Output Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Security Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Input Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:29:57 --> Language Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Loader Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:29:57 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:29:57 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:29:57 --> Session Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:29:57 --> Session routines successfully run
DEBUG - 2013-04-11 15:29:57 --> Controller Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Language Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Config Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:29:57 --> Loader Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Model Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Model Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Model Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Final output sent to browser
DEBUG - 2013-04-11 15:29:57 --> Total execution time: 0.0267
DEBUG - 2013-04-11 15:29:57 --> Config Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:29:57 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:29:57 --> URI Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Router Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Output Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Security Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Input Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:29:57 --> Language Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Loader Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:29:57 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:29:57 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:29:57 --> Session Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:29:57 --> Session routines successfully run
DEBUG - 2013-04-11 15:29:57 --> Controller Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Language Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Config Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:29:57 --> Loader Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Model Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Model Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:29:57 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:29:57 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:29:57 --> Model Class Initialized
DEBUG - 2013-04-11 15:29:57 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:29:57 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:29:57 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:29:57 --> Final output sent to browser
DEBUG - 2013-04-11 15:29:57 --> Total execution time: 0.0289
DEBUG - 2013-04-11 15:30:02 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:30:02 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:30:02 --> URI Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Router Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Output Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Security Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Input Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:30:02 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:30:02 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:30:02 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:30:02 --> Session Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:30:02 --> Session routines successfully run
DEBUG - 2013-04-11 15:30:02 --> Controller Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:30:02 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:30:02 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:30:02 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:30:02 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:02 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:30:02 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:30:02 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:30:02 --> Final output sent to browser
DEBUG - 2013-04-11 15:30:02 --> Total execution time: 0.0255
DEBUG - 2013-04-11 15:30:04 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:30:04 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:30:04 --> URI Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Router Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Output Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Security Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Input Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:30:04 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:30:04 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:30:04 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:30:04 --> Session Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:30:04 --> Session routines successfully run
DEBUG - 2013-04-11 15:30:04 --> Controller Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:30:04 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Final output sent to browser
DEBUG - 2013-04-11 15:30:04 --> Total execution time: 0.0266
DEBUG - 2013-04-11 15:30:04 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:30:04 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:30:04 --> URI Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Router Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Output Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Security Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Input Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:30:04 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:30:04 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:30:04 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:30:04 --> Session Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:30:04 --> Session routines successfully run
DEBUG - 2013-04-11 15:30:04 --> Controller Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:30:04 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:30:04 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:30:04 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:30:04 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:04 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:30:04 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:30:04 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:30:04 --> Final output sent to browser
DEBUG - 2013-04-11 15:30:04 --> Total execution time: 0.0259
DEBUG - 2013-04-11 15:30:15 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:30:15 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:30:15 --> URI Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Router Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Output Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Security Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Input Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:30:15 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:30:15 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:30:15 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:30:15 --> Session Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:30:15 --> Session routines successfully run
DEBUG - 2013-04-11 15:30:15 --> Controller Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:30:15 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:30:15 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:30:15 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:30:15 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:15 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:30:15 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:30:15 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:30:15 --> Final output sent to browser
DEBUG - 2013-04-11 15:30:15 --> Total execution time: 0.0375
DEBUG - 2013-04-11 15:30:17 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:30:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:30:17 --> URI Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Router Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Output Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Security Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Input Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:30:17 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:30:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:30:17 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:30:17 --> Session Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:30:17 --> Session routines successfully run
DEBUG - 2013-04-11 15:30:17 --> Controller Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:30:17 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Final output sent to browser
DEBUG - 2013-04-11 15:30:17 --> Total execution time: 0.0287
DEBUG - 2013-04-11 15:30:17 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:30:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:30:17 --> URI Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Router Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Output Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Security Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Input Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:30:17 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:30:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:30:17 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:30:17 --> Session Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:30:17 --> Session routines successfully run
DEBUG - 2013-04-11 15:30:17 --> Controller Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:30:17 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:30:17 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:30:17 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:30:17 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:17 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:30:17 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:30:17 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:30:17 --> Final output sent to browser
DEBUG - 2013-04-11 15:30:17 --> Total execution time: 0.0273
DEBUG - 2013-04-11 15:30:27 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:30:27 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:30:27 --> URI Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Router Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Output Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Security Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Input Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:30:27 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:30:27 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:30:27 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:30:27 --> Session Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:30:27 --> Session routines successfully run
DEBUG - 2013-04-11 15:30:27 --> Controller Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:30:27 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:30:27 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:30:27 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:30:27 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:27 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:30:27 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:30:27 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:30:27 --> Final output sent to browser
DEBUG - 2013-04-11 15:30:27 --> Total execution time: 0.0282
DEBUG - 2013-04-11 15:30:29 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:29 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:30:29 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:30:29 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:30:29 --> URI Class Initialized
DEBUG - 2013-04-11 15:30:29 --> Router Class Initialized
DEBUG - 2013-04-11 15:30:29 --> Output Class Initialized
DEBUG - 2013-04-11 15:30:29 --> Security Class Initialized
DEBUG - 2013-04-11 15:30:29 --> Input Class Initialized
DEBUG - 2013-04-11 15:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:30:29 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:29 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:29 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:30:29 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:30:29 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:30:29 --> Session Class Initialized
DEBUG - 2013-04-11 15:30:29 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:30:29 --> Session routines successfully run
DEBUG - 2013-04-11 15:30:29 --> Controller Class Initialized
DEBUG - 2013-04-11 15:30:29 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:29 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:29 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:30:29 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:29 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:29 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:29 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:30:29 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:30:29 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusaoPermanente.php
DEBUG - 2013-04-11 15:30:29 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:30:29 --> Final output sent to browser
DEBUG - 2013-04-11 15:30:29 --> Total execution time: 0.0273
DEBUG - 2013-04-11 15:30:32 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:30:32 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:30:32 --> URI Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Router Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Output Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Security Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Input Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:30:32 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:30:32 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:30:32 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:30:32 --> Session Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:30:32 --> Session routines successfully run
DEBUG - 2013-04-11 15:30:32 --> Controller Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:30:32 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Final output sent to browser
DEBUG - 2013-04-11 15:30:32 --> Total execution time: 0.0286
DEBUG - 2013-04-11 15:30:32 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:30:32 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:30:32 --> URI Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Router Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Output Class Initialized
DEBUG - 2013-04-11 15:30:32 --> Security Class Initialized
DEBUG - 2013-04-11 15:30:33 --> Input Class Initialized
DEBUG - 2013-04-11 15:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:30:33 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:33 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:33 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:30:33 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:30:33 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:30:33 --> Session Class Initialized
DEBUG - 2013-04-11 15:30:33 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:30:33 --> Session routines successfully run
DEBUG - 2013-04-11 15:30:33 --> Controller Class Initialized
DEBUG - 2013-04-11 15:30:33 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:33 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:33 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:30:33 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:33 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:33 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:33 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:30:33 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:30:33 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:30:33 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:33 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:30:33 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:30:33 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:30:33 --> Final output sent to browser
DEBUG - 2013-04-11 15:30:33 --> Total execution time: 0.0299
DEBUG - 2013-04-11 15:30:34 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:30:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:30:34 --> URI Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Router Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Output Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Security Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Input Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:30:34 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:30:34 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:30:34 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:30:34 --> Session Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:30:34 --> Session routines successfully run
DEBUG - 2013-04-11 15:30:34 --> Controller Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:30:34 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:30:34 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:30:34 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:30:34 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:34 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:30:34 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:30:34 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:30:34 --> Final output sent to browser
DEBUG - 2013-04-11 15:30:34 --> Total execution time: 0.0274
DEBUG - 2013-04-11 15:30:37 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:37 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:30:37 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:30:37 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:30:37 --> URI Class Initialized
DEBUG - 2013-04-11 15:30:37 --> Router Class Initialized
DEBUG - 2013-04-11 15:30:37 --> Output Class Initialized
DEBUG - 2013-04-11 15:30:37 --> Security Class Initialized
DEBUG - 2013-04-11 15:30:37 --> Input Class Initialized
DEBUG - 2013-04-11 15:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:30:37 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:37 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:37 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:30:37 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:30:37 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:30:37 --> Session Class Initialized
DEBUG - 2013-04-11 15:30:37 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:30:37 --> Session routines successfully run
DEBUG - 2013-04-11 15:30:37 --> Controller Class Initialized
DEBUG - 2013-04-11 15:30:37 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:37 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:37 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:30:37 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:37 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:37 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:37 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:30:37 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:30:37 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusao.php
DEBUG - 2013-04-11 15:30:37 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:30:37 --> Final output sent to browser
DEBUG - 2013-04-11 15:30:37 --> Total execution time: 0.0239
DEBUG - 2013-04-11 15:30:41 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:30:41 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:30:41 --> URI Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Router Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Output Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Security Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Input Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:30:41 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:30:41 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:30:41 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:30:41 --> Session Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:30:41 --> Session routines successfully run
DEBUG - 2013-04-11 15:30:41 --> Controller Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:30:41 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Final output sent to browser
DEBUG - 2013-04-11 15:30:41 --> Total execution time: 0.0272
DEBUG - 2013-04-11 15:30:41 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:30:41 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:30:41 --> URI Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Router Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Output Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Security Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Input Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:30:41 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:30:41 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:30:41 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:30:41 --> Session Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:30:41 --> Session routines successfully run
DEBUG - 2013-04-11 15:30:41 --> Controller Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Language Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Config Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:30:41 --> Loader Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:30:41 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:30:41 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:30:41 --> Model Class Initialized
DEBUG - 2013-04-11 15:30:41 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:30:41 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:30:41 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:30:41 --> Final output sent to browser
DEBUG - 2013-04-11 15:30:41 --> Total execution time: 0.0256
DEBUG - 2013-04-11 15:32:51 --> Config Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:32:51 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:32:51 --> URI Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Router Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Output Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Security Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Input Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:32:51 --> Language Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Loader Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:32:51 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:32:51 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:32:51 --> Session Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:32:51 --> Session routines successfully run
DEBUG - 2013-04-11 15:32:51 --> Controller Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Language Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Config Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:32:51 --> Loader Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Model Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Model Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:32:51 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:32:51 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:32:51 --> Model Class Initialized
DEBUG - 2013-04-11 15:32:51 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:32:51 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:32:51 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:32:51 --> Final output sent to browser
DEBUG - 2013-04-11 15:32:51 --> Total execution time: 0.0312
DEBUG - 2013-04-11 15:32:53 --> Config Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:32:53 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:32:53 --> URI Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Router Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Output Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Security Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Input Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:32:53 --> Language Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Loader Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:32:53 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:32:53 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:32:53 --> Session Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:32:53 --> Session routines successfully run
DEBUG - 2013-04-11 15:32:53 --> Controller Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Language Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Config Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:32:53 --> Loader Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Model Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Model Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:32:53 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:32:53 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:32:53 --> Model Class Initialized
DEBUG - 2013-04-11 15:32:53 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:32:53 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:32:53 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:32:53 --> Final output sent to browser
DEBUG - 2013-04-11 15:32:53 --> Total execution time: 0.0276
DEBUG - 2013-04-11 15:32:54 --> Config Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:32:54 --> URI Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Router Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Output Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Security Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Input Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:32:54 --> Language Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Loader Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:32:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:32:54 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:32:54 --> Session Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:32:54 --> Session routines successfully run
DEBUG - 2013-04-11 15:32:54 --> Controller Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Language Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Config Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:32:54 --> Loader Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Model Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Model Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:32:54 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:32:54 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:32:54 --> Model Class Initialized
DEBUG - 2013-04-11 15:32:54 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:32:54 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:32:54 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:32:54 --> Final output sent to browser
DEBUG - 2013-04-11 15:32:54 --> Total execution time: 0.0285
DEBUG - 2013-04-11 15:32:57 --> Config Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:32:57 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:32:57 --> URI Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Router Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Output Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Security Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Input Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:32:57 --> Language Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Loader Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:32:57 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:32:57 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:32:57 --> Session Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:32:57 --> Session routines successfully run
DEBUG - 2013-04-11 15:32:57 --> Controller Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Language Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Config Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:32:57 --> Loader Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Model Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Model Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:32:57 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:32:57 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:32:57 --> Model Class Initialized
DEBUG - 2013-04-11 15:32:57 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:32:57 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:32:57 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:32:57 --> Final output sent to browser
DEBUG - 2013-04-11 15:32:57 --> Total execution time: 0.0305
DEBUG - 2013-04-11 15:32:59 --> Config Class Initialized
DEBUG - 2013-04-11 15:32:59 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:32:59 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:32:59 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:32:59 --> URI Class Initialized
DEBUG - 2013-04-11 15:32:59 --> Router Class Initialized
DEBUG - 2013-04-11 15:33:00 --> Output Class Initialized
DEBUG - 2013-04-11 15:33:00 --> Security Class Initialized
DEBUG - 2013-04-11 15:33:00 --> Input Class Initialized
DEBUG - 2013-04-11 15:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:33:00 --> Language Class Initialized
DEBUG - 2013-04-11 15:33:00 --> Loader Class Initialized
DEBUG - 2013-04-11 15:33:00 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:33:00 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:33:00 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:33:00 --> Session Class Initialized
DEBUG - 2013-04-11 15:33:00 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:33:00 --> Session routines successfully run
DEBUG - 2013-04-11 15:33:00 --> Controller Class Initialized
DEBUG - 2013-04-11 15:33:00 --> Language Class Initialized
DEBUG - 2013-04-11 15:33:00 --> Config Class Initialized
DEBUG - 2013-04-11 15:33:00 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:33:00 --> Loader Class Initialized
DEBUG - 2013-04-11 15:33:00 --> Model Class Initialized
DEBUG - 2013-04-11 15:33:00 --> Model Class Initialized
DEBUG - 2013-04-11 15:33:00 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:33:00 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:33:00 --> File loaded: ../application/admin/modules/usuarios/views/confirmacaoExclusaoPermanente.php
DEBUG - 2013-04-11 15:33:00 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:33:00 --> Final output sent to browser
DEBUG - 2013-04-11 15:33:00 --> Total execution time: 0.0246
DEBUG - 2013-04-11 15:33:07 --> Config Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:33:07 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:33:07 --> URI Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Router Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Output Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Security Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Input Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:33:07 --> Language Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Loader Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:33:07 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:33:07 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:33:07 --> Session Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:33:07 --> Session routines successfully run
DEBUG - 2013-04-11 15:33:07 --> Controller Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Language Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Config Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:33:07 --> Loader Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Model Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Model Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Model Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Final output sent to browser
DEBUG - 2013-04-11 15:33:07 --> Total execution time: 0.0283
DEBUG - 2013-04-11 15:33:07 --> Config Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:33:07 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:33:07 --> URI Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Router Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Output Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Security Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Input Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:33:07 --> Language Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Loader Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:33:07 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:33:07 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:33:07 --> Session Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:33:07 --> Session routines successfully run
DEBUG - 2013-04-11 15:33:07 --> Controller Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Language Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Config Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:33:07 --> Loader Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Model Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Model Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:33:07 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:33:07 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:33:07 --> Model Class Initialized
DEBUG - 2013-04-11 15:33:07 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:33:07 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:33:07 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:33:07 --> Final output sent to browser
DEBUG - 2013-04-11 15:33:07 --> Total execution time: 0.0319
DEBUG - 2013-04-11 15:34:03 --> Config Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:34:03 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:34:03 --> URI Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Router Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Output Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Security Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Input Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:34:03 --> Language Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Loader Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:34:03 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:34:03 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:34:03 --> Session Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:34:03 --> Session routines successfully run
DEBUG - 2013-04-11 15:34:03 --> Controller Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Language Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Config Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:34:03 --> Loader Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Model Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Model Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:34:03 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:34:03 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:34:03 --> Model Class Initialized
DEBUG - 2013-04-11 15:34:03 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:34:03 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:34:03 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:34:03 --> Final output sent to browser
DEBUG - 2013-04-11 15:34:03 --> Total execution time: 0.0282
DEBUG - 2013-04-11 15:34:05 --> Config Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:34:05 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:34:05 --> URI Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Router Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Output Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Security Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Input Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:34:05 --> Language Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Loader Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:34:05 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:34:05 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:34:05 --> Session Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:34:05 --> Session routines successfully run
DEBUG - 2013-04-11 15:34:05 --> Controller Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Language Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Config Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:34:05 --> Loader Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Model Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Model Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Model Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Final output sent to browser
DEBUG - 2013-04-11 15:34:05 --> Total execution time: 0.0279
DEBUG - 2013-04-11 15:34:05 --> Config Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:34:05 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:34:05 --> URI Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Router Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Output Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Security Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Input Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:34:05 --> Language Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Loader Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:34:05 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:34:05 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:34:05 --> Session Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:34:05 --> Session routines successfully run
DEBUG - 2013-04-11 15:34:05 --> Controller Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Language Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Config Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:34:05 --> Loader Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Model Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Model Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:34:05 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:34:05 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:34:05 --> Model Class Initialized
DEBUG - 2013-04-11 15:34:05 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:34:05 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:34:05 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:34:05 --> Final output sent to browser
DEBUG - 2013-04-11 15:34:05 --> Total execution time: 0.0282
DEBUG - 2013-04-11 15:35:24 --> Config Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:35:24 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:35:24 --> URI Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Router Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Output Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Security Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Input Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:35:24 --> Language Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Loader Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:35:24 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:35:24 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:35:24 --> Session Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:35:24 --> Session routines successfully run
DEBUG - 2013-04-11 15:35:24 --> Controller Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Language Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Config Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:35:24 --> Loader Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Model Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Model Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:35:24 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:35:24 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:35:24 --> Model Class Initialized
DEBUG - 2013-04-11 15:35:24 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:35:24 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:35:24 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:35:24 --> Final output sent to browser
DEBUG - 2013-04-11 15:35:24 --> Total execution time: 0.0284
DEBUG - 2013-04-11 15:43:42 --> Config Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:43:42 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:43:42 --> URI Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Router Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Output Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Security Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Input Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:43:42 --> Language Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Loader Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:43:42 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:43:42 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:43:42 --> Session Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:43:42 --> Session routines successfully run
DEBUG - 2013-04-11 15:43:42 --> Controller Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Language Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Config Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:43:42 --> Loader Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Model Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Model Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:43:42 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:43:42 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:43:42 --> Model Class Initialized
DEBUG - 2013-04-11 15:43:42 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:43:42 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:43:42 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:43:42 --> Final output sent to browser
DEBUG - 2013-04-11 15:43:42 --> Total execution time: 0.0291
DEBUG - 2013-04-11 15:43:43 --> Config Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:43:43 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:43:43 --> URI Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Router Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Output Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Security Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Input Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:43:43 --> Language Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Loader Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:43:43 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:43:43 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:43:43 --> Session Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:43:43 --> Session routines successfully run
DEBUG - 2013-04-11 15:43:43 --> Controller Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Language Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Config Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:43:43 --> Loader Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Model Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Model Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:43:43 --> Model Class Initialized
DEBUG - 2013-04-11 15:43:43 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:43:43 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-11 15:43:43 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:43:43 --> Final output sent to browser
DEBUG - 2013-04-11 15:43:43 --> Total execution time: 0.0306
DEBUG - 2013-04-11 15:43:50 --> Config Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:43:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:43:50 --> URI Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Router Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Output Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Security Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Input Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:43:50 --> Language Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Loader Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:43:50 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:43:50 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:43:50 --> Session Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:43:50 --> Session routines successfully run
DEBUG - 2013-04-11 15:43:50 --> Controller Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Language Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Config Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:43:50 --> Loader Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Model Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Model Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:43:50 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:43:50 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:43:50 --> Model Class Initialized
DEBUG - 2013-04-11 15:43:50 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:43:50 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:43:50 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:43:50 --> Final output sent to browser
DEBUG - 2013-04-11 15:43:50 --> Total execution time: 0.0265
DEBUG - 2013-04-11 15:43:53 --> Config Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:43:53 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:43:53 --> URI Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Router Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Output Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Security Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Input Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:43:53 --> Language Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Loader Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:43:53 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:43:53 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:43:53 --> Session Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:43:53 --> Session routines successfully run
DEBUG - 2013-04-11 15:43:53 --> Controller Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Language Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Config Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:43:53 --> Loader Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Model Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Model Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:43:53 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:43:53 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:43:53 --> Model Class Initialized
DEBUG - 2013-04-11 15:43:53 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:43:53 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:43:53 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:43:53 --> Final output sent to browser
DEBUG - 2013-04-11 15:43:53 --> Total execution time: 0.0285
DEBUG - 2013-04-11 15:45:16 --> Config Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:45:16 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:45:16 --> URI Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Router Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Output Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Security Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Input Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:45:16 --> Language Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Loader Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:45:16 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:45:16 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:45:16 --> Session Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:45:16 --> Session routines successfully run
DEBUG - 2013-04-11 15:45:16 --> Controller Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Language Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Config Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:45:16 --> Loader Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Model Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Model Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:45:16 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:45:16 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:45:16 --> Model Class Initialized
DEBUG - 2013-04-11 15:45:16 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:45:16 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:45:16 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:45:16 --> Final output sent to browser
DEBUG - 2013-04-11 15:45:16 --> Total execution time: 0.0334
DEBUG - 2013-04-11 15:45:49 --> Config Class Initialized
DEBUG - 2013-04-11 15:45:49 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:45:49 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:45:49 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:45:49 --> URI Class Initialized
DEBUG - 2013-04-11 15:45:49 --> Router Class Initialized
DEBUG - 2013-04-11 15:45:49 --> No URI present. Default controller set.
DEBUG - 2013-04-11 15:45:49 --> Output Class Initialized
DEBUG - 2013-04-11 15:45:49 --> Security Class Initialized
DEBUG - 2013-04-11 15:45:49 --> Input Class Initialized
DEBUG - 2013-04-11 15:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:45:49 --> Language Class Initialized
DEBUG - 2013-04-11 15:45:49 --> Loader Class Initialized
DEBUG - 2013-04-11 15:45:49 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:45:49 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:45:49 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:45:49 --> Session Class Initialized
DEBUG - 2013-04-11 15:45:49 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:45:49 --> Session routines successfully run
DEBUG - 2013-04-11 15:45:49 --> Controller Class Initialized
DEBUG - 2013-04-11 15:45:49 --> Language Class Initialized
DEBUG - 2013-04-11 15:45:49 --> Config Class Initialized
DEBUG - 2013-04-11 15:45:49 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-11 15:45:49 --> Loader Class Initialized
DEBUG - 2013-04-11 15:45:49 --> File loaded: ../application/admin/modules/autenticacao/views/login.php
DEBUG - 2013-04-11 15:45:49 --> Final output sent to browser
DEBUG - 2013-04-11 15:45:49 --> Total execution time: 0.0151
DEBUG - 2013-04-11 15:47:53 --> Config Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:47:53 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:47:53 --> URI Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Router Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Output Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Security Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Input Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:47:53 --> Language Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Loader Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:47:53 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:47:53 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:47:53 --> Session Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:47:53 --> Session routines successfully run
DEBUG - 2013-04-11 15:47:53 --> Controller Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Language Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Config Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:47:53 --> Loader Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Model Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Model Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:47:53 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:47:53 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:47:53 --> Model Class Initialized
DEBUG - 2013-04-11 15:47:53 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:47:53 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:47:53 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:47:53 --> Final output sent to browser
DEBUG - 2013-04-11 15:47:53 --> Total execution time: 0.0294
DEBUG - 2013-04-11 15:47:55 --> Config Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:47:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:47:55 --> URI Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Router Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Output Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Security Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Input Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:47:55 --> Language Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Loader Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:47:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:47:55 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:47:55 --> Session Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:47:55 --> Session routines successfully run
DEBUG - 2013-04-11 15:47:55 --> Controller Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Language Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Config Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:47:55 --> Loader Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Model Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Model Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:47:55 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-11 15:47:55 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:47:55 --> Model Class Initialized
DEBUG - 2013-04-11 15:47:55 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:47:55 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-11 15:47:55 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:47:55 --> Final output sent to browser
DEBUG - 2013-04-11 15:47:55 --> Total execution time: 0.0261
DEBUG - 2013-04-11 15:47:56 --> Config Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:47:56 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:47:56 --> URI Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Router Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Output Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Security Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Input Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:47:56 --> Language Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Loader Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:47:56 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:47:56 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:47:56 --> Session Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:47:56 --> Session routines successfully run
DEBUG - 2013-04-11 15:47:56 --> Controller Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Language Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Config Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:47:56 --> Loader Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Model Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Model Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:47:56 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:47:56 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:47:56 --> Model Class Initialized
DEBUG - 2013-04-11 15:47:56 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:47:56 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:47:56 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:47:56 --> Final output sent to browser
DEBUG - 2013-04-11 15:47:56 --> Total execution time: 0.0277
DEBUG - 2013-04-11 15:48:08 --> Config Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:48:08 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:48:08 --> URI Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Router Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Output Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Security Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Input Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:48:08 --> Language Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Loader Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:48:08 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:48:08 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:48:08 --> Session Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:48:08 --> Session routines successfully run
DEBUG - 2013-04-11 15:48:08 --> Controller Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Language Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Config Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:48:08 --> Loader Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Model Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Model Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:48:08 --> Model Class Initialized
DEBUG - 2013-04-11 15:48:08 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:48:08 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-11 15:48:08 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:48:08 --> Final output sent to browser
DEBUG - 2013-04-11 15:48:08 --> Total execution time: 0.0304
DEBUG - 2013-04-11 15:54:25 --> Config Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:54:25 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:54:25 --> URI Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Router Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Output Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Security Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Input Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:54:25 --> Language Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Loader Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:54:25 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:54:25 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:54:25 --> Session Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:54:25 --> Session routines successfully run
DEBUG - 2013-04-11 15:54:25 --> Controller Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Language Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Config Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:54:25 --> Loader Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Model Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Model Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Database Driver Class Initialized
ERROR - 2013-04-11 15:54:25 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 15:54:25 --> Pagination Class Initialized
DEBUG - 2013-04-11 15:54:25 --> Model Class Initialized
DEBUG - 2013-04-11 15:54:25 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:54:25 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 15:54:25 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:54:25 --> Final output sent to browser
DEBUG - 2013-04-11 15:54:25 --> Total execution time: 0.0285
DEBUG - 2013-04-11 15:56:17 --> Config Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:56:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:56:17 --> URI Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Router Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Output Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Security Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Input Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:56:17 --> Language Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Loader Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:56:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:56:17 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:56:17 --> Session Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:56:17 --> Session routines successfully run
DEBUG - 2013-04-11 15:56:17 --> Controller Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Language Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Config Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:56:17 --> Loader Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Model Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Model Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:56:17 --> Final output sent to browser
DEBUG - 2013-04-11 15:56:17 --> Total execution time: 0.0260
DEBUG - 2013-04-11 15:57:18 --> Config Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Hooks Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Utf8 Class Initialized
DEBUG - 2013-04-11 15:57:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 15:57:18 --> URI Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Router Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Output Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Security Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Input Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 15:57:18 --> Language Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Loader Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Helper loaded: url_helper
DEBUG - 2013-04-11 15:57:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 15:57:18 --> Helper loaded: text_helper
DEBUG - 2013-04-11 15:57:18 --> Session Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Helper loaded: string_helper
DEBUG - 2013-04-11 15:57:18 --> Session routines successfully run
DEBUG - 2013-04-11 15:57:18 --> Controller Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Language Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Config Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 15:57:18 --> Loader Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Model Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Model Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Database Driver Class Initialized
DEBUG - 2013-04-11 15:57:18 --> Model Class Initialized
DEBUG - 2013-04-11 15:57:18 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 15:57:18 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-11 15:57:18 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 15:57:18 --> Final output sent to browser
DEBUG - 2013-04-11 15:57:18 --> Total execution time: 0.0289
DEBUG - 2013-04-11 16:00:13 --> Config Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:00:13 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:00:13 --> URI Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Router Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Output Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Security Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Input Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:00:13 --> Language Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Loader Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:00:13 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:00:13 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:00:13 --> Session Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:00:13 --> Session routines successfully run
DEBUG - 2013-04-11 16:00:13 --> Controller Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Language Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Config Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 16:00:13 --> Loader Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Model Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Model Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Database Driver Class Initialized
DEBUG - 2013-04-11 16:00:13 --> Model Class Initialized
ERROR - 2013-04-11 16:00:13 --> Severity: Notice  --> Undefined property: CI::$crud /home/w3case/public_html/target-git/application/admin/third_party/MX/Controller.php 57
DEBUG - 2013-04-11 16:01:13 --> Config Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:01:13 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:01:13 --> URI Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Router Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Output Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Security Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Input Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:01:13 --> Language Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Loader Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:01:13 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:01:13 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:01:13 --> Session Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:01:13 --> Session routines successfully run
DEBUG - 2013-04-11 16:01:13 --> Controller Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Language Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Config Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 16:01:13 --> Loader Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Model Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Model Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Database Driver Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Model Class Initialized
DEBUG - 2013-04-11 16:01:13 --> Model Class Initialized
DEBUG - 2013-04-11 16:01:13 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 16:01:13 --> File loaded: ../application/admin/modules/usuarios/views/atualizar.php
DEBUG - 2013-04-11 16:01:13 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:01:13 --> Final output sent to browser
DEBUG - 2013-04-11 16:01:13 --> Total execution time: 0.0271
DEBUG - 2013-04-11 16:01:43 --> Config Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:01:43 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:01:43 --> URI Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Router Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Output Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Security Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Input Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:01:43 --> Language Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Loader Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:01:43 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:01:43 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:01:43 --> Session Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:01:43 --> Session routines successfully run
DEBUG - 2013-04-11 16:01:43 --> Controller Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Language Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Config Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 16:01:43 --> Loader Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Model Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Model Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Database Driver Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Model Class Initialized
DEBUG - 2013-04-11 16:01:43 --> Model Class Initialized
DEBUG - 2013-04-11 16:01:43 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 16:01:43 --> File loaded: ../application/admin/modules/usuarios/views/atualizar.php
DEBUG - 2013-04-11 16:01:43 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:01:43 --> Final output sent to browser
DEBUG - 2013-04-11 16:01:43 --> Total execution time: 0.0282
DEBUG - 2013-04-11 16:01:55 --> Config Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:01:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:01:55 --> URI Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Router Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Output Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Security Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Input Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:01:55 --> Language Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Loader Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:01:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:01:55 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:01:55 --> Session Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:01:55 --> Session routines successfully run
DEBUG - 2013-04-11 16:01:55 --> Controller Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Language Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Config Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 16:01:55 --> Loader Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Model Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Model Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Database Driver Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Model Class Initialized
DEBUG - 2013-04-11 16:01:55 --> Model Class Initialized
DEBUG - 2013-04-11 16:01:55 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 16:01:55 --> File loaded: ../application/admin/modules/usuarios/views/atualizar.php
DEBUG - 2013-04-11 16:01:55 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:01:55 --> Final output sent to browser
DEBUG - 2013-04-11 16:01:55 --> Total execution time: 0.0299
DEBUG - 2013-04-11 16:02:20 --> Config Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:02:20 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:02:20 --> URI Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Router Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Output Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Security Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Input Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:02:20 --> Language Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Loader Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:02:20 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:02:20 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:02:20 --> Session Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:02:20 --> Session routines successfully run
DEBUG - 2013-04-11 16:02:20 --> Controller Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Language Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Config Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 16:02:20 --> Loader Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Model Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Model Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Database Driver Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Model Class Initialized
DEBUG - 2013-04-11 16:02:20 --> Model Class Initialized
DEBUG - 2013-04-11 16:02:20 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 16:02:20 --> File loaded: ../application/admin/modules/usuarios/views/atualizar.php
DEBUG - 2013-04-11 16:02:20 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:02:20 --> Final output sent to browser
DEBUG - 2013-04-11 16:02:20 --> Total execution time: 0.0292
DEBUG - 2013-04-11 16:02:52 --> Config Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:02:52 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:02:52 --> URI Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Router Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Output Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Security Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Input Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:02:52 --> Language Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Loader Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:02:52 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:02:52 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:02:52 --> Session Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:02:52 --> Session routines successfully run
DEBUG - 2013-04-11 16:02:52 --> Controller Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Language Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Config Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 16:02:52 --> Loader Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Model Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Model Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Database Driver Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Model Class Initialized
DEBUG - 2013-04-11 16:02:52 --> Model Class Initialized
DEBUG - 2013-04-11 16:02:52 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 16:02:52 --> File loaded: ../application/admin/modules/usuarios/views/atualizar.php
DEBUG - 2013-04-11 16:02:52 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:02:52 --> Final output sent to browser
DEBUG - 2013-04-11 16:02:52 --> Total execution time: 0.0282
DEBUG - 2013-04-11 16:03:07 --> Config Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:03:07 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:03:07 --> URI Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Router Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Output Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Security Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Input Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:03:07 --> Language Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Loader Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:03:07 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:03:07 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:03:07 --> Session Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:03:07 --> Session routines successfully run
DEBUG - 2013-04-11 16:03:07 --> Controller Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Language Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Config Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 16:03:07 --> Loader Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Model Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Model Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Database Driver Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Model Class Initialized
DEBUG - 2013-04-11 16:03:07 --> Model Class Initialized
DEBUG - 2013-04-11 16:03:07 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 16:03:07 --> File loaded: ../application/admin/modules/usuarios/views/atualizar.php
DEBUG - 2013-04-11 16:03:07 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:03:07 --> Final output sent to browser
DEBUG - 2013-04-11 16:03:07 --> Total execution time: 0.0311
DEBUG - 2013-04-11 16:10:41 --> Config Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:10:41 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:10:41 --> URI Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Router Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Output Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Security Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Input Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:10:41 --> Language Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Loader Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:10:41 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:10:41 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:10:41 --> Session Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:10:41 --> Session routines successfully run
DEBUG - 2013-04-11 16:10:41 --> Controller Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Language Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Config Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 16:10:41 --> Loader Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Model Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Model Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Database Driver Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Model Class Initialized
DEBUG - 2013-04-11 16:10:41 --> Model Class Initialized
DEBUG - 2013-04-11 16:10:41 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 16:10:41 --> File loaded: ../application/admin/modules/usuarios/views/atualizar.php
DEBUG - 2013-04-11 16:10:41 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:10:41 --> Final output sent to browser
DEBUG - 2013-04-11 16:10:41 --> Total execution time: 0.0276
DEBUG - 2013-04-11 16:11:14 --> Config Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:11:14 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:11:14 --> URI Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Router Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Output Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Security Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Input Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:11:14 --> Language Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Loader Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:11:14 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:11:14 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:11:14 --> Session Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:11:14 --> Session routines successfully run
DEBUG - 2013-04-11 16:11:14 --> Controller Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Language Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Config Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 16:11:14 --> Loader Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Model Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Model Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Database Driver Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Model Class Initialized
DEBUG - 2013-04-11 16:11:14 --> Model Class Initialized
DEBUG - 2013-04-11 16:11:14 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 16:11:14 --> File loaded: ../application/admin/modules/usuarios/views/atualizar.php
DEBUG - 2013-04-11 16:11:14 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:11:14 --> Final output sent to browser
DEBUG - 2013-04-11 16:11:14 --> Total execution time: 0.0366
DEBUG - 2013-04-11 16:11:26 --> Config Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:11:26 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:11:26 --> URI Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Router Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Output Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Security Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Input Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:11:26 --> Language Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Loader Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:11:26 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:11:26 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:11:26 --> Session Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:11:26 --> Session routines successfully run
DEBUG - 2013-04-11 16:11:26 --> Controller Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Language Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Config Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 16:11:26 --> Loader Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Model Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Model Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Database Driver Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Model Class Initialized
DEBUG - 2013-04-11 16:11:26 --> Model Class Initialized
DEBUG - 2013-04-11 16:11:26 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 16:11:26 --> File loaded: ../application/admin/modules/usuarios/views/atualizar.php
DEBUG - 2013-04-11 16:11:26 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:11:26 --> Final output sent to browser
DEBUG - 2013-04-11 16:11:26 --> Total execution time: 0.0379
DEBUG - 2013-04-11 16:11:32 --> Config Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:11:32 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:11:32 --> URI Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Router Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Output Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Security Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Input Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:11:32 --> Language Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Loader Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:11:32 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:11:32 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:11:32 --> Session Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:11:32 --> Session routines successfully run
DEBUG - 2013-04-11 16:11:32 --> Controller Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Language Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Config Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 16:11:32 --> Loader Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Model Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Model Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Database Driver Class Initialized
ERROR - 2013-04-11 16:11:32 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 16:11:32 --> Pagination Class Initialized
DEBUG - 2013-04-11 16:11:32 --> Model Class Initialized
DEBUG - 2013-04-11 16:11:32 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 16:11:32 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 16:11:32 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:11:32 --> Final output sent to browser
DEBUG - 2013-04-11 16:11:32 --> Total execution time: 0.0275
DEBUG - 2013-04-11 16:11:34 --> Config Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:11:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:11:34 --> URI Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Router Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Output Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Security Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Input Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:11:34 --> Language Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Loader Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:11:34 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:11:34 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:11:34 --> Session Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:11:34 --> Session routines successfully run
DEBUG - 2013-04-11 16:11:34 --> Controller Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Language Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Config Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 16:11:34 --> Loader Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Model Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Model Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Database Driver Class Initialized
DEBUG - 2013-04-11 16:11:34 --> Model Class Initialized
DEBUG - 2013-04-11 16:11:34 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 16:11:34 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-11 16:11:34 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:11:34 --> Final output sent to browser
DEBUG - 2013-04-11 16:11:34 --> Total execution time: 0.0277
DEBUG - 2013-04-11 16:19:38 --> Config Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:19:38 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:19:38 --> URI Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Router Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Output Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Security Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Input Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:19:38 --> Language Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Loader Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:19:38 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:19:38 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:19:38 --> Session Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:19:38 --> Session routines successfully run
DEBUG - 2013-04-11 16:19:38 --> Controller Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Language Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Config Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 16:19:38 --> Loader Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Model Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Model Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Database Driver Class Initialized
ERROR - 2013-04-11 16:19:38 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-11 16:19:38 --> Pagination Class Initialized
DEBUG - 2013-04-11 16:19:38 --> Model Class Initialized
DEBUG - 2013-04-11 16:19:38 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 16:19:38 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-11 16:19:38 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:19:38 --> Final output sent to browser
DEBUG - 2013-04-11 16:19:38 --> Total execution time: 0.0302
DEBUG - 2013-04-11 16:19:40 --> Config Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:19:40 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:19:40 --> URI Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Router Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Output Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Security Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Input Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:19:40 --> Language Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Loader Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:19:40 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:19:40 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:19:40 --> Session Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:19:40 --> Session routines successfully run
DEBUG - 2013-04-11 16:19:40 --> Controller Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Language Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Config Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 16:19:40 --> Loader Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Model Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Model Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Database Driver Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Model Class Initialized
DEBUG - 2013-04-11 16:19:40 --> Model Class Initialized
DEBUG - 2013-04-11 16:19:40 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 16:19:40 --> File loaded: ../application/admin/modules/usuarios/views/atualizar.php
DEBUG - 2013-04-11 16:19:40 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:19:40 --> Final output sent to browser
DEBUG - 2013-04-11 16:19:40 --> Total execution time: 0.0293
DEBUG - 2013-04-11 16:20:06 --> Config Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:20:06 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:20:06 --> URI Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Router Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Output Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Security Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Input Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:20:06 --> Language Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Loader Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:20:06 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:20:06 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:20:06 --> Session Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:20:06 --> Session routines successfully run
DEBUG - 2013-04-11 16:20:06 --> Controller Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Language Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Config Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 16:20:06 --> Loader Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Model Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Model Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Database Driver Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Model Class Initialized
DEBUG - 2013-04-11 16:20:06 --> Model Class Initialized
DEBUG - 2013-04-11 16:20:06 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 16:20:06 --> File loaded: ../application/admin/modules/usuarios/views/atualizar.php
DEBUG - 2013-04-11 16:20:06 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:20:06 --> Final output sent to browser
DEBUG - 2013-04-11 16:20:06 --> Total execution time: 0.0361
DEBUG - 2013-04-11 16:47:57 --> Config Class Initialized
DEBUG - 2013-04-11 16:47:57 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:47:57 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:47:57 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:47:57 --> URI Class Initialized
DEBUG - 2013-04-11 16:47:57 --> Router Class Initialized
DEBUG - 2013-04-11 16:47:57 --> Output Class Initialized
DEBUG - 2013-04-11 16:47:57 --> Security Class Initialized
DEBUG - 2013-04-11 16:47:57 --> Input Class Initialized
DEBUG - 2013-04-11 16:47:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:47:57 --> Language Class Initialized
DEBUG - 2013-04-11 16:47:57 --> Loader Class Initialized
DEBUG - 2013-04-11 16:47:57 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:47:57 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:47:57 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:47:57 --> Session Class Initialized
DEBUG - 2013-04-11 16:47:57 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:47:57 --> Session routines successfully run
DEBUG - 2013-04-11 16:47:57 --> Controller Class Initialized
DEBUG - 2013-04-11 16:47:57 --> Language Class Initialized
DEBUG - 2013-04-11 16:47:57 --> Config Class Initialized
DEBUG - 2013-04-11 16:47:57 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-11 16:47:57 --> Loader Class Initialized
DEBUG - 2013-04-11 16:47:57 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-11 16:47:57 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:47:57 --> Final output sent to browser
DEBUG - 2013-04-11 16:47:57 --> Total execution time: 0.0164
DEBUG - 2013-04-11 16:47:58 --> Config Class Initialized
DEBUG - 2013-04-11 16:47:58 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:47:58 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:47:58 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:47:58 --> URI Class Initialized
DEBUG - 2013-04-11 16:47:58 --> Router Class Initialized
DEBUG - 2013-04-11 16:47:58 --> Output Class Initialized
DEBUG - 2013-04-11 16:47:58 --> Security Class Initialized
DEBUG - 2013-04-11 16:47:58 --> Input Class Initialized
DEBUG - 2013-04-11 16:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:47:58 --> Language Class Initialized
DEBUG - 2013-04-11 16:47:58 --> Loader Class Initialized
DEBUG - 2013-04-11 16:47:58 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:47:58 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:47:58 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:47:58 --> Session Class Initialized
DEBUG - 2013-04-11 16:47:58 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:47:58 --> Session routines successfully run
DEBUG - 2013-04-11 16:47:58 --> Controller Class Initialized
DEBUG - 2013-04-11 16:47:58 --> Language Class Initialized
DEBUG - 2013-04-11 16:47:58 --> Config Class Initialized
DEBUG - 2013-04-11 16:47:58 --> Configuracoes MX_Controller Initialized
DEBUG - 2013-04-11 16:47:58 --> Loader Class Initialized
DEBUG - 2013-04-11 16:47:58 --> File loaded: ../application/admin/modules/configuracoes/views/nav.php
DEBUG - 2013-04-11 16:47:58 --> File loaded: ../application/admin/modules/configuracoes/views/configuracoes.php
DEBUG - 2013-04-11 16:47:58 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:47:58 --> Final output sent to browser
DEBUG - 2013-04-11 16:47:58 --> Total execution time: 0.0270
DEBUG - 2013-04-11 16:47:59 --> Config Class Initialized
DEBUG - 2013-04-11 16:47:59 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:47:59 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:47:59 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:47:59 --> URI Class Initialized
DEBUG - 2013-04-11 16:47:59 --> Router Class Initialized
DEBUG - 2013-04-11 16:47:59 --> Output Class Initialized
DEBUG - 2013-04-11 16:47:59 --> Security Class Initialized
DEBUG - 2013-04-11 16:47:59 --> Input Class Initialized
DEBUG - 2013-04-11 16:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:47:59 --> Language Class Initialized
DEBUG - 2013-04-11 16:47:59 --> Loader Class Initialized
DEBUG - 2013-04-11 16:47:59 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:47:59 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:47:59 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:47:59 --> Session Class Initialized
DEBUG - 2013-04-11 16:47:59 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:47:59 --> Session routines successfully run
DEBUG - 2013-04-11 16:47:59 --> Controller Class Initialized
DEBUG - 2013-04-11 16:47:59 --> Language Class Initialized
DEBUG - 2013-04-11 16:47:59 --> Config Class Initialized
DEBUG - 2013-04-11 16:47:59 --> Configuracoes MX_Controller Initialized
DEBUG - 2013-04-11 16:47:59 --> Loader Class Initialized
DEBUG - 2013-04-11 16:47:59 --> File loaded: ../application/admin/modules/configuracoes/views/nav.php
DEBUG - 2013-04-11 16:47:59 --> File loaded: ../application/admin/modules/configuracoes/views/geral.php
DEBUG - 2013-04-11 16:47:59 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:47:59 --> Final output sent to browser
DEBUG - 2013-04-11 16:47:59 --> Total execution time: 0.0179
DEBUG - 2013-04-11 16:48:23 --> Config Class Initialized
DEBUG - 2013-04-11 16:48:23 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:48:23 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:48:23 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:48:23 --> URI Class Initialized
DEBUG - 2013-04-11 16:48:23 --> Router Class Initialized
DEBUG - 2013-04-11 16:48:23 --> Output Class Initialized
DEBUG - 2013-04-11 16:48:23 --> Security Class Initialized
DEBUG - 2013-04-11 16:48:23 --> Input Class Initialized
DEBUG - 2013-04-11 16:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:48:23 --> Language Class Initialized
DEBUG - 2013-04-11 16:48:23 --> Loader Class Initialized
DEBUG - 2013-04-11 16:48:23 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:48:23 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:48:23 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:48:23 --> Session Class Initialized
DEBUG - 2013-04-11 16:48:23 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:48:23 --> Session routines successfully run
DEBUG - 2013-04-11 16:48:23 --> Controller Class Initialized
DEBUG - 2013-04-11 16:48:23 --> Language Class Initialized
DEBUG - 2013-04-11 16:48:23 --> Config Class Initialized
DEBUG - 2013-04-11 16:48:23 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-11 16:48:23 --> Loader Class Initialized
DEBUG - 2013-04-11 16:48:23 --> Model Class Initialized
DEBUG - 2013-04-11 16:48:23 --> Model Class Initialized
DEBUG - 2013-04-11 16:48:23 --> Database Driver Class Initialized
DEBUG - 2013-04-11 16:48:23 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-11 16:48:23 --> File loaded: ../application/admin/modules/usuarios/views/usuarios.php
DEBUG - 2013-04-11 16:48:23 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:48:23 --> Final output sent to browser
DEBUG - 2013-04-11 16:48:23 --> Total execution time: 0.0264
DEBUG - 2013-04-11 16:48:25 --> Config Class Initialized
DEBUG - 2013-04-11 16:48:25 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:48:25 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:48:25 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:48:25 --> URI Class Initialized
DEBUG - 2013-04-11 16:48:25 --> Router Class Initialized
DEBUG - 2013-04-11 16:48:25 --> Output Class Initialized
DEBUG - 2013-04-11 16:48:25 --> Security Class Initialized
DEBUG - 2013-04-11 16:48:25 --> Input Class Initialized
DEBUG - 2013-04-11 16:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:48:25 --> Language Class Initialized
DEBUG - 2013-04-11 16:48:25 --> Loader Class Initialized
DEBUG - 2013-04-11 16:48:25 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:48:25 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:48:25 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:48:25 --> Session Class Initialized
DEBUG - 2013-04-11 16:48:25 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:48:25 --> Session routines successfully run
DEBUG - 2013-04-11 16:48:25 --> Controller Class Initialized
DEBUG - 2013-04-11 16:48:25 --> Language Class Initialized
DEBUG - 2013-04-11 16:48:25 --> Config Class Initialized
DEBUG - 2013-04-11 16:48:25 --> Textos MX_Controller Initialized
DEBUG - 2013-04-11 16:48:25 --> Loader Class Initialized
DEBUG - 2013-04-11 16:48:25 --> File loaded: ../application/admin/modules/textos/views/nav.php
DEBUG - 2013-04-11 16:48:25 --> File loaded: ../application/admin/modules/textos/views/textos.php
DEBUG - 2013-04-11 16:48:25 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:48:25 --> Final output sent to browser
DEBUG - 2013-04-11 16:48:25 --> Total execution time: 0.0192
DEBUG - 2013-04-11 16:48:26 --> Config Class Initialized
DEBUG - 2013-04-11 16:48:26 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:48:26 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:48:26 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:48:26 --> URI Class Initialized
DEBUG - 2013-04-11 16:48:26 --> Router Class Initialized
DEBUG - 2013-04-11 16:48:26 --> Output Class Initialized
DEBUG - 2013-04-11 16:48:26 --> Security Class Initialized
DEBUG - 2013-04-11 16:48:26 --> Input Class Initialized
DEBUG - 2013-04-11 16:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:48:26 --> Language Class Initialized
DEBUG - 2013-04-11 16:48:26 --> Loader Class Initialized
DEBUG - 2013-04-11 16:48:26 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:48:26 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:48:26 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:48:26 --> Session Class Initialized
DEBUG - 2013-04-11 16:48:26 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:48:26 --> Session routines successfully run
DEBUG - 2013-04-11 16:48:26 --> Controller Class Initialized
DEBUG - 2013-04-11 16:48:26 --> Language Class Initialized
DEBUG - 2013-04-11 16:48:26 --> Config Class Initialized
DEBUG - 2013-04-11 16:48:26 --> Textos MX_Controller Initialized
DEBUG - 2013-04-11 16:48:26 --> Loader Class Initialized
DEBUG - 2013-04-11 16:48:26 --> File loaded: ../application/admin/modules/textos/views/nav.php
DEBUG - 2013-04-11 16:48:26 --> File loaded: ../application/admin/modules/textos/views/lixeira.php
DEBUG - 2013-04-11 16:48:26 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:48:26 --> Final output sent to browser
DEBUG - 2013-04-11 16:48:26 --> Total execution time: 0.0239
DEBUG - 2013-04-11 16:48:27 --> Config Class Initialized
DEBUG - 2013-04-11 16:48:27 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:48:27 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:48:27 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:48:27 --> URI Class Initialized
DEBUG - 2013-04-11 16:48:27 --> Router Class Initialized
DEBUG - 2013-04-11 16:48:27 --> Output Class Initialized
DEBUG - 2013-04-11 16:48:27 --> Security Class Initialized
DEBUG - 2013-04-11 16:48:27 --> Input Class Initialized
DEBUG - 2013-04-11 16:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:48:27 --> Language Class Initialized
DEBUG - 2013-04-11 16:48:27 --> Loader Class Initialized
DEBUG - 2013-04-11 16:48:27 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:48:27 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:48:27 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:48:27 --> Session Class Initialized
DEBUG - 2013-04-11 16:48:27 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:48:27 --> Session routines successfully run
DEBUG - 2013-04-11 16:48:27 --> Controller Class Initialized
DEBUG - 2013-04-11 16:48:27 --> Language Class Initialized
DEBUG - 2013-04-11 16:48:27 --> Config Class Initialized
DEBUG - 2013-04-11 16:48:27 --> Textos MX_Controller Initialized
DEBUG - 2013-04-11 16:48:27 --> Loader Class Initialized
DEBUG - 2013-04-11 16:48:27 --> File loaded: ../application/admin/modules/textos/views/nav.php
DEBUG - 2013-04-11 16:48:27 --> File loaded: ../application/admin/modules/textos/views/gerenciar.php
DEBUG - 2013-04-11 16:48:27 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:48:27 --> Final output sent to browser
DEBUG - 2013-04-11 16:48:27 --> Total execution time: 0.0307
DEBUG - 2013-04-11 16:48:30 --> Config Class Initialized
DEBUG - 2013-04-11 16:48:30 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:48:30 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:48:30 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:48:30 --> URI Class Initialized
DEBUG - 2013-04-11 16:48:30 --> Router Class Initialized
DEBUG - 2013-04-11 16:48:30 --> Output Class Initialized
DEBUG - 2013-04-11 16:48:30 --> Security Class Initialized
DEBUG - 2013-04-11 16:48:30 --> Input Class Initialized
DEBUG - 2013-04-11 16:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:48:30 --> Language Class Initialized
DEBUG - 2013-04-11 16:48:30 --> Loader Class Initialized
DEBUG - 2013-04-11 16:48:30 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:48:30 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:48:30 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:48:30 --> Session Class Initialized
DEBUG - 2013-04-11 16:48:30 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:48:30 --> Session routines successfully run
DEBUG - 2013-04-11 16:48:30 --> Controller Class Initialized
DEBUG - 2013-04-11 16:48:30 --> Language Class Initialized
DEBUG - 2013-04-11 16:48:30 --> Config Class Initialized
DEBUG - 2013-04-11 16:48:30 --> Textos MX_Controller Initialized
DEBUG - 2013-04-11 16:48:30 --> Loader Class Initialized
DEBUG - 2013-04-11 16:48:30 --> File loaded: ../application/admin/modules/textos/views/nav.php
DEBUG - 2013-04-11 16:48:30 --> File loaded: ../application/admin/modules/textos/views/gerenciar.php
DEBUG - 2013-04-11 16:48:30 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:48:30 --> Final output sent to browser
DEBUG - 2013-04-11 16:48:30 --> Total execution time: 0.0153
DEBUG - 2013-04-11 16:48:32 --> Config Class Initialized
DEBUG - 2013-04-11 16:48:32 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:48:32 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:48:32 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:48:32 --> URI Class Initialized
DEBUG - 2013-04-11 16:48:32 --> Router Class Initialized
DEBUG - 2013-04-11 16:48:32 --> Output Class Initialized
DEBUG - 2013-04-11 16:48:32 --> Security Class Initialized
DEBUG - 2013-04-11 16:48:32 --> Input Class Initialized
DEBUG - 2013-04-11 16:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:48:32 --> Language Class Initialized
DEBUG - 2013-04-11 16:48:32 --> Loader Class Initialized
DEBUG - 2013-04-11 16:48:32 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:48:32 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:48:32 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:48:32 --> Session Class Initialized
DEBUG - 2013-04-11 16:48:32 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:48:32 --> Session routines successfully run
DEBUG - 2013-04-11 16:48:32 --> Controller Class Initialized
DEBUG - 2013-04-11 16:48:32 --> Language Class Initialized
DEBUG - 2013-04-11 16:48:32 --> Config Class Initialized
DEBUG - 2013-04-11 16:48:32 --> Textos MX_Controller Initialized
DEBUG - 2013-04-11 16:48:32 --> Loader Class Initialized
DEBUG - 2013-04-11 16:48:32 --> File loaded: ../application/admin/modules/textos/views/nav.php
DEBUG - 2013-04-11 16:48:32 --> File loaded: ../application/admin/modules/textos/views/cadastrar.php
DEBUG - 2013-04-11 16:48:32 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-11 16:48:32 --> Final output sent to browser
DEBUG - 2013-04-11 16:48:32 --> Total execution time: 0.0264
DEBUG - 2013-04-11 16:48:44 --> Config Class Initialized
DEBUG - 2013-04-11 16:48:44 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:48:44 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:48:44 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:48:44 --> URI Class Initialized
DEBUG - 2013-04-11 16:48:44 --> Router Class Initialized
DEBUG - 2013-04-11 16:48:44 --> No URI present. Default controller set.
DEBUG - 2013-04-11 16:48:44 --> Output Class Initialized
DEBUG - 2013-04-11 16:48:44 --> Security Class Initialized
DEBUG - 2013-04-11 16:48:44 --> Input Class Initialized
DEBUG - 2013-04-11 16:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:48:44 --> Language Class Initialized
DEBUG - 2013-04-11 16:48:44 --> Loader Class Initialized
DEBUG - 2013-04-11 16:48:44 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:48:44 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:48:44 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:48:44 --> Session Class Initialized
DEBUG - 2013-04-11 16:48:44 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:48:44 --> Session routines successfully run
DEBUG - 2013-04-11 16:48:44 --> Controller Class Initialized
DEBUG - 2013-04-11 16:48:44 --> Language Class Initialized
DEBUG - 2013-04-11 16:48:44 --> Config Class Initialized
DEBUG - 2013-04-11 16:48:44 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-11 16:48:44 --> Loader Class Initialized
DEBUG - 2013-04-11 16:48:44 --> File loaded: ../application/admin/modules/autenticacao/views/login.php
DEBUG - 2013-04-11 16:48:44 --> Final output sent to browser
DEBUG - 2013-04-11 16:48:44 --> Total execution time: 0.0185
DEBUG - 2013-04-11 16:49:55 --> Config Class Initialized
DEBUG - 2013-04-11 16:49:55 --> Hooks Class Initialized
DEBUG - 2013-04-11 16:49:55 --> Utf8 Class Initialized
DEBUG - 2013-04-11 16:49:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-11 16:49:55 --> URI Class Initialized
DEBUG - 2013-04-11 16:49:55 --> Router Class Initialized
DEBUG - 2013-04-11 16:49:55 --> No URI present. Default controller set.
DEBUG - 2013-04-11 16:49:55 --> Output Class Initialized
DEBUG - 2013-04-11 16:49:55 --> Security Class Initialized
DEBUG - 2013-04-11 16:49:55 --> Input Class Initialized
DEBUG - 2013-04-11 16:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-11 16:49:55 --> Language Class Initialized
DEBUG - 2013-04-11 16:49:55 --> Loader Class Initialized
DEBUG - 2013-04-11 16:49:55 --> Helper loaded: url_helper
DEBUG - 2013-04-11 16:49:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-11 16:49:55 --> Helper loaded: text_helper
DEBUG - 2013-04-11 16:49:55 --> Session Class Initialized
DEBUG - 2013-04-11 16:49:55 --> Helper loaded: string_helper
DEBUG - 2013-04-11 16:49:55 --> Session routines successfully run
DEBUG - 2013-04-11 16:49:55 --> Controller Class Initialized
DEBUG - 2013-04-11 16:49:55 --> Language Class Initialized
DEBUG - 2013-04-11 16:49:55 --> Config Class Initialized
DEBUG - 2013-04-11 16:49:55 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-11 16:49:55 --> Loader Class Initialized
DEBUG - 2013-04-11 16:49:55 --> File loaded: ../application/admin/modules/autenticacao/views/login.php
DEBUG - 2013-04-11 16:49:55 --> Final output sent to browser
DEBUG - 2013-04-11 16:49:55 --> Total execution time: 0.0234
