<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-04-12 08:17:24 --> Config Class Initialized
DEBUG - 2013-04-12 08:17:24 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:17:24 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:17:24 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:17:24 --> URI Class Initialized
DEBUG - 2013-04-12 08:17:24 --> Router Class Initialized
DEBUG - 2013-04-12 08:17:25 --> No URI present. Default controller set.
DEBUG - 2013-04-12 08:17:25 --> Output Class Initialized
DEBUG - 2013-04-12 08:17:25 --> Security Class Initialized
DEBUG - 2013-04-12 08:17:25 --> Input Class Initialized
DEBUG - 2013-04-12 08:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:17:25 --> Language Class Initialized
DEBUG - 2013-04-12 08:17:25 --> Loader Class Initialized
DEBUG - 2013-04-12 08:17:25 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:17:25 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:17:25 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:17:25 --> Session Class Initialized
DEBUG - 2013-04-12 08:17:25 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:17:25 --> A session cookie was not found.
DEBUG - 2013-04-12 08:17:25 --> Session routines successfully run
DEBUG - 2013-04-12 08:17:25 --> Controller Class Initialized
DEBUG - 2013-04-12 08:17:25 --> Language Class Initialized
DEBUG - 2013-04-12 08:17:25 --> Config Class Initialized
DEBUG - 2013-04-12 08:17:25 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-12 08:17:25 --> Loader Class Initialized
DEBUG - 2013-04-12 08:17:25 --> File loaded: ../application/admin/modules/autenticacao/views/login.php
DEBUG - 2013-04-12 08:17:25 --> Final output sent to browser
DEBUG - 2013-04-12 08:17:25 --> Total execution time: 0.1723
DEBUG - 2013-04-12 08:17:31 --> Config Class Initialized
DEBUG - 2013-04-12 08:17:31 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:17:31 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:17:31 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:17:31 --> URI Class Initialized
DEBUG - 2013-04-12 08:17:31 --> Router Class Initialized
DEBUG - 2013-04-12 08:17:31 --> Output Class Initialized
DEBUG - 2013-04-12 08:17:31 --> Security Class Initialized
DEBUG - 2013-04-12 08:17:31 --> Input Class Initialized
DEBUG - 2013-04-12 08:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:17:31 --> Language Class Initialized
DEBUG - 2013-04-12 08:17:31 --> Loader Class Initialized
DEBUG - 2013-04-12 08:17:31 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:17:31 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:17:31 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:17:31 --> Session Class Initialized
DEBUG - 2013-04-12 08:17:31 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:17:31 --> Session routines successfully run
DEBUG - 2013-04-12 08:17:31 --> Controller Class Initialized
DEBUG - 2013-04-12 08:17:31 --> Language Class Initialized
DEBUG - 2013-04-12 08:17:31 --> Config Class Initialized
DEBUG - 2013-04-12 08:17:31 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-12 08:17:31 --> Loader Class Initialized
DEBUG - 2013-04-12 08:17:31 --> Model Class Initialized
DEBUG - 2013-04-12 08:17:31 --> Model Class Initialized
DEBUG - 2013-04-12 08:17:31 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:17:32 --> Model Class Initialized
ERROR - 2013-04-12 08:17:32 --> Severity: Notice  --> Undefined index: orlike /home/w3case/public_html/target-git/application/admin/models/crud.php 121
ERROR - 2013-04-12 08:17:32 --> Severity: Notice  --> Undefined index: orlike /home/w3case/public_html/target-git/application/admin/models/crud.php 121
DEBUG - 2013-04-12 08:17:32 --> Final output sent to browser
DEBUG - 2013-04-12 08:17:32 --> Total execution time: 0.7834
DEBUG - 2013-04-12 08:17:32 --> Config Class Initialized
DEBUG - 2013-04-12 08:17:32 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:17:32 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:17:32 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:17:32 --> URI Class Initialized
DEBUG - 2013-04-12 08:17:32 --> Router Class Initialized
DEBUG - 2013-04-12 08:17:32 --> Output Class Initialized
DEBUG - 2013-04-12 08:17:32 --> Security Class Initialized
DEBUG - 2013-04-12 08:17:32 --> Input Class Initialized
DEBUG - 2013-04-12 08:17:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:17:32 --> Language Class Initialized
DEBUG - 2013-04-12 08:17:32 --> Loader Class Initialized
DEBUG - 2013-04-12 08:17:32 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:17:32 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:17:32 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:17:32 --> Session Class Initialized
DEBUG - 2013-04-12 08:17:32 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:17:32 --> Session routines successfully run
DEBUG - 2013-04-12 08:17:32 --> Controller Class Initialized
DEBUG - 2013-04-12 08:17:32 --> Language Class Initialized
DEBUG - 2013-04-12 08:17:32 --> Config Class Initialized
DEBUG - 2013-04-12 08:17:32 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-12 08:17:32 --> Loader Class Initialized
DEBUG - 2013-04-12 08:17:32 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-12 08:17:32 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:17:32 --> Final output sent to browser
DEBUG - 2013-04-12 08:17:32 --> Total execution time: 0.0421
DEBUG - 2013-04-12 08:17:36 --> Config Class Initialized
DEBUG - 2013-04-12 08:17:36 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:17:36 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:17:36 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:17:36 --> URI Class Initialized
DEBUG - 2013-04-12 08:17:36 --> Router Class Initialized
DEBUG - 2013-04-12 08:17:36 --> Output Class Initialized
DEBUG - 2013-04-12 08:17:36 --> Security Class Initialized
DEBUG - 2013-04-12 08:17:36 --> Input Class Initialized
DEBUG - 2013-04-12 08:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:17:36 --> Language Class Initialized
DEBUG - 2013-04-12 08:17:36 --> Loader Class Initialized
DEBUG - 2013-04-12 08:17:36 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:17:36 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:17:36 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:17:36 --> Session Class Initialized
DEBUG - 2013-04-12 08:17:36 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:17:36 --> Session routines successfully run
DEBUG - 2013-04-12 08:17:36 --> Controller Class Initialized
DEBUG - 2013-04-12 08:17:36 --> Language Class Initialized
DEBUG - 2013-04-12 08:17:36 --> Config Class Initialized
DEBUG - 2013-04-12 08:17:36 --> Configuracoes MX_Controller Initialized
DEBUG - 2013-04-12 08:17:36 --> Loader Class Initialized
DEBUG - 2013-04-12 08:17:36 --> File loaded: ../application/admin/modules/configuracoes/views/nav.php
DEBUG - 2013-04-12 08:17:36 --> File loaded: ../application/admin/modules/configuracoes/views/configuracoes.php
DEBUG - 2013-04-12 08:17:36 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:17:36 --> Final output sent to browser
DEBUG - 2013-04-12 08:17:36 --> Total execution time: 0.0210
DEBUG - 2013-04-12 08:27:41 --> Config Class Initialized
DEBUG - 2013-04-12 08:27:41 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:27:41 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:27:41 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:27:41 --> URI Class Initialized
DEBUG - 2013-04-12 08:27:41 --> Router Class Initialized
DEBUG - 2013-04-12 08:27:41 --> Output Class Initialized
DEBUG - 2013-04-12 08:27:41 --> Security Class Initialized
DEBUG - 2013-04-12 08:27:41 --> Input Class Initialized
DEBUG - 2013-04-12 08:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:27:41 --> Language Class Initialized
DEBUG - 2013-04-12 08:27:41 --> Loader Class Initialized
DEBUG - 2013-04-12 08:27:41 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:27:41 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:27:41 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:27:41 --> Session Class Initialized
DEBUG - 2013-04-12 08:27:41 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:27:41 --> Session routines successfully run
DEBUG - 2013-04-12 08:27:41 --> Controller Class Initialized
DEBUG - 2013-04-12 08:27:41 --> Language Class Initialized
DEBUG - 2013-04-12 08:27:41 --> Config Class Initialized
DEBUG - 2013-04-12 08:27:41 --> Configuracoes MX_Controller Initialized
DEBUG - 2013-04-12 08:27:41 --> Loader Class Initialized
DEBUG - 2013-04-12 08:27:41 --> Model Class Initialized
DEBUG - 2013-04-12 08:29:48 --> Config Class Initialized
DEBUG - 2013-04-12 08:29:48 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:29:48 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:29:48 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:29:48 --> URI Class Initialized
DEBUG - 2013-04-12 08:29:48 --> Router Class Initialized
DEBUG - 2013-04-12 08:29:48 --> Output Class Initialized
DEBUG - 2013-04-12 08:29:48 --> Security Class Initialized
DEBUG - 2013-04-12 08:29:48 --> Input Class Initialized
DEBUG - 2013-04-12 08:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:29:48 --> Language Class Initialized
DEBUG - 2013-04-12 08:29:48 --> Loader Class Initialized
DEBUG - 2013-04-12 08:29:48 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:29:48 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:29:48 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:29:48 --> Session Class Initialized
DEBUG - 2013-04-12 08:29:48 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:29:48 --> Session routines successfully run
DEBUG - 2013-04-12 08:29:48 --> Controller Class Initialized
DEBUG - 2013-04-12 08:29:48 --> Language Class Initialized
DEBUG - 2013-04-12 08:29:48 --> Config Class Initialized
DEBUG - 2013-04-12 08:29:48 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-12 08:29:48 --> Loader Class Initialized
DEBUG - 2013-04-12 08:29:48 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-12 08:29:48 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:29:48 --> Final output sent to browser
DEBUG - 2013-04-12 08:29:48 --> Total execution time: 0.0174
DEBUG - 2013-04-12 08:29:50 --> Config Class Initialized
DEBUG - 2013-04-12 08:29:50 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:29:50 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:29:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:29:50 --> URI Class Initialized
DEBUG - 2013-04-12 08:29:50 --> Router Class Initialized
ERROR - 2013-04-12 08:29:50 --> 404 Page Not Found --> 
DEBUG - 2013-04-12 08:30:09 --> Config Class Initialized
DEBUG - 2013-04-12 08:30:09 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:30:09 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:30:09 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:30:09 --> URI Class Initialized
DEBUG - 2013-04-12 08:30:09 --> Router Class Initialized
DEBUG - 2013-04-12 08:30:09 --> Output Class Initialized
DEBUG - 2013-04-12 08:30:09 --> Security Class Initialized
DEBUG - 2013-04-12 08:30:09 --> Input Class Initialized
DEBUG - 2013-04-12 08:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:30:09 --> Language Class Initialized
DEBUG - 2013-04-12 08:30:09 --> Loader Class Initialized
DEBUG - 2013-04-12 08:30:09 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:30:09 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:30:09 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:30:09 --> Session Class Initialized
DEBUG - 2013-04-12 08:30:09 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:30:09 --> Session routines successfully run
DEBUG - 2013-04-12 08:30:09 --> Controller Class Initialized
DEBUG - 2013-04-12 08:30:09 --> Language Class Initialized
DEBUG - 2013-04-12 08:30:09 --> Config Class Initialized
DEBUG - 2013-04-12 08:30:09 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:30:09 --> Loader Class Initialized
DEBUG - 2013-04-12 08:30:09 --> Model Class Initialized
DEBUG - 2013-04-12 08:30:09 --> Model Class Initialized
DEBUG - 2013-04-12 08:30:09 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:30:09 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:30:09 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-12 08:30:09 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:30:09 --> Final output sent to browser
DEBUG - 2013-04-12 08:30:09 --> Total execution time: 0.0225
DEBUG - 2013-04-12 08:30:13 --> Config Class Initialized
DEBUG - 2013-04-12 08:30:13 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:30:13 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:30:13 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:30:13 --> URI Class Initialized
DEBUG - 2013-04-12 08:30:13 --> Router Class Initialized
DEBUG - 2013-04-12 08:30:13 --> Output Class Initialized
DEBUG - 2013-04-12 08:30:13 --> Security Class Initialized
DEBUG - 2013-04-12 08:30:13 --> Input Class Initialized
DEBUG - 2013-04-12 08:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:30:13 --> Language Class Initialized
DEBUG - 2013-04-12 08:30:13 --> Loader Class Initialized
DEBUG - 2013-04-12 08:30:13 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:30:13 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:30:13 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:30:13 --> Session Class Initialized
DEBUG - 2013-04-12 08:30:13 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:30:13 --> Session routines successfully run
DEBUG - 2013-04-12 08:30:13 --> Controller Class Initialized
DEBUG - 2013-04-12 08:30:13 --> Language Class Initialized
DEBUG - 2013-04-12 08:30:13 --> Config Class Initialized
DEBUG - 2013-04-12 08:30:13 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:30:13 --> Loader Class Initialized
DEBUG - 2013-04-12 08:30:13 --> Model Class Initialized
DEBUG - 2013-04-12 08:30:13 --> Model Class Initialized
DEBUG - 2013-04-12 08:30:13 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:30:13 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:30:13 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-12 08:30:13 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:30:13 --> Final output sent to browser
DEBUG - 2013-04-12 08:30:13 --> Total execution time: 0.0229
DEBUG - 2013-04-12 08:30:38 --> Config Class Initialized
DEBUG - 2013-04-12 08:30:38 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:30:38 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:30:38 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:30:38 --> URI Class Initialized
DEBUG - 2013-04-12 08:30:38 --> Router Class Initialized
DEBUG - 2013-04-12 08:30:38 --> Output Class Initialized
DEBUG - 2013-04-12 08:30:38 --> Security Class Initialized
DEBUG - 2013-04-12 08:30:38 --> Input Class Initialized
DEBUG - 2013-04-12 08:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:30:38 --> Language Class Initialized
DEBUG - 2013-04-12 08:30:38 --> Loader Class Initialized
DEBUG - 2013-04-12 08:30:38 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:30:38 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:30:38 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:30:38 --> Session Class Initialized
DEBUG - 2013-04-12 08:30:38 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:30:38 --> Session routines successfully run
DEBUG - 2013-04-12 08:30:38 --> Controller Class Initialized
DEBUG - 2013-04-12 08:30:38 --> Language Class Initialized
DEBUG - 2013-04-12 08:30:38 --> Config Class Initialized
DEBUG - 2013-04-12 08:30:38 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:30:38 --> Loader Class Initialized
DEBUG - 2013-04-12 08:30:38 --> Model Class Initialized
DEBUG - 2013-04-12 08:30:38 --> Model Class Initialized
DEBUG - 2013-04-12 08:30:38 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:30:38 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:30:38 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-12 08:30:38 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:30:38 --> Final output sent to browser
DEBUG - 2013-04-12 08:30:38 --> Total execution time: 0.0330
DEBUG - 2013-04-12 08:30:50 --> Config Class Initialized
DEBUG - 2013-04-12 08:30:50 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:30:50 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:30:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:30:50 --> URI Class Initialized
DEBUG - 2013-04-12 08:30:50 --> Router Class Initialized
DEBUG - 2013-04-12 08:30:50 --> Output Class Initialized
DEBUG - 2013-04-12 08:30:50 --> Security Class Initialized
DEBUG - 2013-04-12 08:30:50 --> Input Class Initialized
DEBUG - 2013-04-12 08:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:30:50 --> Language Class Initialized
DEBUG - 2013-04-12 08:30:50 --> Loader Class Initialized
DEBUG - 2013-04-12 08:30:50 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:30:50 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:30:50 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:30:50 --> Session Class Initialized
DEBUG - 2013-04-12 08:30:50 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:30:50 --> Session routines successfully run
DEBUG - 2013-04-12 08:30:50 --> Controller Class Initialized
DEBUG - 2013-04-12 08:30:50 --> Language Class Initialized
DEBUG - 2013-04-12 08:30:50 --> Config Class Initialized
DEBUG - 2013-04-12 08:30:50 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:30:50 --> Loader Class Initialized
DEBUG - 2013-04-12 08:30:50 --> Model Class Initialized
DEBUG - 2013-04-12 08:30:50 --> Model Class Initialized
DEBUG - 2013-04-12 08:30:50 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:30:50 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:30:50 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:30:50 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:30:50 --> Final output sent to browser
DEBUG - 2013-04-12 08:30:50 --> Total execution time: 0.0254
DEBUG - 2013-04-12 08:31:59 --> Config Class Initialized
DEBUG - 2013-04-12 08:31:59 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:31:59 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:31:59 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:31:59 --> URI Class Initialized
DEBUG - 2013-04-12 08:31:59 --> Router Class Initialized
DEBUG - 2013-04-12 08:31:59 --> Output Class Initialized
DEBUG - 2013-04-12 08:31:59 --> Security Class Initialized
DEBUG - 2013-04-12 08:31:59 --> Input Class Initialized
DEBUG - 2013-04-12 08:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:31:59 --> Language Class Initialized
DEBUG - 2013-04-12 08:31:59 --> Loader Class Initialized
DEBUG - 2013-04-12 08:31:59 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:31:59 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:31:59 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:31:59 --> Session Class Initialized
DEBUG - 2013-04-12 08:31:59 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:31:59 --> Session routines successfully run
DEBUG - 2013-04-12 08:31:59 --> Controller Class Initialized
DEBUG - 2013-04-12 08:31:59 --> Language Class Initialized
DEBUG - 2013-04-12 08:31:59 --> Config Class Initialized
DEBUG - 2013-04-12 08:31:59 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:31:59 --> Loader Class Initialized
DEBUG - 2013-04-12 08:31:59 --> Model Class Initialized
DEBUG - 2013-04-12 08:31:59 --> Model Class Initialized
DEBUG - 2013-04-12 08:31:59 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:31:59 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:31:59 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:31:59 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:31:59 --> Final output sent to browser
DEBUG - 2013-04-12 08:31:59 --> Total execution time: 0.0240
DEBUG - 2013-04-12 08:32:04 --> Config Class Initialized
DEBUG - 2013-04-12 08:32:04 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:32:04 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:32:04 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:32:04 --> URI Class Initialized
DEBUG - 2013-04-12 08:32:04 --> Router Class Initialized
DEBUG - 2013-04-12 08:32:04 --> Output Class Initialized
DEBUG - 2013-04-12 08:32:04 --> Security Class Initialized
DEBUG - 2013-04-12 08:32:04 --> Input Class Initialized
DEBUG - 2013-04-12 08:32:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:32:04 --> Language Class Initialized
DEBUG - 2013-04-12 08:32:04 --> Loader Class Initialized
DEBUG - 2013-04-12 08:32:04 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:32:04 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:32:04 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:32:04 --> Session Class Initialized
DEBUG - 2013-04-12 08:32:04 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:32:04 --> Session routines successfully run
DEBUG - 2013-04-12 08:32:04 --> Controller Class Initialized
DEBUG - 2013-04-12 08:32:04 --> Language Class Initialized
DEBUG - 2013-04-12 08:32:04 --> Config Class Initialized
DEBUG - 2013-04-12 08:32:04 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:32:04 --> Loader Class Initialized
DEBUG - 2013-04-12 08:32:04 --> Model Class Initialized
DEBUG - 2013-04-12 08:32:04 --> Model Class Initialized
DEBUG - 2013-04-12 08:32:04 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:32:04 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:32:04 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 08:32:04 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:32:04 --> Final output sent to browser
DEBUG - 2013-04-12 08:32:04 --> Total execution time: 0.0223
DEBUG - 2013-04-12 08:32:05 --> Config Class Initialized
DEBUG - 2013-04-12 08:32:05 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:32:05 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:32:05 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:32:05 --> URI Class Initialized
DEBUG - 2013-04-12 08:32:05 --> Router Class Initialized
DEBUG - 2013-04-12 08:32:05 --> Output Class Initialized
DEBUG - 2013-04-12 08:32:05 --> Security Class Initialized
DEBUG - 2013-04-12 08:32:05 --> Input Class Initialized
DEBUG - 2013-04-12 08:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:32:05 --> Language Class Initialized
DEBUG - 2013-04-12 08:32:05 --> Loader Class Initialized
DEBUG - 2013-04-12 08:32:05 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:32:05 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:32:05 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:32:05 --> Session Class Initialized
DEBUG - 2013-04-12 08:32:05 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:32:05 --> Session routines successfully run
DEBUG - 2013-04-12 08:32:05 --> Controller Class Initialized
DEBUG - 2013-04-12 08:32:05 --> Language Class Initialized
DEBUG - 2013-04-12 08:32:05 --> Config Class Initialized
DEBUG - 2013-04-12 08:32:05 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:32:05 --> Loader Class Initialized
DEBUG - 2013-04-12 08:32:05 --> Model Class Initialized
DEBUG - 2013-04-12 08:32:05 --> Model Class Initialized
DEBUG - 2013-04-12 08:32:05 --> Database Driver Class Initialized
ERROR - 2013-04-12 08:32:05 --> 404 Page Not Found --> configuracao/metas-analytics
DEBUG - 2013-04-12 08:32:30 --> Config Class Initialized
DEBUG - 2013-04-12 08:32:30 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:32:30 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:32:30 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:32:30 --> URI Class Initialized
DEBUG - 2013-04-12 08:32:30 --> Router Class Initialized
DEBUG - 2013-04-12 08:32:30 --> Output Class Initialized
DEBUG - 2013-04-12 08:32:30 --> Security Class Initialized
DEBUG - 2013-04-12 08:32:30 --> Input Class Initialized
DEBUG - 2013-04-12 08:32:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:32:30 --> Language Class Initialized
DEBUG - 2013-04-12 08:32:30 --> Loader Class Initialized
DEBUG - 2013-04-12 08:32:30 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:32:30 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:32:30 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:32:30 --> Session Class Initialized
DEBUG - 2013-04-12 08:32:30 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:32:30 --> Session routines successfully run
DEBUG - 2013-04-12 08:32:30 --> Controller Class Initialized
DEBUG - 2013-04-12 08:32:30 --> Language Class Initialized
DEBUG - 2013-04-12 08:32:30 --> Config Class Initialized
DEBUG - 2013-04-12 08:32:30 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:32:30 --> Loader Class Initialized
DEBUG - 2013-04-12 08:32:30 --> Model Class Initialized
DEBUG - 2013-04-12 08:32:30 --> Model Class Initialized
DEBUG - 2013-04-12 08:32:30 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:32:30 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:32:30 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 08:32:30 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:32:30 --> Final output sent to browser
DEBUG - 2013-04-12 08:32:30 --> Total execution time: 0.0232
DEBUG - 2013-04-12 08:32:31 --> Config Class Initialized
DEBUG - 2013-04-12 08:32:31 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:32:31 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:32:31 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:32:31 --> URI Class Initialized
DEBUG - 2013-04-12 08:32:31 --> Router Class Initialized
ERROR - 2013-04-12 08:32:31 --> 404 Page Not Found --> 
DEBUG - 2013-04-12 08:32:33 --> Config Class Initialized
DEBUG - 2013-04-12 08:32:33 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:32:33 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:32:33 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:32:33 --> URI Class Initialized
DEBUG - 2013-04-12 08:32:33 --> Router Class Initialized
ERROR - 2013-04-12 08:32:33 --> 404 Page Not Found --> 
DEBUG - 2013-04-12 08:32:34 --> Config Class Initialized
DEBUG - 2013-04-12 08:32:34 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:32:34 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:32:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:32:34 --> URI Class Initialized
DEBUG - 2013-04-12 08:32:34 --> Router Class Initialized
ERROR - 2013-04-12 08:32:34 --> 404 Page Not Found --> 
DEBUG - 2013-04-12 08:32:34 --> Config Class Initialized
DEBUG - 2013-04-12 08:32:34 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:32:34 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:32:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:32:34 --> URI Class Initialized
DEBUG - 2013-04-12 08:32:34 --> Router Class Initialized
ERROR - 2013-04-12 08:32:34 --> 404 Page Not Found --> 
DEBUG - 2013-04-12 08:32:45 --> Config Class Initialized
DEBUG - 2013-04-12 08:32:45 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:32:45 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:32:45 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:32:45 --> URI Class Initialized
DEBUG - 2013-04-12 08:32:45 --> Router Class Initialized
DEBUG - 2013-04-12 08:32:45 --> Output Class Initialized
DEBUG - 2013-04-12 08:32:45 --> Security Class Initialized
DEBUG - 2013-04-12 08:32:45 --> Input Class Initialized
DEBUG - 2013-04-12 08:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:32:45 --> Language Class Initialized
DEBUG - 2013-04-12 08:32:45 --> Loader Class Initialized
DEBUG - 2013-04-12 08:32:45 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:32:45 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:32:45 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:32:45 --> Session Class Initialized
DEBUG - 2013-04-12 08:32:45 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:32:45 --> Session routines successfully run
DEBUG - 2013-04-12 08:32:45 --> Controller Class Initialized
DEBUG - 2013-04-12 08:32:45 --> Language Class Initialized
DEBUG - 2013-04-12 08:32:45 --> Config Class Initialized
DEBUG - 2013-04-12 08:32:45 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:32:45 --> Loader Class Initialized
DEBUG - 2013-04-12 08:32:45 --> Model Class Initialized
DEBUG - 2013-04-12 08:32:45 --> Model Class Initialized
DEBUG - 2013-04-12 08:32:45 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:32:45 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:32:45 --> File loaded: ../application/admin/modules/configuracao/views/metas-analytics.php
DEBUG - 2013-04-12 08:32:45 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:32:45 --> Final output sent to browser
DEBUG - 2013-04-12 08:32:45 --> Total execution time: 0.0254
DEBUG - 2013-04-12 08:32:47 --> Config Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:32:47 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:32:47 --> URI Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Router Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Output Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Security Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Input Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:32:47 --> Language Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Loader Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:32:47 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:32:47 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:32:47 --> Session Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:32:47 --> Session routines successfully run
DEBUG - 2013-04-12 08:32:47 --> Controller Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Language Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Config Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:32:47 --> Loader Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Model Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Model Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:32:47 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:32:47 --> File loaded: ../application/admin/modules/configuracao/views/manutencao.php
DEBUG - 2013-04-12 08:32:47 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:32:47 --> Final output sent to browser
DEBUG - 2013-04-12 08:32:47 --> Total execution time: 0.0256
DEBUG - 2013-04-12 08:32:47 --> Config Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:32:47 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:32:47 --> URI Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Router Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Output Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Security Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Input Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:32:47 --> Language Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Loader Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:32:47 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:32:47 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:32:47 --> Session Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:32:47 --> Session routines successfully run
DEBUG - 2013-04-12 08:32:47 --> Controller Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Language Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Config Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:32:47 --> Loader Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Model Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Model Class Initialized
DEBUG - 2013-04-12 08:32:47 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:32:47 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:32:47 --> File loaded: ../application/admin/modules/configuracao/views/tempo.php
DEBUG - 2013-04-12 08:32:47 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:32:47 --> Final output sent to browser
DEBUG - 2013-04-12 08:32:47 --> Total execution time: 0.0219
DEBUG - 2013-04-12 08:33:10 --> Config Class Initialized
DEBUG - 2013-04-12 08:33:10 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:33:10 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:33:10 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:33:10 --> URI Class Initialized
DEBUG - 2013-04-12 08:33:10 --> Router Class Initialized
DEBUG - 2013-04-12 08:33:10 --> Output Class Initialized
DEBUG - 2013-04-12 08:33:10 --> Security Class Initialized
DEBUG - 2013-04-12 08:33:10 --> Input Class Initialized
DEBUG - 2013-04-12 08:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:33:10 --> Language Class Initialized
DEBUG - 2013-04-12 08:33:10 --> Loader Class Initialized
DEBUG - 2013-04-12 08:33:10 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:33:10 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:33:10 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:33:10 --> Session Class Initialized
DEBUG - 2013-04-12 08:33:10 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:33:10 --> Session routines successfully run
DEBUG - 2013-04-12 08:33:10 --> Controller Class Initialized
DEBUG - 2013-04-12 08:33:10 --> Language Class Initialized
DEBUG - 2013-04-12 08:33:10 --> Config Class Initialized
DEBUG - 2013-04-12 08:33:10 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:33:10 --> Loader Class Initialized
DEBUG - 2013-04-12 08:33:10 --> Model Class Initialized
DEBUG - 2013-04-12 08:33:10 --> Model Class Initialized
DEBUG - 2013-04-12 08:33:10 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:33:10 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:33:10 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:33:10 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:33:10 --> Final output sent to browser
DEBUG - 2013-04-12 08:33:10 --> Total execution time: 0.0251
DEBUG - 2013-04-12 08:41:06 --> Config Class Initialized
DEBUG - 2013-04-12 08:41:06 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:41:06 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:41:06 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:41:06 --> URI Class Initialized
DEBUG - 2013-04-12 08:41:06 --> Router Class Initialized
DEBUG - 2013-04-12 08:41:06 --> Output Class Initialized
DEBUG - 2013-04-12 08:41:06 --> Security Class Initialized
DEBUG - 2013-04-12 08:41:06 --> Input Class Initialized
DEBUG - 2013-04-12 08:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:41:06 --> Language Class Initialized
DEBUG - 2013-04-12 08:41:06 --> Loader Class Initialized
DEBUG - 2013-04-12 08:41:06 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:41:06 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:41:06 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:41:06 --> Session Class Initialized
DEBUG - 2013-04-12 08:41:06 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:41:06 --> Session routines successfully run
DEBUG - 2013-04-12 08:41:06 --> Controller Class Initialized
DEBUG - 2013-04-12 08:41:06 --> Language Class Initialized
DEBUG - 2013-04-12 08:41:06 --> Config Class Initialized
DEBUG - 2013-04-12 08:41:06 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:41:06 --> Loader Class Initialized
DEBUG - 2013-04-12 08:41:06 --> Model Class Initialized
DEBUG - 2013-04-12 08:41:06 --> Model Class Initialized
DEBUG - 2013-04-12 08:41:06 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:41:06 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:41:06 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:41:06 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:41:06 --> Final output sent to browser
DEBUG - 2013-04-12 08:41:06 --> Total execution time: 0.0325
DEBUG - 2013-04-12 08:41:21 --> Config Class Initialized
DEBUG - 2013-04-12 08:41:21 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:41:21 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:41:21 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:41:21 --> URI Class Initialized
DEBUG - 2013-04-12 08:41:21 --> Router Class Initialized
DEBUG - 2013-04-12 08:41:21 --> Output Class Initialized
DEBUG - 2013-04-12 08:41:21 --> Security Class Initialized
DEBUG - 2013-04-12 08:41:21 --> Input Class Initialized
DEBUG - 2013-04-12 08:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:41:21 --> Language Class Initialized
DEBUG - 2013-04-12 08:41:21 --> Loader Class Initialized
DEBUG - 2013-04-12 08:41:21 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:41:21 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:41:21 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:41:21 --> Session Class Initialized
DEBUG - 2013-04-12 08:41:21 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:41:21 --> Session routines successfully run
DEBUG - 2013-04-12 08:41:21 --> Controller Class Initialized
DEBUG - 2013-04-12 08:41:21 --> Language Class Initialized
DEBUG - 2013-04-12 08:41:21 --> Config Class Initialized
DEBUG - 2013-04-12 08:41:21 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:41:21 --> Loader Class Initialized
DEBUG - 2013-04-12 08:41:21 --> Model Class Initialized
DEBUG - 2013-04-12 08:41:21 --> Model Class Initialized
DEBUG - 2013-04-12 08:41:21 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:41:21 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:41:21 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:41:21 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:41:21 --> Final output sent to browser
DEBUG - 2013-04-12 08:41:21 --> Total execution time: 0.0304
DEBUG - 2013-04-12 08:42:12 --> Config Class Initialized
DEBUG - 2013-04-12 08:42:12 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:42:12 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:42:12 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:42:12 --> URI Class Initialized
DEBUG - 2013-04-12 08:42:12 --> Router Class Initialized
DEBUG - 2013-04-12 08:42:12 --> Output Class Initialized
DEBUG - 2013-04-12 08:42:12 --> Security Class Initialized
DEBUG - 2013-04-12 08:42:12 --> Input Class Initialized
DEBUG - 2013-04-12 08:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:42:12 --> Language Class Initialized
DEBUG - 2013-04-12 08:42:12 --> Loader Class Initialized
DEBUG - 2013-04-12 08:42:12 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:42:12 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:42:12 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:42:12 --> Session Class Initialized
DEBUG - 2013-04-12 08:42:12 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:42:12 --> Session routines successfully run
DEBUG - 2013-04-12 08:42:12 --> Controller Class Initialized
DEBUG - 2013-04-12 08:42:12 --> Language Class Initialized
DEBUG - 2013-04-12 08:42:12 --> Config Class Initialized
DEBUG - 2013-04-12 08:42:12 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:42:12 --> Loader Class Initialized
DEBUG - 2013-04-12 08:42:12 --> Model Class Initialized
DEBUG - 2013-04-12 08:42:12 --> Model Class Initialized
DEBUG - 2013-04-12 08:42:12 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:42:12 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:42:12 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:42:12 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:42:12 --> Final output sent to browser
DEBUG - 2013-04-12 08:42:12 --> Total execution time: 0.0298
DEBUG - 2013-04-12 08:43:01 --> Config Class Initialized
DEBUG - 2013-04-12 08:43:01 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:43:01 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:43:01 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:43:01 --> URI Class Initialized
DEBUG - 2013-04-12 08:43:01 --> Router Class Initialized
DEBUG - 2013-04-12 08:43:01 --> Output Class Initialized
DEBUG - 2013-04-12 08:43:01 --> Security Class Initialized
DEBUG - 2013-04-12 08:43:01 --> Input Class Initialized
DEBUG - 2013-04-12 08:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:43:01 --> Language Class Initialized
DEBUG - 2013-04-12 08:43:01 --> Loader Class Initialized
DEBUG - 2013-04-12 08:43:01 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:43:01 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:43:01 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:43:01 --> Session Class Initialized
DEBUG - 2013-04-12 08:43:01 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:43:01 --> Session routines successfully run
DEBUG - 2013-04-12 08:43:01 --> Controller Class Initialized
DEBUG - 2013-04-12 08:43:01 --> Language Class Initialized
DEBUG - 2013-04-12 08:43:01 --> Config Class Initialized
DEBUG - 2013-04-12 08:43:01 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:43:01 --> Loader Class Initialized
DEBUG - 2013-04-12 08:43:01 --> Model Class Initialized
DEBUG - 2013-04-12 08:43:01 --> Model Class Initialized
DEBUG - 2013-04-12 08:43:01 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Config Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:44:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:44:34 --> URI Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Router Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Output Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Security Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Input Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:44:34 --> Language Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Loader Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:44:34 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:44:34 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:44:34 --> Session Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:44:34 --> Session routines successfully run
DEBUG - 2013-04-12 08:44:34 --> Controller Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Language Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Config Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:44:34 --> Loader Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Model Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Model Class Initialized
DEBUG - 2013-04-12 08:44:34 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:44:34 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:44:34 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-12 08:44:34 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:44:34 --> Final output sent to browser
DEBUG - 2013-04-12 08:44:34 --> Total execution time: 0.0232
DEBUG - 2013-04-12 08:45:24 --> Config Class Initialized
DEBUG - 2013-04-12 08:45:24 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:45:24 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:45:24 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:45:24 --> URI Class Initialized
DEBUG - 2013-04-12 08:45:24 --> Router Class Initialized
DEBUG - 2013-04-12 08:45:24 --> Output Class Initialized
DEBUG - 2013-04-12 08:45:24 --> Security Class Initialized
DEBUG - 2013-04-12 08:45:24 --> Input Class Initialized
DEBUG - 2013-04-12 08:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:45:24 --> Language Class Initialized
DEBUG - 2013-04-12 08:45:24 --> Loader Class Initialized
DEBUG - 2013-04-12 08:45:24 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:45:24 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:45:24 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:45:24 --> Session Class Initialized
DEBUG - 2013-04-12 08:45:24 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:45:24 --> Session routines successfully run
DEBUG - 2013-04-12 08:45:24 --> Controller Class Initialized
DEBUG - 2013-04-12 08:45:24 --> Language Class Initialized
DEBUG - 2013-04-12 08:45:24 --> Config Class Initialized
DEBUG - 2013-04-12 08:45:24 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:45:24 --> Loader Class Initialized
DEBUG - 2013-04-12 08:45:24 --> Model Class Initialized
DEBUG - 2013-04-12 08:45:24 --> Model Class Initialized
DEBUG - 2013-04-12 08:45:24 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:45:24 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:45:24 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-12 08:45:24 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:45:24 --> Final output sent to browser
DEBUG - 2013-04-12 08:45:24 --> Total execution time: 0.0304
DEBUG - 2013-04-12 08:45:27 --> Config Class Initialized
DEBUG - 2013-04-12 08:45:27 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:45:27 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:45:27 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:45:27 --> URI Class Initialized
DEBUG - 2013-04-12 08:45:27 --> Router Class Initialized
DEBUG - 2013-04-12 08:45:27 --> Output Class Initialized
DEBUG - 2013-04-12 08:45:27 --> Security Class Initialized
DEBUG - 2013-04-12 08:45:27 --> Input Class Initialized
DEBUG - 2013-04-12 08:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:45:27 --> Language Class Initialized
DEBUG - 2013-04-12 08:45:27 --> Loader Class Initialized
DEBUG - 2013-04-12 08:45:27 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:45:27 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:45:27 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:45:27 --> Session Class Initialized
DEBUG - 2013-04-12 08:45:27 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:45:27 --> Session routines successfully run
DEBUG - 2013-04-12 08:45:27 --> Controller Class Initialized
DEBUG - 2013-04-12 08:45:27 --> Language Class Initialized
DEBUG - 2013-04-12 08:45:27 --> Config Class Initialized
DEBUG - 2013-04-12 08:45:27 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:45:27 --> Loader Class Initialized
DEBUG - 2013-04-12 08:45:27 --> Model Class Initialized
DEBUG - 2013-04-12 08:45:27 --> Model Class Initialized
DEBUG - 2013-04-12 08:45:27 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:45:27 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:45:27 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-12 08:45:27 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:45:27 --> Final output sent to browser
DEBUG - 2013-04-12 08:45:27 --> Total execution time: 0.0241
DEBUG - 2013-04-12 08:45:38 --> Config Class Initialized
DEBUG - 2013-04-12 08:45:38 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:45:38 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:45:38 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:45:38 --> URI Class Initialized
DEBUG - 2013-04-12 08:45:38 --> Router Class Initialized
DEBUG - 2013-04-12 08:45:38 --> Output Class Initialized
DEBUG - 2013-04-12 08:45:38 --> Security Class Initialized
DEBUG - 2013-04-12 08:45:38 --> Input Class Initialized
DEBUG - 2013-04-12 08:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:45:38 --> Language Class Initialized
DEBUG - 2013-04-12 08:45:38 --> Loader Class Initialized
DEBUG - 2013-04-12 08:45:38 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:45:38 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:45:38 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:45:38 --> Session Class Initialized
DEBUG - 2013-04-12 08:45:38 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:45:38 --> Session routines successfully run
DEBUG - 2013-04-12 08:45:38 --> Controller Class Initialized
DEBUG - 2013-04-12 08:45:38 --> Language Class Initialized
DEBUG - 2013-04-12 08:45:38 --> Config Class Initialized
DEBUG - 2013-04-12 08:45:38 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:45:38 --> Loader Class Initialized
DEBUG - 2013-04-12 08:45:38 --> Model Class Initialized
DEBUG - 2013-04-12 08:45:38 --> Model Class Initialized
DEBUG - 2013-04-12 08:45:38 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:45:38 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:45:38 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-12 08:45:38 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:45:38 --> Final output sent to browser
DEBUG - 2013-04-12 08:45:38 --> Total execution time: 0.0278
DEBUG - 2013-04-12 08:45:40 --> Config Class Initialized
DEBUG - 2013-04-12 08:45:40 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:45:40 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:45:40 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:45:40 --> URI Class Initialized
DEBUG - 2013-04-12 08:45:40 --> Router Class Initialized
DEBUG - 2013-04-12 08:45:40 --> Output Class Initialized
DEBUG - 2013-04-12 08:45:40 --> Security Class Initialized
DEBUG - 2013-04-12 08:45:40 --> Input Class Initialized
DEBUG - 2013-04-12 08:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:45:40 --> Language Class Initialized
DEBUG - 2013-04-12 08:45:40 --> Loader Class Initialized
DEBUG - 2013-04-12 08:45:40 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:45:40 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:45:40 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:45:40 --> Session Class Initialized
DEBUG - 2013-04-12 08:45:40 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:45:40 --> Session routines successfully run
DEBUG - 2013-04-12 08:45:40 --> Controller Class Initialized
DEBUG - 2013-04-12 08:45:40 --> Language Class Initialized
DEBUG - 2013-04-12 08:45:40 --> Config Class Initialized
DEBUG - 2013-04-12 08:45:40 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:45:40 --> Loader Class Initialized
DEBUG - 2013-04-12 08:45:40 --> Model Class Initialized
DEBUG - 2013-04-12 08:45:40 --> Model Class Initialized
DEBUG - 2013-04-12 08:45:40 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:45:40 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:45:40 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:45:40 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:45:40 --> Final output sent to browser
DEBUG - 2013-04-12 08:45:40 --> Total execution time: 0.0224
DEBUG - 2013-04-12 08:49:21 --> Config Class Initialized
DEBUG - 2013-04-12 08:49:21 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:49:21 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:49:21 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:49:21 --> URI Class Initialized
DEBUG - 2013-04-12 08:49:21 --> Router Class Initialized
DEBUG - 2013-04-12 08:49:21 --> Output Class Initialized
DEBUG - 2013-04-12 08:49:21 --> Security Class Initialized
DEBUG - 2013-04-12 08:49:21 --> Input Class Initialized
DEBUG - 2013-04-12 08:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:49:21 --> Language Class Initialized
DEBUG - 2013-04-12 08:49:21 --> Loader Class Initialized
DEBUG - 2013-04-12 08:49:21 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:49:21 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:49:21 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:49:21 --> Session Class Initialized
DEBUG - 2013-04-12 08:49:21 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:49:21 --> Session routines successfully run
DEBUG - 2013-04-12 08:49:21 --> Controller Class Initialized
DEBUG - 2013-04-12 08:49:21 --> Language Class Initialized
DEBUG - 2013-04-12 08:49:21 --> Config Class Initialized
DEBUG - 2013-04-12 08:49:21 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:49:21 --> Loader Class Initialized
DEBUG - 2013-04-12 08:49:21 --> Model Class Initialized
DEBUG - 2013-04-12 08:49:21 --> Model Class Initialized
DEBUG - 2013-04-12 08:49:21 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:49:21 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:49:21 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:49:21 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:49:21 --> Final output sent to browser
DEBUG - 2013-04-12 08:49:21 --> Total execution time: 0.0306
DEBUG - 2013-04-12 08:49:49 --> Config Class Initialized
DEBUG - 2013-04-12 08:49:49 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:49:49 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:49:49 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:49:49 --> URI Class Initialized
DEBUG - 2013-04-12 08:49:49 --> Router Class Initialized
DEBUG - 2013-04-12 08:49:49 --> Output Class Initialized
DEBUG - 2013-04-12 08:49:49 --> Security Class Initialized
DEBUG - 2013-04-12 08:49:49 --> Input Class Initialized
DEBUG - 2013-04-12 08:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:49:49 --> Language Class Initialized
DEBUG - 2013-04-12 08:49:49 --> Loader Class Initialized
DEBUG - 2013-04-12 08:49:49 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:49:49 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:49:49 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:49:49 --> Session Class Initialized
DEBUG - 2013-04-12 08:49:49 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:49:49 --> Session routines successfully run
DEBUG - 2013-04-12 08:49:49 --> Controller Class Initialized
DEBUG - 2013-04-12 08:49:49 --> Language Class Initialized
DEBUG - 2013-04-12 08:49:49 --> Config Class Initialized
DEBUG - 2013-04-12 08:49:49 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:49:49 --> Loader Class Initialized
DEBUG - 2013-04-12 08:49:49 --> Model Class Initialized
DEBUG - 2013-04-12 08:49:49 --> Model Class Initialized
DEBUG - 2013-04-12 08:49:49 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:49:49 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:49:49 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:49:49 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:49:49 --> Final output sent to browser
DEBUG - 2013-04-12 08:49:49 --> Total execution time: 0.0249
DEBUG - 2013-04-12 08:50:06 --> Config Class Initialized
DEBUG - 2013-04-12 08:50:06 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:50:06 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:50:06 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:50:06 --> URI Class Initialized
DEBUG - 2013-04-12 08:50:06 --> Router Class Initialized
DEBUG - 2013-04-12 08:50:06 --> Output Class Initialized
DEBUG - 2013-04-12 08:50:06 --> Security Class Initialized
DEBUG - 2013-04-12 08:50:06 --> Input Class Initialized
DEBUG - 2013-04-12 08:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:50:06 --> Language Class Initialized
DEBUG - 2013-04-12 08:50:06 --> Loader Class Initialized
DEBUG - 2013-04-12 08:50:06 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:50:06 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:50:06 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:50:06 --> Session Class Initialized
DEBUG - 2013-04-12 08:50:06 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:50:06 --> Session routines successfully run
DEBUG - 2013-04-12 08:50:06 --> Controller Class Initialized
DEBUG - 2013-04-12 08:50:06 --> Language Class Initialized
DEBUG - 2013-04-12 08:50:06 --> Config Class Initialized
DEBUG - 2013-04-12 08:50:06 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:50:06 --> Loader Class Initialized
DEBUG - 2013-04-12 08:50:06 --> Model Class Initialized
DEBUG - 2013-04-12 08:50:06 --> Model Class Initialized
DEBUG - 2013-04-12 08:50:06 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:50:06 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:50:06 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:50:06 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:50:06 --> Final output sent to browser
DEBUG - 2013-04-12 08:50:06 --> Total execution time: 0.0242
DEBUG - 2013-04-12 08:52:18 --> Config Class Initialized
DEBUG - 2013-04-12 08:52:18 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:52:18 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:52:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:52:18 --> URI Class Initialized
DEBUG - 2013-04-12 08:52:18 --> Router Class Initialized
DEBUG - 2013-04-12 08:52:18 --> Output Class Initialized
DEBUG - 2013-04-12 08:52:18 --> Security Class Initialized
DEBUG - 2013-04-12 08:52:18 --> Input Class Initialized
DEBUG - 2013-04-12 08:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:52:18 --> Language Class Initialized
DEBUG - 2013-04-12 08:52:18 --> Loader Class Initialized
DEBUG - 2013-04-12 08:52:18 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:52:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:52:18 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:52:18 --> Session Class Initialized
DEBUG - 2013-04-12 08:52:18 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:52:18 --> Session routines successfully run
DEBUG - 2013-04-12 08:52:18 --> Controller Class Initialized
DEBUG - 2013-04-12 08:52:18 --> Language Class Initialized
DEBUG - 2013-04-12 08:52:18 --> Config Class Initialized
DEBUG - 2013-04-12 08:52:18 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:52:18 --> Loader Class Initialized
DEBUG - 2013-04-12 08:52:18 --> Model Class Initialized
DEBUG - 2013-04-12 08:52:18 --> Model Class Initialized
DEBUG - 2013-04-12 08:52:18 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:52:18 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:52:18 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:52:18 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:52:18 --> Final output sent to browser
DEBUG - 2013-04-12 08:52:18 --> Total execution time: 0.0300
DEBUG - 2013-04-12 08:52:54 --> Config Class Initialized
DEBUG - 2013-04-12 08:52:54 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:52:54 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:52:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:52:54 --> URI Class Initialized
DEBUG - 2013-04-12 08:52:54 --> Router Class Initialized
DEBUG - 2013-04-12 08:52:54 --> Output Class Initialized
DEBUG - 2013-04-12 08:52:54 --> Security Class Initialized
DEBUG - 2013-04-12 08:52:54 --> Input Class Initialized
DEBUG - 2013-04-12 08:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:52:54 --> Language Class Initialized
DEBUG - 2013-04-12 08:52:54 --> Loader Class Initialized
DEBUG - 2013-04-12 08:52:54 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:52:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:52:54 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:52:54 --> Session Class Initialized
DEBUG - 2013-04-12 08:52:54 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:52:54 --> Session routines successfully run
DEBUG - 2013-04-12 08:52:54 --> Controller Class Initialized
DEBUG - 2013-04-12 08:52:54 --> Language Class Initialized
DEBUG - 2013-04-12 08:52:54 --> Config Class Initialized
DEBUG - 2013-04-12 08:52:54 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:52:54 --> Loader Class Initialized
DEBUG - 2013-04-12 08:52:54 --> Model Class Initialized
DEBUG - 2013-04-12 08:52:54 --> Model Class Initialized
DEBUG - 2013-04-12 08:52:54 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:52:54 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:52:54 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:52:54 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:52:54 --> Final output sent to browser
DEBUG - 2013-04-12 08:52:54 --> Total execution time: 0.0301
DEBUG - 2013-04-12 08:53:18 --> Config Class Initialized
DEBUG - 2013-04-12 08:53:18 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:53:18 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:53:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:53:18 --> URI Class Initialized
DEBUG - 2013-04-12 08:53:18 --> Router Class Initialized
DEBUG - 2013-04-12 08:53:18 --> Output Class Initialized
DEBUG - 2013-04-12 08:53:18 --> Security Class Initialized
DEBUG - 2013-04-12 08:53:18 --> Input Class Initialized
DEBUG - 2013-04-12 08:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:53:18 --> Language Class Initialized
DEBUG - 2013-04-12 08:53:18 --> Loader Class Initialized
DEBUG - 2013-04-12 08:53:18 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:53:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:53:18 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:53:18 --> Session Class Initialized
DEBUG - 2013-04-12 08:53:18 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:53:18 --> Session routines successfully run
DEBUG - 2013-04-12 08:53:18 --> Controller Class Initialized
DEBUG - 2013-04-12 08:53:18 --> Language Class Initialized
DEBUG - 2013-04-12 08:53:18 --> Config Class Initialized
DEBUG - 2013-04-12 08:53:18 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:53:18 --> Loader Class Initialized
DEBUG - 2013-04-12 08:53:18 --> Model Class Initialized
DEBUG - 2013-04-12 08:53:18 --> Model Class Initialized
DEBUG - 2013-04-12 08:53:18 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:53:18 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:53:18 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:53:18 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:53:18 --> Final output sent to browser
DEBUG - 2013-04-12 08:53:18 --> Total execution time: 0.0226
DEBUG - 2013-04-12 08:53:28 --> Config Class Initialized
DEBUG - 2013-04-12 08:53:28 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:53:28 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:53:28 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:53:28 --> URI Class Initialized
DEBUG - 2013-04-12 08:53:28 --> Router Class Initialized
DEBUG - 2013-04-12 08:53:28 --> Output Class Initialized
DEBUG - 2013-04-12 08:53:28 --> Security Class Initialized
DEBUG - 2013-04-12 08:53:28 --> Input Class Initialized
DEBUG - 2013-04-12 08:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:53:28 --> Language Class Initialized
DEBUG - 2013-04-12 08:53:28 --> Loader Class Initialized
DEBUG - 2013-04-12 08:53:28 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:53:28 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:53:28 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:53:28 --> Session Class Initialized
DEBUG - 2013-04-12 08:53:28 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:53:28 --> Session routines successfully run
DEBUG - 2013-04-12 08:53:28 --> Controller Class Initialized
DEBUG - 2013-04-12 08:53:28 --> Language Class Initialized
DEBUG - 2013-04-12 08:53:28 --> Config Class Initialized
DEBUG - 2013-04-12 08:53:28 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:53:28 --> Loader Class Initialized
DEBUG - 2013-04-12 08:53:28 --> Model Class Initialized
DEBUG - 2013-04-12 08:53:28 --> Model Class Initialized
DEBUG - 2013-04-12 08:53:28 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:53:28 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:53:28 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:53:28 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:53:28 --> Final output sent to browser
DEBUG - 2013-04-12 08:53:28 --> Total execution time: 0.0342
DEBUG - 2013-04-12 08:53:38 --> Config Class Initialized
DEBUG - 2013-04-12 08:53:38 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:53:38 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:53:38 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:53:38 --> URI Class Initialized
DEBUG - 2013-04-12 08:53:38 --> Router Class Initialized
DEBUG - 2013-04-12 08:53:38 --> Output Class Initialized
DEBUG - 2013-04-12 08:53:38 --> Security Class Initialized
DEBUG - 2013-04-12 08:53:38 --> Input Class Initialized
DEBUG - 2013-04-12 08:53:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:53:38 --> Language Class Initialized
DEBUG - 2013-04-12 08:53:38 --> Loader Class Initialized
DEBUG - 2013-04-12 08:53:38 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:53:38 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:53:38 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:53:38 --> Session Class Initialized
DEBUG - 2013-04-12 08:53:38 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:53:38 --> Session routines successfully run
DEBUG - 2013-04-12 08:53:38 --> Controller Class Initialized
DEBUG - 2013-04-12 08:53:38 --> Language Class Initialized
DEBUG - 2013-04-12 08:53:38 --> Config Class Initialized
DEBUG - 2013-04-12 08:53:38 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:53:38 --> Loader Class Initialized
DEBUG - 2013-04-12 08:53:38 --> Model Class Initialized
DEBUG - 2013-04-12 08:53:38 --> Model Class Initialized
DEBUG - 2013-04-12 08:53:38 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:53:38 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:53:38 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:53:38 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:53:38 --> Final output sent to browser
DEBUG - 2013-04-12 08:53:38 --> Total execution time: 0.0320
DEBUG - 2013-04-12 08:53:44 --> Config Class Initialized
DEBUG - 2013-04-12 08:53:44 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:53:44 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:53:44 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:53:44 --> URI Class Initialized
DEBUG - 2013-04-12 08:53:44 --> Router Class Initialized
DEBUG - 2013-04-12 08:53:44 --> Output Class Initialized
DEBUG - 2013-04-12 08:53:44 --> Security Class Initialized
DEBUG - 2013-04-12 08:53:44 --> Input Class Initialized
DEBUG - 2013-04-12 08:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:53:44 --> Language Class Initialized
DEBUG - 2013-04-12 08:53:44 --> Loader Class Initialized
DEBUG - 2013-04-12 08:53:44 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:53:44 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:53:44 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:53:44 --> Session Class Initialized
DEBUG - 2013-04-12 08:53:44 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:53:44 --> Session routines successfully run
DEBUG - 2013-04-12 08:53:44 --> Controller Class Initialized
DEBUG - 2013-04-12 08:53:44 --> Language Class Initialized
DEBUG - 2013-04-12 08:53:44 --> Config Class Initialized
DEBUG - 2013-04-12 08:53:44 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:53:44 --> Loader Class Initialized
DEBUG - 2013-04-12 08:53:44 --> Model Class Initialized
DEBUG - 2013-04-12 08:53:44 --> Model Class Initialized
DEBUG - 2013-04-12 08:53:44 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:53:44 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:53:44 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:53:44 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:53:44 --> Final output sent to browser
DEBUG - 2013-04-12 08:53:44 --> Total execution time: 0.0320
DEBUG - 2013-04-12 08:53:58 --> Config Class Initialized
DEBUG - 2013-04-12 08:53:58 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:53:58 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:53:58 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:53:58 --> URI Class Initialized
DEBUG - 2013-04-12 08:53:58 --> Router Class Initialized
DEBUG - 2013-04-12 08:53:58 --> Output Class Initialized
DEBUG - 2013-04-12 08:53:58 --> Security Class Initialized
DEBUG - 2013-04-12 08:53:58 --> Input Class Initialized
DEBUG - 2013-04-12 08:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:53:58 --> Language Class Initialized
DEBUG - 2013-04-12 08:53:58 --> Loader Class Initialized
DEBUG - 2013-04-12 08:53:58 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:53:58 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:53:58 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:53:58 --> Session Class Initialized
DEBUG - 2013-04-12 08:53:58 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:53:58 --> Session routines successfully run
DEBUG - 2013-04-12 08:53:58 --> Controller Class Initialized
DEBUG - 2013-04-12 08:53:58 --> Language Class Initialized
DEBUG - 2013-04-12 08:53:58 --> Config Class Initialized
DEBUG - 2013-04-12 08:53:58 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:53:58 --> Loader Class Initialized
DEBUG - 2013-04-12 08:53:58 --> Model Class Initialized
DEBUG - 2013-04-12 08:53:58 --> Model Class Initialized
DEBUG - 2013-04-12 08:53:58 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:53:58 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:53:58 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:53:58 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:53:58 --> Final output sent to browser
DEBUG - 2013-04-12 08:53:58 --> Total execution time: 0.0227
DEBUG - 2013-04-12 08:54:14 --> Config Class Initialized
DEBUG - 2013-04-12 08:54:14 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:54:14 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:54:14 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:54:14 --> URI Class Initialized
DEBUG - 2013-04-12 08:54:14 --> Router Class Initialized
DEBUG - 2013-04-12 08:54:14 --> Output Class Initialized
DEBUG - 2013-04-12 08:54:14 --> Security Class Initialized
DEBUG - 2013-04-12 08:54:14 --> Input Class Initialized
DEBUG - 2013-04-12 08:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:54:14 --> Language Class Initialized
DEBUG - 2013-04-12 08:54:14 --> Loader Class Initialized
DEBUG - 2013-04-12 08:54:14 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:54:14 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:54:14 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:54:14 --> Session Class Initialized
DEBUG - 2013-04-12 08:54:14 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:54:14 --> Session routines successfully run
DEBUG - 2013-04-12 08:54:14 --> Controller Class Initialized
DEBUG - 2013-04-12 08:54:14 --> Language Class Initialized
DEBUG - 2013-04-12 08:54:14 --> Config Class Initialized
DEBUG - 2013-04-12 08:54:14 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:54:14 --> Loader Class Initialized
DEBUG - 2013-04-12 08:54:14 --> Model Class Initialized
DEBUG - 2013-04-12 08:54:14 --> Model Class Initialized
DEBUG - 2013-04-12 08:54:14 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:54:14 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:54:14 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:54:14 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:54:14 --> Final output sent to browser
DEBUG - 2013-04-12 08:54:14 --> Total execution time: 0.0229
DEBUG - 2013-04-12 08:56:04 --> Config Class Initialized
DEBUG - 2013-04-12 08:56:04 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:56:04 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:56:04 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:56:04 --> URI Class Initialized
DEBUG - 2013-04-12 08:56:04 --> Router Class Initialized
DEBUG - 2013-04-12 08:56:04 --> Output Class Initialized
DEBUG - 2013-04-12 08:56:04 --> Security Class Initialized
DEBUG - 2013-04-12 08:56:04 --> Input Class Initialized
DEBUG - 2013-04-12 08:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:56:04 --> Language Class Initialized
DEBUG - 2013-04-12 08:56:04 --> Loader Class Initialized
DEBUG - 2013-04-12 08:56:04 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:56:04 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:56:04 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:56:04 --> Session Class Initialized
DEBUG - 2013-04-12 08:56:04 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:56:04 --> Session routines successfully run
DEBUG - 2013-04-12 08:56:04 --> Controller Class Initialized
DEBUG - 2013-04-12 08:56:04 --> Language Class Initialized
DEBUG - 2013-04-12 08:56:04 --> Config Class Initialized
DEBUG - 2013-04-12 08:56:04 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:56:04 --> Loader Class Initialized
DEBUG - 2013-04-12 08:56:04 --> Model Class Initialized
DEBUG - 2013-04-12 08:56:04 --> Model Class Initialized
DEBUG - 2013-04-12 08:56:04 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:56:04 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:56:04 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:56:04 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:56:04 --> Final output sent to browser
DEBUG - 2013-04-12 08:56:04 --> Total execution time: 0.0306
DEBUG - 2013-04-12 08:56:25 --> Config Class Initialized
DEBUG - 2013-04-12 08:56:25 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:56:25 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:56:25 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:56:25 --> URI Class Initialized
DEBUG - 2013-04-12 08:56:25 --> Router Class Initialized
DEBUG - 2013-04-12 08:56:25 --> Output Class Initialized
DEBUG - 2013-04-12 08:56:25 --> Security Class Initialized
DEBUG - 2013-04-12 08:56:25 --> Input Class Initialized
DEBUG - 2013-04-12 08:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:56:25 --> Language Class Initialized
DEBUG - 2013-04-12 08:56:25 --> Loader Class Initialized
DEBUG - 2013-04-12 08:56:25 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:56:25 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:56:25 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:56:25 --> Session Class Initialized
DEBUG - 2013-04-12 08:56:25 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:56:25 --> Session routines successfully run
DEBUG - 2013-04-12 08:56:25 --> Controller Class Initialized
DEBUG - 2013-04-12 08:56:25 --> Language Class Initialized
DEBUG - 2013-04-12 08:56:25 --> Config Class Initialized
DEBUG - 2013-04-12 08:56:25 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:56:25 --> Loader Class Initialized
DEBUG - 2013-04-12 08:56:25 --> Model Class Initialized
DEBUG - 2013-04-12 08:56:25 --> Model Class Initialized
DEBUG - 2013-04-12 08:56:25 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:56:25 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:56:25 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:56:25 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:56:25 --> Final output sent to browser
DEBUG - 2013-04-12 08:56:25 --> Total execution time: 0.0262
DEBUG - 2013-04-12 08:56:50 --> Config Class Initialized
DEBUG - 2013-04-12 08:56:50 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:56:50 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:56:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:56:50 --> URI Class Initialized
DEBUG - 2013-04-12 08:56:50 --> Router Class Initialized
DEBUG - 2013-04-12 08:56:50 --> Output Class Initialized
DEBUG - 2013-04-12 08:56:50 --> Security Class Initialized
DEBUG - 2013-04-12 08:56:50 --> Input Class Initialized
DEBUG - 2013-04-12 08:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:56:50 --> Language Class Initialized
DEBUG - 2013-04-12 08:56:50 --> Loader Class Initialized
DEBUG - 2013-04-12 08:56:50 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:56:50 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:56:50 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:56:50 --> Session Class Initialized
DEBUG - 2013-04-12 08:56:50 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:56:50 --> Session routines successfully run
DEBUG - 2013-04-12 08:56:50 --> Controller Class Initialized
DEBUG - 2013-04-12 08:56:50 --> Language Class Initialized
DEBUG - 2013-04-12 08:56:50 --> Config Class Initialized
DEBUG - 2013-04-12 08:56:50 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:56:50 --> Loader Class Initialized
DEBUG - 2013-04-12 08:56:50 --> Model Class Initialized
DEBUG - 2013-04-12 08:56:50 --> Model Class Initialized
DEBUG - 2013-04-12 08:56:50 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:56:50 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:56:50 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:56:50 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:56:50 --> Final output sent to browser
DEBUG - 2013-04-12 08:56:50 --> Total execution time: 0.0313
DEBUG - 2013-04-12 08:56:55 --> Config Class Initialized
DEBUG - 2013-04-12 08:56:55 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:56:55 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:56:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:56:55 --> URI Class Initialized
DEBUG - 2013-04-12 08:56:55 --> Router Class Initialized
DEBUG - 2013-04-12 08:56:55 --> Output Class Initialized
DEBUG - 2013-04-12 08:56:55 --> Security Class Initialized
DEBUG - 2013-04-12 08:56:55 --> Input Class Initialized
DEBUG - 2013-04-12 08:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:56:55 --> Language Class Initialized
DEBUG - 2013-04-12 08:56:55 --> Loader Class Initialized
DEBUG - 2013-04-12 08:56:55 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:56:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:56:55 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:56:55 --> Session Class Initialized
DEBUG - 2013-04-12 08:56:55 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:56:55 --> Session routines successfully run
DEBUG - 2013-04-12 08:56:55 --> Controller Class Initialized
DEBUG - 2013-04-12 08:56:55 --> Language Class Initialized
DEBUG - 2013-04-12 08:56:55 --> Config Class Initialized
DEBUG - 2013-04-12 08:56:55 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:56:55 --> Loader Class Initialized
DEBUG - 2013-04-12 08:56:55 --> Model Class Initialized
DEBUG - 2013-04-12 08:56:55 --> Model Class Initialized
DEBUG - 2013-04-12 08:56:55 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:56:55 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:56:55 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:56:55 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:56:55 --> Final output sent to browser
DEBUG - 2013-04-12 08:56:55 --> Total execution time: 0.0244
DEBUG - 2013-04-12 08:56:56 --> Config Class Initialized
DEBUG - 2013-04-12 08:56:56 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:56:56 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:56:56 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:56:56 --> URI Class Initialized
DEBUG - 2013-04-12 08:56:56 --> Router Class Initialized
DEBUG - 2013-04-12 08:56:56 --> Output Class Initialized
DEBUG - 2013-04-12 08:56:56 --> Security Class Initialized
DEBUG - 2013-04-12 08:56:56 --> Input Class Initialized
DEBUG - 2013-04-12 08:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:56:56 --> Language Class Initialized
DEBUG - 2013-04-12 08:56:56 --> Loader Class Initialized
DEBUG - 2013-04-12 08:56:56 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:56:56 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:56:56 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:56:56 --> Session Class Initialized
DEBUG - 2013-04-12 08:56:56 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:56:56 --> Session routines successfully run
DEBUG - 2013-04-12 08:56:56 --> Controller Class Initialized
DEBUG - 2013-04-12 08:56:56 --> Language Class Initialized
DEBUG - 2013-04-12 08:56:56 --> Config Class Initialized
DEBUG - 2013-04-12 08:56:56 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:56:56 --> Loader Class Initialized
DEBUG - 2013-04-12 08:56:56 --> Model Class Initialized
DEBUG - 2013-04-12 08:56:56 --> Model Class Initialized
DEBUG - 2013-04-12 08:56:56 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:56:56 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:56:56 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:56:56 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:56:56 --> Final output sent to browser
DEBUG - 2013-04-12 08:56:56 --> Total execution time: 0.0276
DEBUG - 2013-04-12 08:56:57 --> Config Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:56:57 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:56:57 --> URI Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Router Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Output Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Security Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Input Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:56:57 --> Language Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Loader Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:56:57 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:56:57 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:56:57 --> Session Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:56:57 --> Session routines successfully run
DEBUG - 2013-04-12 08:56:57 --> Controller Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Language Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Config Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:56:57 --> Loader Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Model Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Model Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:56:57 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:56:57 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:56:57 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:56:57 --> Final output sent to browser
DEBUG - 2013-04-12 08:56:57 --> Total execution time: 0.0235
DEBUG - 2013-04-12 08:56:57 --> Config Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:56:57 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:56:57 --> URI Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Router Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Output Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Security Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Input Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:56:57 --> Language Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Loader Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:56:57 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:56:57 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:56:57 --> Session Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:56:57 --> Session routines successfully run
DEBUG - 2013-04-12 08:56:57 --> Controller Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Language Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Config Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:56:57 --> Loader Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Model Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Model Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:56:57 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:56:57 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:56:57 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:56:57 --> Final output sent to browser
DEBUG - 2013-04-12 08:56:57 --> Total execution time: 0.0301
DEBUG - 2013-04-12 08:56:57 --> Config Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:56:57 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:56:57 --> URI Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Router Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Output Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Security Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Input Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:56:57 --> Language Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Loader Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:56:57 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:56:57 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:56:57 --> Session Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:56:57 --> Session routines successfully run
DEBUG - 2013-04-12 08:56:57 --> Controller Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Language Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Config Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:56:57 --> Loader Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Model Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Model Class Initialized
DEBUG - 2013-04-12 08:56:57 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:56:57 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:56:57 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:56:57 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:56:57 --> Final output sent to browser
DEBUG - 2013-04-12 08:56:57 --> Total execution time: 0.0240
DEBUG - 2013-04-12 08:57:14 --> Config Class Initialized
DEBUG - 2013-04-12 08:57:14 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:57:14 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:57:14 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:57:14 --> URI Class Initialized
DEBUG - 2013-04-12 08:57:14 --> Router Class Initialized
DEBUG - 2013-04-12 08:57:14 --> Output Class Initialized
DEBUG - 2013-04-12 08:57:14 --> Security Class Initialized
DEBUG - 2013-04-12 08:57:14 --> Input Class Initialized
DEBUG - 2013-04-12 08:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:57:14 --> Language Class Initialized
DEBUG - 2013-04-12 08:57:14 --> Loader Class Initialized
DEBUG - 2013-04-12 08:57:14 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:57:14 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:57:14 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:57:14 --> Session Class Initialized
DEBUG - 2013-04-12 08:57:14 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:57:14 --> Session routines successfully run
DEBUG - 2013-04-12 08:57:14 --> Controller Class Initialized
DEBUG - 2013-04-12 08:57:14 --> Language Class Initialized
DEBUG - 2013-04-12 08:57:14 --> Config Class Initialized
DEBUG - 2013-04-12 08:57:14 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 08:57:14 --> Loader Class Initialized
DEBUG - 2013-04-12 08:57:14 --> Model Class Initialized
DEBUG - 2013-04-12 08:57:14 --> Model Class Initialized
DEBUG - 2013-04-12 08:57:14 --> Database Driver Class Initialized
DEBUG - 2013-04-12 08:57:14 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 08:57:14 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 08:57:14 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:57:14 --> Final output sent to browser
DEBUG - 2013-04-12 08:57:14 --> Total execution time: 0.0220
DEBUG - 2013-04-12 08:59:16 --> Config Class Initialized
DEBUG - 2013-04-12 08:59:16 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:59:16 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:59:16 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:59:16 --> URI Class Initialized
DEBUG - 2013-04-12 08:59:16 --> Router Class Initialized
DEBUG - 2013-04-12 08:59:16 --> Output Class Initialized
DEBUG - 2013-04-12 08:59:16 --> Security Class Initialized
DEBUG - 2013-04-12 08:59:16 --> Input Class Initialized
DEBUG - 2013-04-12 08:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:59:16 --> Language Class Initialized
DEBUG - 2013-04-12 08:59:16 --> Loader Class Initialized
DEBUG - 2013-04-12 08:59:16 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:59:16 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:59:16 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:59:16 --> Session Class Initialized
DEBUG - 2013-04-12 08:59:16 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:59:16 --> Session routines successfully run
DEBUG - 2013-04-12 08:59:16 --> Controller Class Initialized
DEBUG - 2013-04-12 08:59:16 --> Language Class Initialized
DEBUG - 2013-04-12 08:59:16 --> Config Class Initialized
DEBUG - 2013-04-12 08:59:16 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-12 08:59:16 --> Loader Class Initialized
DEBUG - 2013-04-12 08:59:16 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-12 08:59:16 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 08:59:16 --> Final output sent to browser
DEBUG - 2013-04-12 08:59:16 --> Total execution time: 0.0196
DEBUG - 2013-04-12 08:59:22 --> Config Class Initialized
DEBUG - 2013-04-12 08:59:22 --> Hooks Class Initialized
DEBUG - 2013-04-12 08:59:22 --> Utf8 Class Initialized
DEBUG - 2013-04-12 08:59:22 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 08:59:22 --> URI Class Initialized
DEBUG - 2013-04-12 08:59:22 --> Router Class Initialized
DEBUG - 2013-04-12 08:59:22 --> No URI present. Default controller set.
DEBUG - 2013-04-12 08:59:22 --> Output Class Initialized
DEBUG - 2013-04-12 08:59:22 --> Security Class Initialized
DEBUG - 2013-04-12 08:59:22 --> Input Class Initialized
DEBUG - 2013-04-12 08:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 08:59:22 --> Language Class Initialized
DEBUG - 2013-04-12 08:59:22 --> Loader Class Initialized
DEBUG - 2013-04-12 08:59:22 --> Helper loaded: url_helper
DEBUG - 2013-04-12 08:59:22 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 08:59:22 --> Helper loaded: text_helper
DEBUG - 2013-04-12 08:59:22 --> Session Class Initialized
DEBUG - 2013-04-12 08:59:22 --> Helper loaded: string_helper
DEBUG - 2013-04-12 08:59:22 --> Session routines successfully run
DEBUG - 2013-04-12 08:59:22 --> Controller Class Initialized
DEBUG - 2013-04-12 08:59:22 --> Language Class Initialized
DEBUG - 2013-04-12 08:59:22 --> Config Class Initialized
DEBUG - 2013-04-12 08:59:22 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-12 08:59:22 --> Loader Class Initialized
DEBUG - 2013-04-12 08:59:22 --> File loaded: ../application/admin/modules/autenticacao/views/login.php
DEBUG - 2013-04-12 08:59:22 --> Final output sent to browser
DEBUG - 2013-04-12 08:59:22 --> Total execution time: 0.0165
DEBUG - 2013-04-12 09:00:58 --> Config Class Initialized
DEBUG - 2013-04-12 09:00:58 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:00:58 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:00:58 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:00:58 --> URI Class Initialized
DEBUG - 2013-04-12 09:00:58 --> Router Class Initialized
DEBUG - 2013-04-12 09:00:58 --> Output Class Initialized
DEBUG - 2013-04-12 09:00:58 --> Security Class Initialized
DEBUG - 2013-04-12 09:00:58 --> Input Class Initialized
DEBUG - 2013-04-12 09:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:00:58 --> Language Class Initialized
DEBUG - 2013-04-12 09:00:58 --> Loader Class Initialized
DEBUG - 2013-04-12 09:00:58 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:00:58 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:00:58 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:00:58 --> Session Class Initialized
DEBUG - 2013-04-12 09:00:58 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:00:58 --> Session routines successfully run
DEBUG - 2013-04-12 09:00:58 --> Controller Class Initialized
DEBUG - 2013-04-12 09:00:58 --> Language Class Initialized
DEBUG - 2013-04-12 09:00:58 --> Config Class Initialized
DEBUG - 2013-04-12 09:00:58 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:00:58 --> Loader Class Initialized
DEBUG - 2013-04-12 09:00:58 --> Model Class Initialized
DEBUG - 2013-04-12 09:00:58 --> Model Class Initialized
DEBUG - 2013-04-12 09:00:58 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:00:58 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:00:58 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-12 09:00:58 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:00:58 --> Final output sent to browser
DEBUG - 2013-04-12 09:00:58 --> Total execution time: 0.0308
DEBUG - 2013-04-12 09:01:00 --> Config Class Initialized
DEBUG - 2013-04-12 09:01:00 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:01:00 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:01:00 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:01:00 --> URI Class Initialized
DEBUG - 2013-04-12 09:01:00 --> Router Class Initialized
DEBUG - 2013-04-12 09:01:00 --> Output Class Initialized
DEBUG - 2013-04-12 09:01:00 --> Security Class Initialized
DEBUG - 2013-04-12 09:01:00 --> Input Class Initialized
DEBUG - 2013-04-12 09:01:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:01:00 --> Language Class Initialized
DEBUG - 2013-04-12 09:01:00 --> Loader Class Initialized
DEBUG - 2013-04-12 09:01:00 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:01:00 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:01:00 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:01:00 --> Session Class Initialized
DEBUG - 2013-04-12 09:01:00 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:01:00 --> Session routines successfully run
DEBUG - 2013-04-12 09:01:00 --> Controller Class Initialized
DEBUG - 2013-04-12 09:01:00 --> Language Class Initialized
DEBUG - 2013-04-12 09:01:00 --> Config Class Initialized
DEBUG - 2013-04-12 09:01:00 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:01:00 --> Loader Class Initialized
DEBUG - 2013-04-12 09:01:00 --> Model Class Initialized
DEBUG - 2013-04-12 09:01:00 --> Model Class Initialized
DEBUG - 2013-04-12 09:01:00 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:01:00 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:01:00 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:01:00 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:01:00 --> Final output sent to browser
DEBUG - 2013-04-12 09:01:00 --> Total execution time: 0.0263
DEBUG - 2013-04-12 09:17:30 --> Config Class Initialized
DEBUG - 2013-04-12 09:17:30 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:17:30 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:17:30 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:17:30 --> URI Class Initialized
DEBUG - 2013-04-12 09:17:30 --> Router Class Initialized
DEBUG - 2013-04-12 09:17:30 --> Output Class Initialized
DEBUG - 2013-04-12 09:17:30 --> Security Class Initialized
DEBUG - 2013-04-12 09:17:30 --> Input Class Initialized
DEBUG - 2013-04-12 09:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:17:30 --> Language Class Initialized
DEBUG - 2013-04-12 09:17:30 --> Loader Class Initialized
DEBUG - 2013-04-12 09:17:30 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:17:30 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:17:30 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:17:30 --> Session Class Initialized
DEBUG - 2013-04-12 09:17:30 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:17:30 --> Session routines successfully run
DEBUG - 2013-04-12 09:17:30 --> Controller Class Initialized
DEBUG - 2013-04-12 09:17:30 --> Language Class Initialized
DEBUG - 2013-04-12 09:17:30 --> Config Class Initialized
DEBUG - 2013-04-12 09:17:30 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:17:30 --> Loader Class Initialized
DEBUG - 2013-04-12 09:17:30 --> Model Class Initialized
DEBUG - 2013-04-12 09:17:30 --> Model Class Initialized
DEBUG - 2013-04-12 09:17:30 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:17:30 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:17:30 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:17:30 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:17:30 --> Final output sent to browser
DEBUG - 2013-04-12 09:17:30 --> Total execution time: 0.0309
DEBUG - 2013-04-12 09:21:38 --> Config Class Initialized
DEBUG - 2013-04-12 09:21:38 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:21:38 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:21:38 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:21:38 --> URI Class Initialized
DEBUG - 2013-04-12 09:21:38 --> Router Class Initialized
DEBUG - 2013-04-12 09:21:38 --> Output Class Initialized
DEBUG - 2013-04-12 09:21:38 --> Security Class Initialized
DEBUG - 2013-04-12 09:21:38 --> Input Class Initialized
DEBUG - 2013-04-12 09:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:21:38 --> Language Class Initialized
DEBUG - 2013-04-12 09:21:38 --> Loader Class Initialized
DEBUG - 2013-04-12 09:21:38 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:21:38 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:21:38 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:21:38 --> Session Class Initialized
DEBUG - 2013-04-12 09:21:38 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:21:38 --> Session routines successfully run
DEBUG - 2013-04-12 09:21:38 --> Controller Class Initialized
DEBUG - 2013-04-12 09:21:38 --> Language Class Initialized
DEBUG - 2013-04-12 09:21:38 --> Config Class Initialized
DEBUG - 2013-04-12 09:21:38 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:21:38 --> Loader Class Initialized
DEBUG - 2013-04-12 09:21:38 --> Model Class Initialized
DEBUG - 2013-04-12 09:21:38 --> Model Class Initialized
DEBUG - 2013-04-12 09:21:38 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:21:38 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:21:38 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:21:38 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:21:38 --> Final output sent to browser
DEBUG - 2013-04-12 09:21:38 --> Total execution time: 0.0260
DEBUG - 2013-04-12 09:21:49 --> Config Class Initialized
DEBUG - 2013-04-12 09:21:49 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:21:49 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:21:49 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:21:49 --> URI Class Initialized
DEBUG - 2013-04-12 09:21:49 --> Router Class Initialized
DEBUG - 2013-04-12 09:21:49 --> Output Class Initialized
DEBUG - 2013-04-12 09:21:49 --> Security Class Initialized
DEBUG - 2013-04-12 09:21:49 --> Input Class Initialized
DEBUG - 2013-04-12 09:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:21:49 --> Language Class Initialized
DEBUG - 2013-04-12 09:21:49 --> Loader Class Initialized
DEBUG - 2013-04-12 09:21:49 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:21:49 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:21:49 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:21:49 --> Session Class Initialized
DEBUG - 2013-04-12 09:21:49 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:21:49 --> Session routines successfully run
DEBUG - 2013-04-12 09:21:49 --> Controller Class Initialized
DEBUG - 2013-04-12 09:21:49 --> Language Class Initialized
DEBUG - 2013-04-12 09:21:49 --> Config Class Initialized
DEBUG - 2013-04-12 09:21:49 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:21:49 --> Loader Class Initialized
DEBUG - 2013-04-12 09:21:49 --> Model Class Initialized
DEBUG - 2013-04-12 09:21:49 --> Model Class Initialized
DEBUG - 2013-04-12 09:21:49 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:21:49 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:21:49 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:21:49 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:21:49 --> Final output sent to browser
DEBUG - 2013-04-12 09:21:49 --> Total execution time: 0.0308
DEBUG - 2013-04-12 09:22:51 --> Config Class Initialized
DEBUG - 2013-04-12 09:22:51 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:22:51 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:22:51 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:22:51 --> URI Class Initialized
DEBUG - 2013-04-12 09:22:51 --> Router Class Initialized
DEBUG - 2013-04-12 09:22:51 --> Output Class Initialized
DEBUG - 2013-04-12 09:22:51 --> Security Class Initialized
DEBUG - 2013-04-12 09:22:51 --> Input Class Initialized
DEBUG - 2013-04-12 09:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:22:51 --> Language Class Initialized
DEBUG - 2013-04-12 09:22:51 --> Loader Class Initialized
DEBUG - 2013-04-12 09:22:51 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:22:51 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:22:51 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:22:51 --> Session Class Initialized
DEBUG - 2013-04-12 09:22:51 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:22:51 --> Session routines successfully run
DEBUG - 2013-04-12 09:22:51 --> Controller Class Initialized
DEBUG - 2013-04-12 09:22:51 --> Language Class Initialized
DEBUG - 2013-04-12 09:22:51 --> Config Class Initialized
DEBUG - 2013-04-12 09:22:51 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:22:51 --> Loader Class Initialized
DEBUG - 2013-04-12 09:22:51 --> Model Class Initialized
DEBUG - 2013-04-12 09:22:51 --> Model Class Initialized
DEBUG - 2013-04-12 09:22:51 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:22:51 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:22:51 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:22:51 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:22:51 --> Final output sent to browser
DEBUG - 2013-04-12 09:22:51 --> Total execution time: 0.0236
DEBUG - 2013-04-12 09:22:53 --> Config Class Initialized
DEBUG - 2013-04-12 09:22:53 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:22:53 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:22:53 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:22:53 --> URI Class Initialized
DEBUG - 2013-04-12 09:22:53 --> Router Class Initialized
DEBUG - 2013-04-12 09:22:53 --> Output Class Initialized
DEBUG - 2013-04-12 09:22:53 --> Security Class Initialized
DEBUG - 2013-04-12 09:22:53 --> Input Class Initialized
DEBUG - 2013-04-12 09:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:22:53 --> Language Class Initialized
DEBUG - 2013-04-12 09:22:53 --> Loader Class Initialized
DEBUG - 2013-04-12 09:22:53 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:22:53 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:22:53 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:22:53 --> Session Class Initialized
DEBUG - 2013-04-12 09:22:53 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:22:53 --> Session routines successfully run
DEBUG - 2013-04-12 09:22:53 --> Controller Class Initialized
DEBUG - 2013-04-12 09:22:53 --> Language Class Initialized
DEBUG - 2013-04-12 09:22:53 --> Config Class Initialized
DEBUG - 2013-04-12 09:22:53 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:22:53 --> Loader Class Initialized
DEBUG - 2013-04-12 09:22:53 --> Model Class Initialized
DEBUG - 2013-04-12 09:22:53 --> Model Class Initialized
DEBUG - 2013-04-12 09:22:53 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:22:53 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:22:53 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:22:53 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:22:53 --> Final output sent to browser
DEBUG - 2013-04-12 09:22:53 --> Total execution time: 0.0255
DEBUG - 2013-04-12 09:23:09 --> Config Class Initialized
DEBUG - 2013-04-12 09:23:09 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:23:09 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:23:09 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:23:09 --> URI Class Initialized
DEBUG - 2013-04-12 09:23:09 --> Router Class Initialized
DEBUG - 2013-04-12 09:23:09 --> Output Class Initialized
DEBUG - 2013-04-12 09:23:09 --> Security Class Initialized
DEBUG - 2013-04-12 09:23:09 --> Input Class Initialized
DEBUG - 2013-04-12 09:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:23:09 --> Language Class Initialized
DEBUG - 2013-04-12 09:23:09 --> Loader Class Initialized
DEBUG - 2013-04-12 09:23:09 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:23:09 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:23:09 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:23:09 --> Session Class Initialized
DEBUG - 2013-04-12 09:23:09 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:23:09 --> Session routines successfully run
DEBUG - 2013-04-12 09:23:09 --> Controller Class Initialized
DEBUG - 2013-04-12 09:23:09 --> Language Class Initialized
DEBUG - 2013-04-12 09:23:09 --> Config Class Initialized
DEBUG - 2013-04-12 09:23:09 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:23:09 --> Loader Class Initialized
DEBUG - 2013-04-12 09:23:09 --> Model Class Initialized
DEBUG - 2013-04-12 09:23:09 --> Model Class Initialized
DEBUG - 2013-04-12 09:23:09 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:23:09 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:23:09 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:23:09 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:23:09 --> Final output sent to browser
DEBUG - 2013-04-12 09:23:09 --> Total execution time: 0.0312
DEBUG - 2013-04-12 09:24:44 --> Config Class Initialized
DEBUG - 2013-04-12 09:24:44 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:24:44 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:24:44 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:24:44 --> URI Class Initialized
DEBUG - 2013-04-12 09:24:44 --> Router Class Initialized
DEBUG - 2013-04-12 09:24:44 --> Output Class Initialized
DEBUG - 2013-04-12 09:24:44 --> Security Class Initialized
DEBUG - 2013-04-12 09:24:44 --> Input Class Initialized
DEBUG - 2013-04-12 09:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:24:44 --> Language Class Initialized
DEBUG - 2013-04-12 09:24:44 --> Loader Class Initialized
DEBUG - 2013-04-12 09:24:44 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:24:44 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:24:44 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:24:44 --> Session Class Initialized
DEBUG - 2013-04-12 09:24:44 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:24:44 --> Session routines successfully run
DEBUG - 2013-04-12 09:24:44 --> Controller Class Initialized
DEBUG - 2013-04-12 09:24:44 --> Language Class Initialized
DEBUG - 2013-04-12 09:24:44 --> Config Class Initialized
DEBUG - 2013-04-12 09:24:44 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:24:44 --> Loader Class Initialized
DEBUG - 2013-04-12 09:24:44 --> Model Class Initialized
DEBUG - 2013-04-12 09:24:44 --> Model Class Initialized
DEBUG - 2013-04-12 09:24:44 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:24:44 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:24:44 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:24:44 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:24:44 --> Final output sent to browser
DEBUG - 2013-04-12 09:24:44 --> Total execution time: 0.0256
DEBUG - 2013-04-12 09:24:59 --> Config Class Initialized
DEBUG - 2013-04-12 09:24:59 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:24:59 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:24:59 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:24:59 --> URI Class Initialized
DEBUG - 2013-04-12 09:24:59 --> Router Class Initialized
DEBUG - 2013-04-12 09:24:59 --> Output Class Initialized
DEBUG - 2013-04-12 09:24:59 --> Security Class Initialized
DEBUG - 2013-04-12 09:24:59 --> Input Class Initialized
DEBUG - 2013-04-12 09:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:24:59 --> Language Class Initialized
DEBUG - 2013-04-12 09:24:59 --> Loader Class Initialized
DEBUG - 2013-04-12 09:24:59 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:24:59 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:24:59 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:24:59 --> Session Class Initialized
DEBUG - 2013-04-12 09:24:59 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:24:59 --> Session routines successfully run
DEBUG - 2013-04-12 09:24:59 --> Controller Class Initialized
DEBUG - 2013-04-12 09:24:59 --> Language Class Initialized
DEBUG - 2013-04-12 09:24:59 --> Config Class Initialized
DEBUG - 2013-04-12 09:24:59 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:24:59 --> Loader Class Initialized
DEBUG - 2013-04-12 09:24:59 --> Model Class Initialized
DEBUG - 2013-04-12 09:24:59 --> Model Class Initialized
DEBUG - 2013-04-12 09:24:59 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:24:59 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:24:59 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:24:59 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:24:59 --> Final output sent to browser
DEBUG - 2013-04-12 09:24:59 --> Total execution time: 0.0323
DEBUG - 2013-04-12 09:25:07 --> Config Class Initialized
DEBUG - 2013-04-12 09:25:07 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:25:07 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:25:07 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:25:07 --> URI Class Initialized
DEBUG - 2013-04-12 09:25:08 --> Router Class Initialized
DEBUG - 2013-04-12 09:25:08 --> Output Class Initialized
DEBUG - 2013-04-12 09:25:08 --> Security Class Initialized
DEBUG - 2013-04-12 09:25:08 --> Input Class Initialized
DEBUG - 2013-04-12 09:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:25:08 --> Language Class Initialized
DEBUG - 2013-04-12 09:25:08 --> Loader Class Initialized
DEBUG - 2013-04-12 09:25:08 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:25:08 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:25:08 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:25:08 --> Session Class Initialized
DEBUG - 2013-04-12 09:25:08 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:25:08 --> Session routines successfully run
DEBUG - 2013-04-12 09:25:08 --> Controller Class Initialized
DEBUG - 2013-04-12 09:25:08 --> Language Class Initialized
DEBUG - 2013-04-12 09:25:08 --> Config Class Initialized
DEBUG - 2013-04-12 09:25:08 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:25:08 --> Loader Class Initialized
DEBUG - 2013-04-12 09:25:08 --> Model Class Initialized
DEBUG - 2013-04-12 09:25:08 --> Model Class Initialized
DEBUG - 2013-04-12 09:25:08 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:25:08 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:25:08 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:25:08 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:25:08 --> Final output sent to browser
DEBUG - 2013-04-12 09:25:08 --> Total execution time: 0.0280
DEBUG - 2013-04-12 09:25:20 --> Config Class Initialized
DEBUG - 2013-04-12 09:25:20 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:25:20 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:25:20 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:25:20 --> URI Class Initialized
DEBUG - 2013-04-12 09:25:20 --> Router Class Initialized
DEBUG - 2013-04-12 09:25:20 --> Output Class Initialized
DEBUG - 2013-04-12 09:25:20 --> Security Class Initialized
DEBUG - 2013-04-12 09:25:20 --> Input Class Initialized
DEBUG - 2013-04-12 09:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:25:20 --> Language Class Initialized
DEBUG - 2013-04-12 09:25:20 --> Loader Class Initialized
DEBUG - 2013-04-12 09:25:21 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:25:21 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:25:21 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:25:21 --> Session Class Initialized
DEBUG - 2013-04-12 09:25:21 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:25:21 --> Session routines successfully run
DEBUG - 2013-04-12 09:25:21 --> Controller Class Initialized
DEBUG - 2013-04-12 09:25:21 --> Language Class Initialized
DEBUG - 2013-04-12 09:25:21 --> Config Class Initialized
DEBUG - 2013-04-12 09:25:21 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:25:21 --> Loader Class Initialized
DEBUG - 2013-04-12 09:25:21 --> Model Class Initialized
DEBUG - 2013-04-12 09:25:21 --> Model Class Initialized
DEBUG - 2013-04-12 09:25:21 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:25:21 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:25:21 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:25:21 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:25:21 --> Final output sent to browser
DEBUG - 2013-04-12 09:25:21 --> Total execution time: 0.0232
DEBUG - 2013-04-12 09:25:41 --> Config Class Initialized
DEBUG - 2013-04-12 09:25:41 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:25:41 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:25:41 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:25:41 --> URI Class Initialized
DEBUG - 2013-04-12 09:25:41 --> Router Class Initialized
DEBUG - 2013-04-12 09:25:41 --> Output Class Initialized
DEBUG - 2013-04-12 09:25:41 --> Security Class Initialized
DEBUG - 2013-04-12 09:25:41 --> Input Class Initialized
DEBUG - 2013-04-12 09:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:25:41 --> Language Class Initialized
DEBUG - 2013-04-12 09:25:41 --> Loader Class Initialized
DEBUG - 2013-04-12 09:25:41 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:25:41 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:25:41 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:25:41 --> Session Class Initialized
DEBUG - 2013-04-12 09:25:41 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:25:41 --> Session routines successfully run
DEBUG - 2013-04-12 09:25:41 --> Controller Class Initialized
DEBUG - 2013-04-12 09:25:41 --> Language Class Initialized
DEBUG - 2013-04-12 09:25:41 --> Config Class Initialized
DEBUG - 2013-04-12 09:25:41 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:25:41 --> Loader Class Initialized
DEBUG - 2013-04-12 09:25:41 --> Model Class Initialized
DEBUG - 2013-04-12 09:25:41 --> Model Class Initialized
DEBUG - 2013-04-12 09:25:41 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:25:41 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:25:41 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:25:41 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:25:41 --> Final output sent to browser
DEBUG - 2013-04-12 09:25:41 --> Total execution time: 0.0314
DEBUG - 2013-04-12 09:25:50 --> Config Class Initialized
DEBUG - 2013-04-12 09:25:50 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:25:50 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:25:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:25:50 --> URI Class Initialized
DEBUG - 2013-04-12 09:25:50 --> Router Class Initialized
DEBUG - 2013-04-12 09:25:50 --> Output Class Initialized
DEBUG - 2013-04-12 09:25:50 --> Security Class Initialized
DEBUG - 2013-04-12 09:25:50 --> Input Class Initialized
DEBUG - 2013-04-12 09:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:25:50 --> Language Class Initialized
DEBUG - 2013-04-12 09:25:50 --> Loader Class Initialized
DEBUG - 2013-04-12 09:25:50 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:25:50 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:25:50 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:25:50 --> Session Class Initialized
DEBUG - 2013-04-12 09:25:50 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:25:50 --> Session routines successfully run
DEBUG - 2013-04-12 09:25:50 --> Controller Class Initialized
DEBUG - 2013-04-12 09:25:50 --> Language Class Initialized
DEBUG - 2013-04-12 09:25:50 --> Config Class Initialized
DEBUG - 2013-04-12 09:25:50 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:25:50 --> Loader Class Initialized
DEBUG - 2013-04-12 09:25:50 --> Model Class Initialized
DEBUG - 2013-04-12 09:25:50 --> Model Class Initialized
DEBUG - 2013-04-12 09:25:50 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:25:50 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:25:50 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:25:50 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:25:50 --> Final output sent to browser
DEBUG - 2013-04-12 09:25:50 --> Total execution time: 0.0345
DEBUG - 2013-04-12 09:26:14 --> Config Class Initialized
DEBUG - 2013-04-12 09:26:14 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:26:14 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:26:14 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:26:14 --> URI Class Initialized
DEBUG - 2013-04-12 09:26:14 --> Router Class Initialized
DEBUG - 2013-04-12 09:26:14 --> Output Class Initialized
DEBUG - 2013-04-12 09:26:14 --> Security Class Initialized
DEBUG - 2013-04-12 09:26:14 --> Input Class Initialized
DEBUG - 2013-04-12 09:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:26:14 --> Language Class Initialized
DEBUG - 2013-04-12 09:26:14 --> Loader Class Initialized
DEBUG - 2013-04-12 09:26:14 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:26:14 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:26:14 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:26:14 --> Session Class Initialized
DEBUG - 2013-04-12 09:26:14 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:26:14 --> Session routines successfully run
DEBUG - 2013-04-12 09:26:14 --> Controller Class Initialized
DEBUG - 2013-04-12 09:26:14 --> Language Class Initialized
DEBUG - 2013-04-12 09:26:14 --> Config Class Initialized
DEBUG - 2013-04-12 09:26:14 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:26:14 --> Loader Class Initialized
DEBUG - 2013-04-12 09:26:14 --> Model Class Initialized
DEBUG - 2013-04-12 09:26:14 --> Model Class Initialized
DEBUG - 2013-04-12 09:26:14 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:26:14 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:26:14 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:26:14 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:26:14 --> Final output sent to browser
DEBUG - 2013-04-12 09:26:14 --> Total execution time: 0.0268
DEBUG - 2013-04-12 09:26:33 --> Config Class Initialized
DEBUG - 2013-04-12 09:26:33 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:26:33 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:26:33 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:26:33 --> URI Class Initialized
DEBUG - 2013-04-12 09:26:33 --> Router Class Initialized
DEBUG - 2013-04-12 09:26:33 --> Output Class Initialized
DEBUG - 2013-04-12 09:26:33 --> Security Class Initialized
DEBUG - 2013-04-12 09:26:33 --> Input Class Initialized
DEBUG - 2013-04-12 09:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:26:33 --> Language Class Initialized
DEBUG - 2013-04-12 09:26:33 --> Loader Class Initialized
DEBUG - 2013-04-12 09:26:33 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:26:33 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:26:33 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:26:33 --> Session Class Initialized
DEBUG - 2013-04-12 09:26:33 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:26:33 --> Session routines successfully run
DEBUG - 2013-04-12 09:26:33 --> Controller Class Initialized
DEBUG - 2013-04-12 09:26:33 --> Language Class Initialized
DEBUG - 2013-04-12 09:26:33 --> Config Class Initialized
DEBUG - 2013-04-12 09:26:33 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:26:33 --> Loader Class Initialized
DEBUG - 2013-04-12 09:26:33 --> Model Class Initialized
DEBUG - 2013-04-12 09:26:33 --> Model Class Initialized
DEBUG - 2013-04-12 09:26:33 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:26:33 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:26:33 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:26:33 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:26:33 --> Final output sent to browser
DEBUG - 2013-04-12 09:26:33 --> Total execution time: 0.0307
DEBUG - 2013-04-12 09:26:42 --> Config Class Initialized
DEBUG - 2013-04-12 09:26:42 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:26:42 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:26:42 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:26:42 --> URI Class Initialized
DEBUG - 2013-04-12 09:26:42 --> Router Class Initialized
DEBUG - 2013-04-12 09:26:42 --> Output Class Initialized
DEBUG - 2013-04-12 09:26:42 --> Security Class Initialized
DEBUG - 2013-04-12 09:26:42 --> Input Class Initialized
DEBUG - 2013-04-12 09:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:26:42 --> Language Class Initialized
DEBUG - 2013-04-12 09:26:42 --> Loader Class Initialized
DEBUG - 2013-04-12 09:26:42 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:26:42 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:26:42 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:26:42 --> Session Class Initialized
DEBUG - 2013-04-12 09:26:42 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:26:42 --> Session routines successfully run
DEBUG - 2013-04-12 09:26:42 --> Controller Class Initialized
DEBUG - 2013-04-12 09:26:42 --> Language Class Initialized
DEBUG - 2013-04-12 09:26:42 --> Config Class Initialized
DEBUG - 2013-04-12 09:26:42 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:26:42 --> Loader Class Initialized
DEBUG - 2013-04-12 09:26:42 --> Model Class Initialized
DEBUG - 2013-04-12 09:26:42 --> Model Class Initialized
DEBUG - 2013-04-12 09:26:42 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:26:42 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:26:42 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:26:42 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:26:42 --> Final output sent to browser
DEBUG - 2013-04-12 09:26:42 --> Total execution time: 0.0339
DEBUG - 2013-04-12 09:28:29 --> Config Class Initialized
DEBUG - 2013-04-12 09:28:29 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:28:29 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:28:29 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:28:29 --> URI Class Initialized
DEBUG - 2013-04-12 09:28:29 --> Router Class Initialized
DEBUG - 2013-04-12 09:28:29 --> Output Class Initialized
DEBUG - 2013-04-12 09:28:29 --> Security Class Initialized
DEBUG - 2013-04-12 09:28:29 --> Input Class Initialized
DEBUG - 2013-04-12 09:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:28:29 --> Language Class Initialized
DEBUG - 2013-04-12 09:28:29 --> Loader Class Initialized
DEBUG - 2013-04-12 09:28:29 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:28:29 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:28:29 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:28:29 --> Session Class Initialized
DEBUG - 2013-04-12 09:28:29 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:28:29 --> Session routines successfully run
DEBUG - 2013-04-12 09:28:29 --> Controller Class Initialized
DEBUG - 2013-04-12 09:28:29 --> Language Class Initialized
DEBUG - 2013-04-12 09:28:29 --> Config Class Initialized
DEBUG - 2013-04-12 09:28:29 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:28:29 --> Loader Class Initialized
DEBUG - 2013-04-12 09:28:29 --> Model Class Initialized
DEBUG - 2013-04-12 09:28:29 --> Model Class Initialized
DEBUG - 2013-04-12 09:28:29 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:28:29 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:28:29 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:28:29 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:28:29 --> Final output sent to browser
DEBUG - 2013-04-12 09:28:29 --> Total execution time: 0.0268
DEBUG - 2013-04-12 09:28:57 --> Config Class Initialized
DEBUG - 2013-04-12 09:28:57 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:28:57 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:28:57 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:28:57 --> URI Class Initialized
DEBUG - 2013-04-12 09:28:57 --> Router Class Initialized
DEBUG - 2013-04-12 09:28:57 --> Output Class Initialized
DEBUG - 2013-04-12 09:28:57 --> Security Class Initialized
DEBUG - 2013-04-12 09:28:57 --> Input Class Initialized
DEBUG - 2013-04-12 09:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:28:57 --> Language Class Initialized
DEBUG - 2013-04-12 09:28:57 --> Loader Class Initialized
DEBUG - 2013-04-12 09:28:57 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:28:57 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:28:57 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:28:57 --> Session Class Initialized
DEBUG - 2013-04-12 09:28:57 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:28:57 --> Session routines successfully run
DEBUG - 2013-04-12 09:28:57 --> Controller Class Initialized
DEBUG - 2013-04-12 09:28:57 --> Language Class Initialized
DEBUG - 2013-04-12 09:28:57 --> Config Class Initialized
DEBUG - 2013-04-12 09:28:57 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:28:57 --> Loader Class Initialized
DEBUG - 2013-04-12 09:28:57 --> Model Class Initialized
DEBUG - 2013-04-12 09:28:57 --> Model Class Initialized
DEBUG - 2013-04-12 09:28:57 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:28:57 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:28:57 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:28:57 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:28:57 --> Final output sent to browser
DEBUG - 2013-04-12 09:28:57 --> Total execution time: 0.0336
DEBUG - 2013-04-12 09:29:08 --> Config Class Initialized
DEBUG - 2013-04-12 09:29:08 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:29:08 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:29:08 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:29:08 --> URI Class Initialized
DEBUG - 2013-04-12 09:29:08 --> Router Class Initialized
DEBUG - 2013-04-12 09:29:08 --> Output Class Initialized
DEBUG - 2013-04-12 09:29:08 --> Security Class Initialized
DEBUG - 2013-04-12 09:29:08 --> Input Class Initialized
DEBUG - 2013-04-12 09:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:29:08 --> Language Class Initialized
DEBUG - 2013-04-12 09:29:08 --> Loader Class Initialized
DEBUG - 2013-04-12 09:29:08 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:29:08 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:29:08 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:29:08 --> Session Class Initialized
DEBUG - 2013-04-12 09:29:08 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:29:08 --> Session routines successfully run
DEBUG - 2013-04-12 09:29:08 --> Controller Class Initialized
DEBUG - 2013-04-12 09:29:08 --> Language Class Initialized
DEBUG - 2013-04-12 09:29:08 --> Config Class Initialized
DEBUG - 2013-04-12 09:29:08 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:29:08 --> Loader Class Initialized
DEBUG - 2013-04-12 09:29:08 --> Model Class Initialized
DEBUG - 2013-04-12 09:29:08 --> Model Class Initialized
DEBUG - 2013-04-12 09:29:08 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:29:08 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:29:08 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:29:08 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:29:08 --> Final output sent to browser
DEBUG - 2013-04-12 09:29:08 --> Total execution time: 0.0300
DEBUG - 2013-04-12 09:29:14 --> Config Class Initialized
DEBUG - 2013-04-12 09:29:14 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:29:14 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:29:14 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:29:14 --> URI Class Initialized
DEBUG - 2013-04-12 09:29:14 --> Router Class Initialized
DEBUG - 2013-04-12 09:29:14 --> Output Class Initialized
DEBUG - 2013-04-12 09:29:14 --> Security Class Initialized
DEBUG - 2013-04-12 09:29:14 --> Input Class Initialized
DEBUG - 2013-04-12 09:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:29:14 --> Language Class Initialized
DEBUG - 2013-04-12 09:29:14 --> Loader Class Initialized
DEBUG - 2013-04-12 09:29:14 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:29:14 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:29:14 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:29:14 --> Session Class Initialized
DEBUG - 2013-04-12 09:29:14 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:29:14 --> Session routines successfully run
DEBUG - 2013-04-12 09:29:14 --> Controller Class Initialized
DEBUG - 2013-04-12 09:29:14 --> Language Class Initialized
DEBUG - 2013-04-12 09:29:14 --> Config Class Initialized
DEBUG - 2013-04-12 09:29:14 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:29:14 --> Loader Class Initialized
DEBUG - 2013-04-12 09:29:14 --> Model Class Initialized
DEBUG - 2013-04-12 09:29:14 --> Model Class Initialized
DEBUG - 2013-04-12 09:29:14 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:29:14 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:29:14 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:29:14 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:29:14 --> Final output sent to browser
DEBUG - 2013-04-12 09:29:14 --> Total execution time: 0.0299
DEBUG - 2013-04-12 09:29:50 --> Config Class Initialized
DEBUG - 2013-04-12 09:29:50 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:29:50 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:29:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:29:50 --> URI Class Initialized
DEBUG - 2013-04-12 09:29:50 --> Router Class Initialized
DEBUG - 2013-04-12 09:29:50 --> Output Class Initialized
DEBUG - 2013-04-12 09:29:50 --> Security Class Initialized
DEBUG - 2013-04-12 09:29:50 --> Input Class Initialized
DEBUG - 2013-04-12 09:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:29:50 --> Language Class Initialized
DEBUG - 2013-04-12 09:29:50 --> Loader Class Initialized
DEBUG - 2013-04-12 09:29:50 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:29:50 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:29:50 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:29:50 --> Session Class Initialized
DEBUG - 2013-04-12 09:29:50 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:29:50 --> Session routines successfully run
DEBUG - 2013-04-12 09:29:50 --> Controller Class Initialized
DEBUG - 2013-04-12 09:29:50 --> Language Class Initialized
DEBUG - 2013-04-12 09:29:50 --> Config Class Initialized
DEBUG - 2013-04-12 09:29:50 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:29:50 --> Loader Class Initialized
DEBUG - 2013-04-12 09:29:50 --> Model Class Initialized
DEBUG - 2013-04-12 09:29:50 --> Model Class Initialized
DEBUG - 2013-04-12 09:29:50 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:29:50 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:29:50 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:29:50 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:29:50 --> Final output sent to browser
DEBUG - 2013-04-12 09:29:50 --> Total execution time: 0.0254
DEBUG - 2013-04-12 09:30:31 --> Config Class Initialized
DEBUG - 2013-04-12 09:30:31 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:30:31 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:30:31 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:30:31 --> URI Class Initialized
DEBUG - 2013-04-12 09:30:31 --> Router Class Initialized
DEBUG - 2013-04-12 09:30:31 --> Output Class Initialized
DEBUG - 2013-04-12 09:30:31 --> Security Class Initialized
DEBUG - 2013-04-12 09:30:31 --> Input Class Initialized
DEBUG - 2013-04-12 09:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:30:31 --> Language Class Initialized
DEBUG - 2013-04-12 09:30:31 --> Loader Class Initialized
DEBUG - 2013-04-12 09:30:31 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:30:31 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:30:31 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:30:31 --> Session Class Initialized
DEBUG - 2013-04-12 09:30:31 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:30:31 --> Session routines successfully run
DEBUG - 2013-04-12 09:30:31 --> Controller Class Initialized
DEBUG - 2013-04-12 09:30:31 --> Language Class Initialized
DEBUG - 2013-04-12 09:30:31 --> Config Class Initialized
DEBUG - 2013-04-12 09:30:31 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:30:31 --> Loader Class Initialized
DEBUG - 2013-04-12 09:30:31 --> Model Class Initialized
DEBUG - 2013-04-12 09:30:31 --> Model Class Initialized
DEBUG - 2013-04-12 09:30:31 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:30:31 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:30:31 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:30:31 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:30:31 --> Final output sent to browser
DEBUG - 2013-04-12 09:30:31 --> Total execution time: 0.0321
DEBUG - 2013-04-12 09:31:30 --> Config Class Initialized
DEBUG - 2013-04-12 09:31:30 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:31:30 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:31:30 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:31:30 --> URI Class Initialized
DEBUG - 2013-04-12 09:31:30 --> Router Class Initialized
DEBUG - 2013-04-12 09:31:30 --> Output Class Initialized
DEBUG - 2013-04-12 09:31:30 --> Security Class Initialized
DEBUG - 2013-04-12 09:31:30 --> Input Class Initialized
DEBUG - 2013-04-12 09:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:31:30 --> Language Class Initialized
DEBUG - 2013-04-12 09:31:31 --> Loader Class Initialized
DEBUG - 2013-04-12 09:31:31 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:31:31 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:31:31 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:31:31 --> Session Class Initialized
DEBUG - 2013-04-12 09:31:31 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:31:31 --> Session routines successfully run
DEBUG - 2013-04-12 09:31:31 --> Controller Class Initialized
DEBUG - 2013-04-12 09:31:31 --> Language Class Initialized
DEBUG - 2013-04-12 09:31:31 --> Config Class Initialized
DEBUG - 2013-04-12 09:31:31 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:31:31 --> Loader Class Initialized
DEBUG - 2013-04-12 09:31:31 --> Model Class Initialized
DEBUG - 2013-04-12 09:31:31 --> Model Class Initialized
DEBUG - 2013-04-12 09:31:31 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:31:31 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:31:31 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:31:31 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:31:31 --> Final output sent to browser
DEBUG - 2013-04-12 09:31:31 --> Total execution time: 0.0296
DEBUG - 2013-04-12 09:32:05 --> Config Class Initialized
DEBUG - 2013-04-12 09:32:05 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:32:05 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:32:05 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:32:05 --> URI Class Initialized
DEBUG - 2013-04-12 09:32:05 --> Router Class Initialized
DEBUG - 2013-04-12 09:32:05 --> Output Class Initialized
DEBUG - 2013-04-12 09:32:05 --> Security Class Initialized
DEBUG - 2013-04-12 09:32:05 --> Input Class Initialized
DEBUG - 2013-04-12 09:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:32:05 --> Language Class Initialized
DEBUG - 2013-04-12 09:32:05 --> Loader Class Initialized
DEBUG - 2013-04-12 09:32:05 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:32:05 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:32:05 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:32:05 --> Session Class Initialized
DEBUG - 2013-04-12 09:32:05 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:32:05 --> Session routines successfully run
DEBUG - 2013-04-12 09:32:05 --> Controller Class Initialized
DEBUG - 2013-04-12 09:32:05 --> Language Class Initialized
DEBUG - 2013-04-12 09:32:05 --> Config Class Initialized
DEBUG - 2013-04-12 09:32:05 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:32:05 --> Loader Class Initialized
DEBUG - 2013-04-12 09:32:05 --> Model Class Initialized
DEBUG - 2013-04-12 09:32:05 --> Model Class Initialized
DEBUG - 2013-04-12 09:32:05 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:32:05 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:32:05 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:32:05 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:32:05 --> Final output sent to browser
DEBUG - 2013-04-12 09:32:05 --> Total execution time: 0.0255
DEBUG - 2013-04-12 09:32:44 --> Config Class Initialized
DEBUG - 2013-04-12 09:32:44 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:32:44 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:32:44 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:32:44 --> URI Class Initialized
DEBUG - 2013-04-12 09:32:44 --> Router Class Initialized
DEBUG - 2013-04-12 09:32:44 --> Output Class Initialized
DEBUG - 2013-04-12 09:32:44 --> Security Class Initialized
DEBUG - 2013-04-12 09:32:44 --> Input Class Initialized
DEBUG - 2013-04-12 09:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:32:44 --> Language Class Initialized
DEBUG - 2013-04-12 09:32:44 --> Loader Class Initialized
DEBUG - 2013-04-12 09:32:44 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:32:44 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:32:44 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:32:44 --> Session Class Initialized
DEBUG - 2013-04-12 09:32:44 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:32:44 --> Session routines successfully run
DEBUG - 2013-04-12 09:32:44 --> Controller Class Initialized
DEBUG - 2013-04-12 09:32:44 --> Language Class Initialized
DEBUG - 2013-04-12 09:32:44 --> Config Class Initialized
DEBUG - 2013-04-12 09:32:44 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:32:44 --> Loader Class Initialized
DEBUG - 2013-04-12 09:32:44 --> Model Class Initialized
DEBUG - 2013-04-12 09:32:44 --> Model Class Initialized
DEBUG - 2013-04-12 09:32:44 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:32:44 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:32:44 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:32:44 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:32:44 --> Final output sent to browser
DEBUG - 2013-04-12 09:32:44 --> Total execution time: 0.0331
DEBUG - 2013-04-12 09:32:51 --> Config Class Initialized
DEBUG - 2013-04-12 09:32:51 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:32:51 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:32:51 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:32:51 --> URI Class Initialized
DEBUG - 2013-04-12 09:32:51 --> Router Class Initialized
DEBUG - 2013-04-12 09:32:51 --> Output Class Initialized
DEBUG - 2013-04-12 09:32:51 --> Security Class Initialized
DEBUG - 2013-04-12 09:32:51 --> Input Class Initialized
DEBUG - 2013-04-12 09:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:32:51 --> Language Class Initialized
DEBUG - 2013-04-12 09:32:51 --> Loader Class Initialized
DEBUG - 2013-04-12 09:32:51 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:32:51 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:32:51 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:32:51 --> Session Class Initialized
DEBUG - 2013-04-12 09:32:51 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:32:51 --> Session routines successfully run
DEBUG - 2013-04-12 09:32:51 --> Controller Class Initialized
DEBUG - 2013-04-12 09:32:51 --> Language Class Initialized
DEBUG - 2013-04-12 09:32:51 --> Config Class Initialized
DEBUG - 2013-04-12 09:32:51 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:32:51 --> Loader Class Initialized
DEBUG - 2013-04-12 09:32:51 --> Model Class Initialized
DEBUG - 2013-04-12 09:32:51 --> Model Class Initialized
DEBUG - 2013-04-12 09:32:51 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:32:51 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:32:51 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:32:51 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:32:51 --> Final output sent to browser
DEBUG - 2013-04-12 09:32:51 --> Total execution time: 0.0247
DEBUG - 2013-04-12 09:32:56 --> Config Class Initialized
DEBUG - 2013-04-12 09:32:56 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:32:56 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:32:56 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:32:56 --> URI Class Initialized
DEBUG - 2013-04-12 09:32:56 --> Router Class Initialized
DEBUG - 2013-04-12 09:32:56 --> Output Class Initialized
DEBUG - 2013-04-12 09:32:56 --> Security Class Initialized
DEBUG - 2013-04-12 09:32:56 --> Input Class Initialized
DEBUG - 2013-04-12 09:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:32:56 --> Language Class Initialized
DEBUG - 2013-04-12 09:32:56 --> Loader Class Initialized
DEBUG - 2013-04-12 09:32:56 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:32:56 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:32:56 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:32:56 --> Session Class Initialized
DEBUG - 2013-04-12 09:32:56 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:32:56 --> Session routines successfully run
DEBUG - 2013-04-12 09:32:56 --> Controller Class Initialized
DEBUG - 2013-04-12 09:32:56 --> Language Class Initialized
DEBUG - 2013-04-12 09:32:56 --> Config Class Initialized
DEBUG - 2013-04-12 09:32:56 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:32:56 --> Loader Class Initialized
DEBUG - 2013-04-12 09:32:56 --> Model Class Initialized
DEBUG - 2013-04-12 09:32:56 --> Model Class Initialized
DEBUG - 2013-04-12 09:32:56 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:32:56 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:32:56 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:32:56 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:32:56 --> Final output sent to browser
DEBUG - 2013-04-12 09:32:56 --> Total execution time: 0.0338
DEBUG - 2013-04-12 09:33:12 --> Config Class Initialized
DEBUG - 2013-04-12 09:33:12 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:33:12 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:33:12 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:33:12 --> URI Class Initialized
DEBUG - 2013-04-12 09:33:12 --> Router Class Initialized
DEBUG - 2013-04-12 09:33:12 --> Output Class Initialized
DEBUG - 2013-04-12 09:33:12 --> Security Class Initialized
DEBUG - 2013-04-12 09:33:12 --> Input Class Initialized
DEBUG - 2013-04-12 09:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:33:12 --> Language Class Initialized
DEBUG - 2013-04-12 09:33:12 --> Loader Class Initialized
DEBUG - 2013-04-12 09:33:12 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:33:12 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:33:12 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:33:12 --> Session Class Initialized
DEBUG - 2013-04-12 09:33:12 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:33:12 --> Session routines successfully run
DEBUG - 2013-04-12 09:33:12 --> Controller Class Initialized
DEBUG - 2013-04-12 09:33:12 --> Language Class Initialized
DEBUG - 2013-04-12 09:33:12 --> Config Class Initialized
DEBUG - 2013-04-12 09:33:12 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:33:12 --> Loader Class Initialized
DEBUG - 2013-04-12 09:33:12 --> Model Class Initialized
DEBUG - 2013-04-12 09:33:12 --> Model Class Initialized
DEBUG - 2013-04-12 09:33:12 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:33:12 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:33:12 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:33:12 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:33:12 --> Final output sent to browser
DEBUG - 2013-04-12 09:33:12 --> Total execution time: 0.0327
DEBUG - 2013-04-12 09:33:19 --> Config Class Initialized
DEBUG - 2013-04-12 09:33:19 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:33:19 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:33:19 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:33:19 --> URI Class Initialized
DEBUG - 2013-04-12 09:33:19 --> Router Class Initialized
DEBUG - 2013-04-12 09:33:19 --> Output Class Initialized
DEBUG - 2013-04-12 09:33:19 --> Security Class Initialized
DEBUG - 2013-04-12 09:33:19 --> Input Class Initialized
DEBUG - 2013-04-12 09:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:33:19 --> Language Class Initialized
DEBUG - 2013-04-12 09:33:19 --> Loader Class Initialized
DEBUG - 2013-04-12 09:33:19 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:33:19 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:33:19 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:33:19 --> Session Class Initialized
DEBUG - 2013-04-12 09:33:19 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:33:19 --> Session routines successfully run
DEBUG - 2013-04-12 09:33:19 --> Controller Class Initialized
DEBUG - 2013-04-12 09:33:19 --> Language Class Initialized
DEBUG - 2013-04-12 09:33:19 --> Config Class Initialized
DEBUG - 2013-04-12 09:33:19 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:33:19 --> Loader Class Initialized
DEBUG - 2013-04-12 09:33:19 --> Model Class Initialized
DEBUG - 2013-04-12 09:33:19 --> Model Class Initialized
DEBUG - 2013-04-12 09:33:19 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:33:19 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:33:19 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:33:19 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:33:19 --> Final output sent to browser
DEBUG - 2013-04-12 09:33:19 --> Total execution time: 0.0342
DEBUG - 2013-04-12 09:33:27 --> Config Class Initialized
DEBUG - 2013-04-12 09:33:27 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:33:27 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:33:27 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:33:27 --> URI Class Initialized
DEBUG - 2013-04-12 09:33:27 --> Router Class Initialized
DEBUG - 2013-04-12 09:33:27 --> Output Class Initialized
DEBUG - 2013-04-12 09:33:27 --> Security Class Initialized
DEBUG - 2013-04-12 09:33:27 --> Input Class Initialized
DEBUG - 2013-04-12 09:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:33:27 --> Language Class Initialized
DEBUG - 2013-04-12 09:33:27 --> Loader Class Initialized
DEBUG - 2013-04-12 09:33:27 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:33:27 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:33:27 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:33:27 --> Session Class Initialized
DEBUG - 2013-04-12 09:33:27 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:33:27 --> Session routines successfully run
DEBUG - 2013-04-12 09:33:27 --> Controller Class Initialized
DEBUG - 2013-04-12 09:33:27 --> Language Class Initialized
DEBUG - 2013-04-12 09:33:27 --> Config Class Initialized
DEBUG - 2013-04-12 09:33:27 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:33:27 --> Loader Class Initialized
DEBUG - 2013-04-12 09:33:27 --> Model Class Initialized
DEBUG - 2013-04-12 09:33:27 --> Model Class Initialized
DEBUG - 2013-04-12 09:33:27 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:33:27 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:33:27 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:33:27 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:33:27 --> Final output sent to browser
DEBUG - 2013-04-12 09:33:27 --> Total execution time: 0.0305
DEBUG - 2013-04-12 09:33:50 --> Config Class Initialized
DEBUG - 2013-04-12 09:33:50 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:33:50 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:33:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:33:50 --> URI Class Initialized
DEBUG - 2013-04-12 09:33:50 --> Router Class Initialized
DEBUG - 2013-04-12 09:33:50 --> Output Class Initialized
DEBUG - 2013-04-12 09:33:50 --> Security Class Initialized
DEBUG - 2013-04-12 09:33:50 --> Input Class Initialized
DEBUG - 2013-04-12 09:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:33:50 --> Language Class Initialized
DEBUG - 2013-04-12 09:33:50 --> Loader Class Initialized
DEBUG - 2013-04-12 09:33:50 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:33:50 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:33:50 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:33:50 --> Session Class Initialized
DEBUG - 2013-04-12 09:33:50 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:33:50 --> Session routines successfully run
DEBUG - 2013-04-12 09:33:50 --> Controller Class Initialized
DEBUG - 2013-04-12 09:33:50 --> Language Class Initialized
DEBUG - 2013-04-12 09:33:50 --> Config Class Initialized
DEBUG - 2013-04-12 09:33:50 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:33:50 --> Loader Class Initialized
DEBUG - 2013-04-12 09:33:50 --> Model Class Initialized
DEBUG - 2013-04-12 09:33:50 --> Model Class Initialized
DEBUG - 2013-04-12 09:33:50 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:33:50 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:33:50 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:33:50 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:33:50 --> Final output sent to browser
DEBUG - 2013-04-12 09:33:50 --> Total execution time: 0.0254
DEBUG - 2013-04-12 09:36:18 --> Config Class Initialized
DEBUG - 2013-04-12 09:36:18 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:36:18 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:36:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:36:18 --> URI Class Initialized
DEBUG - 2013-04-12 09:36:18 --> Router Class Initialized
DEBUG - 2013-04-12 09:36:18 --> Output Class Initialized
DEBUG - 2013-04-12 09:36:18 --> Security Class Initialized
DEBUG - 2013-04-12 09:36:18 --> Input Class Initialized
DEBUG - 2013-04-12 09:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:36:18 --> Language Class Initialized
DEBUG - 2013-04-12 09:36:18 --> Loader Class Initialized
DEBUG - 2013-04-12 09:36:18 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:36:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:36:18 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:36:18 --> Session Class Initialized
DEBUG - 2013-04-12 09:36:18 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:36:18 --> Session routines successfully run
DEBUG - 2013-04-12 09:36:18 --> Controller Class Initialized
DEBUG - 2013-04-12 09:36:18 --> Language Class Initialized
DEBUG - 2013-04-12 09:36:18 --> Config Class Initialized
DEBUG - 2013-04-12 09:36:18 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:36:18 --> Loader Class Initialized
DEBUG - 2013-04-12 09:36:18 --> Model Class Initialized
DEBUG - 2013-04-12 09:36:18 --> Model Class Initialized
DEBUG - 2013-04-12 09:36:18 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:36:18 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:36:18 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:36:18 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:36:18 --> Final output sent to browser
DEBUG - 2013-04-12 09:36:18 --> Total execution time: 0.0250
DEBUG - 2013-04-12 09:54:54 --> Config Class Initialized
DEBUG - 2013-04-12 09:54:54 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:54:54 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:54:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:54:54 --> URI Class Initialized
DEBUG - 2013-04-12 09:54:54 --> Router Class Initialized
DEBUG - 2013-04-12 09:54:54 --> Output Class Initialized
DEBUG - 2013-04-12 09:54:54 --> Security Class Initialized
DEBUG - 2013-04-12 09:54:54 --> Input Class Initialized
DEBUG - 2013-04-12 09:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:54:54 --> Language Class Initialized
DEBUG - 2013-04-12 09:54:54 --> Loader Class Initialized
DEBUG - 2013-04-12 09:54:54 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:54:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:54:54 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:54:54 --> Session Class Initialized
DEBUG - 2013-04-12 09:54:54 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:54:54 --> Session routines successfully run
DEBUG - 2013-04-12 09:54:54 --> Controller Class Initialized
DEBUG - 2013-04-12 09:54:54 --> Language Class Initialized
DEBUG - 2013-04-12 09:54:54 --> Config Class Initialized
DEBUG - 2013-04-12 09:54:54 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:54:54 --> Loader Class Initialized
DEBUG - 2013-04-12 09:54:54 --> Model Class Initialized
DEBUG - 2013-04-12 09:54:54 --> Model Class Initialized
DEBUG - 2013-04-12 09:54:54 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:54:54 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:54:54 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:54:54 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:54:54 --> Final output sent to browser
DEBUG - 2013-04-12 09:54:54 --> Total execution time: 0.0315
DEBUG - 2013-04-12 09:55:16 --> Config Class Initialized
DEBUG - 2013-04-12 09:55:16 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:55:16 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:55:16 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:55:16 --> URI Class Initialized
DEBUG - 2013-04-12 09:55:16 --> Router Class Initialized
DEBUG - 2013-04-12 09:55:16 --> Output Class Initialized
DEBUG - 2013-04-12 09:55:16 --> Security Class Initialized
DEBUG - 2013-04-12 09:55:16 --> Input Class Initialized
DEBUG - 2013-04-12 09:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:55:16 --> Language Class Initialized
DEBUG - 2013-04-12 09:55:16 --> Loader Class Initialized
DEBUG - 2013-04-12 09:55:16 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:55:16 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:55:16 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:55:16 --> Session Class Initialized
DEBUG - 2013-04-12 09:55:16 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:55:16 --> Session routines successfully run
DEBUG - 2013-04-12 09:55:16 --> Controller Class Initialized
DEBUG - 2013-04-12 09:55:16 --> Language Class Initialized
DEBUG - 2013-04-12 09:55:16 --> Config Class Initialized
DEBUG - 2013-04-12 09:55:16 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:55:16 --> Loader Class Initialized
DEBUG - 2013-04-12 09:55:16 --> Model Class Initialized
DEBUG - 2013-04-12 09:55:16 --> Model Class Initialized
DEBUG - 2013-04-12 09:55:16 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:55:16 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:55:16 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:55:16 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:55:16 --> Final output sent to browser
DEBUG - 2013-04-12 09:55:16 --> Total execution time: 0.0261
DEBUG - 2013-04-12 09:55:27 --> Config Class Initialized
DEBUG - 2013-04-12 09:55:27 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:55:27 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:55:27 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:55:27 --> URI Class Initialized
DEBUG - 2013-04-12 09:55:27 --> Router Class Initialized
DEBUG - 2013-04-12 09:55:27 --> Output Class Initialized
DEBUG - 2013-04-12 09:55:27 --> Security Class Initialized
DEBUG - 2013-04-12 09:55:27 --> Input Class Initialized
DEBUG - 2013-04-12 09:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:55:27 --> Language Class Initialized
DEBUG - 2013-04-12 09:55:27 --> Loader Class Initialized
DEBUG - 2013-04-12 09:55:27 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:55:27 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:55:27 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:55:27 --> Session Class Initialized
DEBUG - 2013-04-12 09:55:27 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:55:27 --> Session routines successfully run
DEBUG - 2013-04-12 09:55:27 --> Controller Class Initialized
DEBUG - 2013-04-12 09:55:27 --> Language Class Initialized
DEBUG - 2013-04-12 09:55:27 --> Config Class Initialized
DEBUG - 2013-04-12 09:55:27 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:55:27 --> Loader Class Initialized
DEBUG - 2013-04-12 09:55:27 --> Model Class Initialized
DEBUG - 2013-04-12 09:55:27 --> Model Class Initialized
DEBUG - 2013-04-12 09:55:27 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:55:27 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:55:27 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:55:27 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:55:27 --> Final output sent to browser
DEBUG - 2013-04-12 09:55:27 --> Total execution time: 0.0314
DEBUG - 2013-04-12 09:56:30 --> Config Class Initialized
DEBUG - 2013-04-12 09:56:30 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:56:30 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:56:30 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:56:30 --> URI Class Initialized
DEBUG - 2013-04-12 09:56:30 --> Router Class Initialized
DEBUG - 2013-04-12 09:56:30 --> Output Class Initialized
DEBUG - 2013-04-12 09:56:30 --> Security Class Initialized
DEBUG - 2013-04-12 09:56:30 --> Input Class Initialized
DEBUG - 2013-04-12 09:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:56:30 --> Language Class Initialized
DEBUG - 2013-04-12 09:56:30 --> Loader Class Initialized
DEBUG - 2013-04-12 09:56:30 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:56:30 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:56:30 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:56:30 --> Session Class Initialized
DEBUG - 2013-04-12 09:56:30 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:56:30 --> Session routines successfully run
DEBUG - 2013-04-12 09:56:30 --> Controller Class Initialized
DEBUG - 2013-04-12 09:56:30 --> Language Class Initialized
DEBUG - 2013-04-12 09:56:30 --> Config Class Initialized
DEBUG - 2013-04-12 09:56:30 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:56:30 --> Loader Class Initialized
DEBUG - 2013-04-12 09:56:30 --> Model Class Initialized
DEBUG - 2013-04-12 09:56:30 --> Model Class Initialized
DEBUG - 2013-04-12 09:56:30 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:56:30 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:56:30 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:56:30 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:56:30 --> Final output sent to browser
DEBUG - 2013-04-12 09:56:30 --> Total execution time: 0.0237
DEBUG - 2013-04-12 09:57:35 --> Config Class Initialized
DEBUG - 2013-04-12 09:57:35 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:57:35 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:57:35 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:57:35 --> URI Class Initialized
DEBUG - 2013-04-12 09:57:35 --> Router Class Initialized
DEBUG - 2013-04-12 09:57:35 --> Output Class Initialized
DEBUG - 2013-04-12 09:57:35 --> Security Class Initialized
DEBUG - 2013-04-12 09:57:35 --> Input Class Initialized
DEBUG - 2013-04-12 09:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:57:35 --> Language Class Initialized
DEBUG - 2013-04-12 09:57:35 --> Loader Class Initialized
DEBUG - 2013-04-12 09:57:35 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:57:35 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:57:35 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:57:35 --> Session Class Initialized
DEBUG - 2013-04-12 09:57:35 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:57:35 --> Session routines successfully run
DEBUG - 2013-04-12 09:57:35 --> Controller Class Initialized
DEBUG - 2013-04-12 09:57:35 --> Language Class Initialized
DEBUG - 2013-04-12 09:57:35 --> Config Class Initialized
DEBUG - 2013-04-12 09:57:35 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:57:35 --> Loader Class Initialized
DEBUG - 2013-04-12 09:57:35 --> Model Class Initialized
DEBUG - 2013-04-12 09:57:35 --> Model Class Initialized
DEBUG - 2013-04-12 09:57:35 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:57:35 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:57:35 --> File loaded: ../application/admin/modules/configuracao/views/metas-analytics.php
DEBUG - 2013-04-12 09:57:35 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:57:35 --> Final output sent to browser
DEBUG - 2013-04-12 09:57:35 --> Total execution time: 0.0336
DEBUG - 2013-04-12 09:57:59 --> Config Class Initialized
DEBUG - 2013-04-12 09:57:59 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:57:59 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:57:59 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:57:59 --> URI Class Initialized
DEBUG - 2013-04-12 09:57:59 --> Router Class Initialized
DEBUG - 2013-04-12 09:57:59 --> Output Class Initialized
DEBUG - 2013-04-12 09:57:59 --> Security Class Initialized
DEBUG - 2013-04-12 09:57:59 --> Input Class Initialized
DEBUG - 2013-04-12 09:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:57:59 --> Language Class Initialized
DEBUG - 2013-04-12 09:57:59 --> Loader Class Initialized
DEBUG - 2013-04-12 09:57:59 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:57:59 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:57:59 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:57:59 --> Session Class Initialized
DEBUG - 2013-04-12 09:57:59 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:57:59 --> Session routines successfully run
DEBUG - 2013-04-12 09:57:59 --> Controller Class Initialized
DEBUG - 2013-04-12 09:57:59 --> Language Class Initialized
DEBUG - 2013-04-12 09:57:59 --> Config Class Initialized
DEBUG - 2013-04-12 09:57:59 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:57:59 --> Loader Class Initialized
DEBUG - 2013-04-12 09:57:59 --> Model Class Initialized
DEBUG - 2013-04-12 09:57:59 --> Model Class Initialized
DEBUG - 2013-04-12 09:57:59 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:57:59 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:57:59 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:57:59 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:57:59 --> Final output sent to browser
DEBUG - 2013-04-12 09:57:59 --> Total execution time: 0.0237
DEBUG - 2013-04-12 09:58:32 --> Config Class Initialized
DEBUG - 2013-04-12 09:58:32 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:58:32 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:58:32 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:58:32 --> URI Class Initialized
DEBUG - 2013-04-12 09:58:32 --> Router Class Initialized
DEBUG - 2013-04-12 09:58:32 --> Output Class Initialized
DEBUG - 2013-04-12 09:58:32 --> Security Class Initialized
DEBUG - 2013-04-12 09:58:32 --> Input Class Initialized
DEBUG - 2013-04-12 09:58:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:58:32 --> Language Class Initialized
DEBUG - 2013-04-12 09:58:32 --> Loader Class Initialized
DEBUG - 2013-04-12 09:58:32 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:58:32 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:58:32 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:58:32 --> Session Class Initialized
DEBUG - 2013-04-12 09:58:32 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:58:32 --> Session routines successfully run
DEBUG - 2013-04-12 09:58:32 --> Controller Class Initialized
DEBUG - 2013-04-12 09:58:32 --> Language Class Initialized
DEBUG - 2013-04-12 09:58:32 --> Config Class Initialized
DEBUG - 2013-04-12 09:58:32 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:58:32 --> Loader Class Initialized
DEBUG - 2013-04-12 09:58:32 --> Model Class Initialized
DEBUG - 2013-04-12 09:58:32 --> Model Class Initialized
DEBUG - 2013-04-12 09:58:32 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:58:32 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:58:32 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:58:32 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:58:32 --> Final output sent to browser
DEBUG - 2013-04-12 09:58:32 --> Total execution time: 0.0336
DEBUG - 2013-04-12 09:58:43 --> Config Class Initialized
DEBUG - 2013-04-12 09:58:43 --> Hooks Class Initialized
DEBUG - 2013-04-12 09:58:43 --> Utf8 Class Initialized
DEBUG - 2013-04-12 09:58:43 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 09:58:43 --> URI Class Initialized
DEBUG - 2013-04-12 09:58:43 --> Router Class Initialized
DEBUG - 2013-04-12 09:58:43 --> Output Class Initialized
DEBUG - 2013-04-12 09:58:43 --> Security Class Initialized
DEBUG - 2013-04-12 09:58:43 --> Input Class Initialized
DEBUG - 2013-04-12 09:58:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 09:58:43 --> Language Class Initialized
DEBUG - 2013-04-12 09:58:43 --> Loader Class Initialized
DEBUG - 2013-04-12 09:58:43 --> Helper loaded: url_helper
DEBUG - 2013-04-12 09:58:43 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 09:58:43 --> Helper loaded: text_helper
DEBUG - 2013-04-12 09:58:43 --> Session Class Initialized
DEBUG - 2013-04-12 09:58:43 --> Helper loaded: string_helper
DEBUG - 2013-04-12 09:58:43 --> Session routines successfully run
DEBUG - 2013-04-12 09:58:43 --> Controller Class Initialized
DEBUG - 2013-04-12 09:58:43 --> Language Class Initialized
DEBUG - 2013-04-12 09:58:43 --> Config Class Initialized
DEBUG - 2013-04-12 09:58:43 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 09:58:43 --> Loader Class Initialized
DEBUG - 2013-04-12 09:58:43 --> Model Class Initialized
DEBUG - 2013-04-12 09:58:43 --> Model Class Initialized
DEBUG - 2013-04-12 09:58:43 --> Database Driver Class Initialized
DEBUG - 2013-04-12 09:58:43 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 09:58:43 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 09:58:43 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 09:58:43 --> Final output sent to browser
DEBUG - 2013-04-12 09:58:43 --> Total execution time: 0.0309
DEBUG - 2013-04-12 10:11:11 --> Config Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Hooks Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Utf8 Class Initialized
DEBUG - 2013-04-12 10:11:11 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 10:11:11 --> URI Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Router Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Output Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Security Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Input Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 10:11:11 --> Language Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Loader Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Helper loaded: url_helper
DEBUG - 2013-04-12 10:11:11 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 10:11:11 --> Helper loaded: text_helper
DEBUG - 2013-04-12 10:11:11 --> Session Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Helper loaded: string_helper
DEBUG - 2013-04-12 10:11:11 --> Session routines successfully run
DEBUG - 2013-04-12 10:11:11 --> Controller Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Language Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Config Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 10:11:11 --> Loader Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Model Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Model Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Database Driver Class Initialized
DEBUG - 2013-04-12 10:11:11 --> Model Class Initialized
DEBUG - 2013-04-12 10:11:11 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 10:11:11 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 10:11:11 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 10:11:11 --> Final output sent to browser
DEBUG - 2013-04-12 10:11:11 --> Total execution time: 0.0264
DEBUG - 2013-04-12 10:26:35 --> Config Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Hooks Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Utf8 Class Initialized
DEBUG - 2013-04-12 10:26:35 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 10:26:35 --> URI Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Router Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Output Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Security Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Input Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 10:26:35 --> Language Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Loader Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Helper loaded: url_helper
DEBUG - 2013-04-12 10:26:35 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 10:26:35 --> Helper loaded: text_helper
DEBUG - 2013-04-12 10:26:35 --> Session Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Helper loaded: string_helper
DEBUG - 2013-04-12 10:26:35 --> Session routines successfully run
DEBUG - 2013-04-12 10:26:35 --> Controller Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Language Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Config Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 10:26:35 --> Loader Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Model Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Model Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Database Driver Class Initialized
DEBUG - 2013-04-12 10:26:35 --> Model Class Initialized
DEBUG - 2013-04-12 10:26:35 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 10:26:35 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 10:26:35 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 10:26:35 --> Final output sent to browser
DEBUG - 2013-04-12 10:26:35 --> Total execution time: 0.0258
DEBUG - 2013-04-12 10:30:02 --> Config Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Hooks Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Utf8 Class Initialized
DEBUG - 2013-04-12 10:30:02 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 10:30:02 --> URI Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Router Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Output Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Security Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Input Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 10:30:02 --> Language Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Loader Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Helper loaded: url_helper
DEBUG - 2013-04-12 10:30:02 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 10:30:02 --> Helper loaded: text_helper
DEBUG - 2013-04-12 10:30:02 --> Session Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Helper loaded: string_helper
DEBUG - 2013-04-12 10:30:02 --> Session routines successfully run
DEBUG - 2013-04-12 10:30:02 --> Controller Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Language Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Config Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 10:30:02 --> Loader Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Model Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Model Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Database Driver Class Initialized
DEBUG - 2013-04-12 10:30:02 --> Model Class Initialized
DEBUG - 2013-04-12 10:30:02 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
ERROR - 2013-04-12 10:30:02 --> Severity: Notice  --> Undefined property: stdClass::$parametro /home/w3case/public_html/target-git/application/admin/modules/configuracao/views/geral.php 26
DEBUG - 2013-04-12 10:30:02 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 10:30:02 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 10:30:02 --> Final output sent to browser
DEBUG - 2013-04-12 10:30:02 --> Total execution time: 0.0252
DEBUG - 2013-04-12 10:30:20 --> Config Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Hooks Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Utf8 Class Initialized
DEBUG - 2013-04-12 10:30:20 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 10:30:20 --> URI Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Router Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Output Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Security Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Input Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 10:30:20 --> Language Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Loader Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Helper loaded: url_helper
DEBUG - 2013-04-12 10:30:20 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 10:30:20 --> Helper loaded: text_helper
DEBUG - 2013-04-12 10:30:20 --> Session Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Helper loaded: string_helper
DEBUG - 2013-04-12 10:30:20 --> Session routines successfully run
DEBUG - 2013-04-12 10:30:20 --> Controller Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Language Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Config Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 10:30:20 --> Loader Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Model Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Model Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Database Driver Class Initialized
DEBUG - 2013-04-12 10:30:20 --> Model Class Initialized
DEBUG - 2013-04-12 10:30:20 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 10:30:20 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 10:30:20 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 10:30:20 --> Final output sent to browser
DEBUG - 2013-04-12 10:30:20 --> Total execution time: 0.0251
DEBUG - 2013-04-12 10:48:03 --> Config Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Hooks Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Utf8 Class Initialized
DEBUG - 2013-04-12 10:48:03 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 10:48:03 --> URI Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Router Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Output Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Security Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Input Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 10:48:03 --> Language Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Loader Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Helper loaded: url_helper
DEBUG - 2013-04-12 10:48:03 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 10:48:03 --> Helper loaded: text_helper
DEBUG - 2013-04-12 10:48:03 --> Session Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Helper loaded: string_helper
DEBUG - 2013-04-12 10:48:03 --> Session routines successfully run
DEBUG - 2013-04-12 10:48:03 --> Controller Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Language Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Config Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 10:48:03 --> Loader Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Model Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Model Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Database Driver Class Initialized
DEBUG - 2013-04-12 10:48:03 --> Model Class Initialized
DEBUG - 2013-04-12 10:48:03 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 10:48:03 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 10:48:03 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 10:48:03 --> Final output sent to browser
DEBUG - 2013-04-12 10:48:03 --> Total execution time: 0.0279
DEBUG - 2013-04-12 13:18:51 --> Config Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:18:51 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:18:51 --> URI Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Router Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Output Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Security Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Input Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:18:51 --> Language Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Loader Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:18:51 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:18:51 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:18:51 --> Session Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:18:51 --> A session cookie was not found.
DEBUG - 2013-04-12 13:18:51 --> Session routines successfully run
DEBUG - 2013-04-12 13:18:51 --> Controller Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Language Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Config Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:18:51 --> Loader Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Model Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Model Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:18:51 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:18:51 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 13:18:51 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:18:51 --> Final output sent to browser
DEBUG - 2013-04-12 13:18:51 --> Total execution time: 0.0229
DEBUG - 2013-04-12 13:18:51 --> Config Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:18:51 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:18:51 --> URI Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Router Class Initialized
DEBUG - 2013-04-12 13:18:51 --> No URI present. Default controller set.
DEBUG - 2013-04-12 13:18:51 --> Output Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Security Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Input Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:18:51 --> Language Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Loader Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:18:51 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:18:51 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:18:51 --> Session Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:18:51 --> Session routines successfully run
DEBUG - 2013-04-12 13:18:51 --> Controller Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Language Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Config Class Initialized
DEBUG - 2013-04-12 13:18:51 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-12 13:18:51 --> Loader Class Initialized
DEBUG - 2013-04-12 13:18:51 --> File loaded: ../application/admin/modules/autenticacao/views/login.php
DEBUG - 2013-04-12 13:18:51 --> Final output sent to browser
DEBUG - 2013-04-12 13:18:51 --> Total execution time: 0.0175
DEBUG - 2013-04-12 13:18:55 --> Config Class Initialized
DEBUG - 2013-04-12 13:18:55 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:18:55 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:18:55 --> URI Class Initialized
DEBUG - 2013-04-12 13:18:55 --> Router Class Initialized
DEBUG - 2013-04-12 13:18:55 --> Output Class Initialized
DEBUG - 2013-04-12 13:18:55 --> Security Class Initialized
DEBUG - 2013-04-12 13:18:55 --> Input Class Initialized
DEBUG - 2013-04-12 13:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:18:55 --> Language Class Initialized
DEBUG - 2013-04-12 13:18:55 --> Loader Class Initialized
DEBUG - 2013-04-12 13:18:55 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:18:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:18:55 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:18:55 --> Session Class Initialized
DEBUG - 2013-04-12 13:18:55 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:18:55 --> Session routines successfully run
DEBUG - 2013-04-12 13:18:55 --> Controller Class Initialized
DEBUG - 2013-04-12 13:18:55 --> Language Class Initialized
DEBUG - 2013-04-12 13:18:55 --> Config Class Initialized
DEBUG - 2013-04-12 13:18:55 --> Autenticacao MX_Controller Initialized
DEBUG - 2013-04-12 13:18:55 --> Loader Class Initialized
DEBUG - 2013-04-12 13:18:55 --> Model Class Initialized
DEBUG - 2013-04-12 13:18:55 --> Model Class Initialized
DEBUG - 2013-04-12 13:18:55 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:18:56 --> Model Class Initialized
ERROR - 2013-04-12 13:18:56 --> Severity: Notice  --> Undefined index: orlike /home/w3case/public_html/target-git/application/admin/models/crud.php 121
ERROR - 2013-04-12 13:18:56 --> Severity: Notice  --> Undefined index: orlike /home/w3case/public_html/target-git/application/admin/models/crud.php 121
DEBUG - 2013-04-12 13:18:56 --> Final output sent to browser
DEBUG - 2013-04-12 13:18:56 --> Total execution time: 0.6690
DEBUG - 2013-04-12 13:18:56 --> Config Class Initialized
DEBUG - 2013-04-12 13:18:56 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:18:56 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:18:56 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:18:56 --> URI Class Initialized
DEBUG - 2013-04-12 13:18:56 --> Router Class Initialized
DEBUG - 2013-04-12 13:18:56 --> Output Class Initialized
DEBUG - 2013-04-12 13:18:56 --> Security Class Initialized
DEBUG - 2013-04-12 13:18:56 --> Input Class Initialized
DEBUG - 2013-04-12 13:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:18:56 --> Language Class Initialized
DEBUG - 2013-04-12 13:18:56 --> Loader Class Initialized
DEBUG - 2013-04-12 13:18:56 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:18:56 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:18:56 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:18:56 --> Session Class Initialized
DEBUG - 2013-04-12 13:18:56 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:18:56 --> Session routines successfully run
DEBUG - 2013-04-12 13:18:56 --> Controller Class Initialized
DEBUG - 2013-04-12 13:18:56 --> Language Class Initialized
DEBUG - 2013-04-12 13:18:56 --> Config Class Initialized
DEBUG - 2013-04-12 13:18:56 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-12 13:18:56 --> Loader Class Initialized
DEBUG - 2013-04-12 13:18:56 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-12 13:18:56 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:18:56 --> Final output sent to browser
DEBUG - 2013-04-12 13:18:56 --> Total execution time: 0.0195
DEBUG - 2013-04-12 13:18:59 --> Config Class Initialized
DEBUG - 2013-04-12 13:18:59 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:18:59 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:18:59 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:18:59 --> URI Class Initialized
DEBUG - 2013-04-12 13:18:59 --> Router Class Initialized
DEBUG - 2013-04-12 13:18:59 --> Output Class Initialized
DEBUG - 2013-04-12 13:18:59 --> Security Class Initialized
DEBUG - 2013-04-12 13:18:59 --> Input Class Initialized
DEBUG - 2013-04-12 13:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:18:59 --> Language Class Initialized
DEBUG - 2013-04-12 13:18:59 --> Loader Class Initialized
DEBUG - 2013-04-12 13:18:59 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:18:59 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:18:59 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:18:59 --> Session Class Initialized
DEBUG - 2013-04-12 13:18:59 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:18:59 --> Session routines successfully run
DEBUG - 2013-04-12 13:18:59 --> Controller Class Initialized
DEBUG - 2013-04-12 13:18:59 --> Language Class Initialized
DEBUG - 2013-04-12 13:18:59 --> Config Class Initialized
DEBUG - 2013-04-12 13:18:59 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:18:59 --> Loader Class Initialized
DEBUG - 2013-04-12 13:18:59 --> Model Class Initialized
DEBUG - 2013-04-12 13:18:59 --> Model Class Initialized
DEBUG - 2013-04-12 13:18:59 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:18:59 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:18:59 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-12 13:18:59 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:18:59 --> Final output sent to browser
DEBUG - 2013-04-12 13:18:59 --> Total execution time: 0.0237
DEBUG - 2013-04-12 13:19:01 --> Config Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:19:01 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:19:01 --> URI Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Router Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Output Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Security Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Input Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:19:01 --> Language Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Loader Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:19:01 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:19:01 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:19:01 --> Session Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:19:01 --> Session routines successfully run
DEBUG - 2013-04-12 13:19:01 --> Controller Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Language Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Config Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:19:01 --> Loader Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Model Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Model Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:19:01 --> Model Class Initialized
DEBUG - 2013-04-12 13:19:01 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:19:01 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 13:19:01 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:19:01 --> Final output sent to browser
DEBUG - 2013-04-12 13:19:01 --> Total execution time: 0.0268
DEBUG - 2013-04-12 13:19:03 --> Config Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:19:03 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:19:03 --> URI Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Router Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Output Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Security Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Input Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:19:03 --> Language Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Loader Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:19:03 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:19:03 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:19:03 --> Session Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:19:03 --> Session routines successfully run
DEBUG - 2013-04-12 13:19:03 --> Controller Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Language Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Config Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:19:03 --> Loader Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Model Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Model Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Model Class Initialized
DEBUG - 2013-04-12 13:19:03 --> Final output sent to browser
DEBUG - 2013-04-12 13:19:03 --> Total execution time: 0.0241
DEBUG - 2013-04-12 13:19:04 --> Config Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:19:04 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:19:04 --> URI Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Router Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Output Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Security Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Input Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:19:04 --> Language Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Loader Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:19:04 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:19:04 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:19:04 --> Session Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:19:04 --> Session routines successfully run
DEBUG - 2013-04-12 13:19:04 --> Controller Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Language Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Config Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:19:04 --> Loader Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Model Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Model Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Model Class Initialized
DEBUG - 2013-04-12 13:19:04 --> Final output sent to browser
DEBUG - 2013-04-12 13:19:04 --> Total execution time: 0.0240
DEBUG - 2013-04-12 13:22:45 --> Config Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:22:45 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:22:45 --> URI Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Router Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Output Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Security Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Input Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:22:45 --> Language Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Loader Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:22:45 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:22:45 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:22:45 --> Session Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:22:45 --> Session routines successfully run
DEBUG - 2013-04-12 13:22:45 --> Controller Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Language Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Config Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:22:45 --> Loader Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:45 --> Final output sent to browser
DEBUG - 2013-04-12 13:22:45 --> Total execution time: 0.1403
DEBUG - 2013-04-12 13:22:48 --> Config Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:22:48 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:22:48 --> URI Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Router Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Output Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Security Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Input Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:22:48 --> Language Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Loader Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:22:48 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:22:48 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:22:48 --> Session Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:22:48 --> Session routines successfully run
DEBUG - 2013-04-12 13:22:48 --> Controller Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Language Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Config Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:22:48 --> Loader Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:48 --> Final output sent to browser
DEBUG - 2013-04-12 13:22:48 --> Total execution time: 0.1415
DEBUG - 2013-04-12 13:22:49 --> Config Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:22:49 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:22:49 --> URI Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Router Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Output Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Security Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Input Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:22:49 --> Language Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Loader Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:22:49 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:22:49 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:22:49 --> Session Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:22:49 --> Session routines successfully run
DEBUG - 2013-04-12 13:22:49 --> Controller Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Language Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Config Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:22:49 --> Loader Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:22:49 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:49 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:22:49 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 13:22:49 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:22:49 --> Final output sent to browser
DEBUG - 2013-04-12 13:22:49 --> Total execution time: 0.0249
DEBUG - 2013-04-12 13:22:52 --> Config Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:22:52 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:22:52 --> URI Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Router Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Output Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Security Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Input Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:22:52 --> Language Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Loader Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:22:52 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:22:52 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:22:52 --> Session Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:22:52 --> Session routines successfully run
DEBUG - 2013-04-12 13:22:52 --> Controller Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Language Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Config Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:22:52 --> Loader Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:22:52 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:52 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:22:52 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 13:22:52 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:22:52 --> Final output sent to browser
DEBUG - 2013-04-12 13:22:52 --> Total execution time: 0.0244
DEBUG - 2013-04-12 13:22:55 --> Config Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:22:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:22:55 --> URI Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Router Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Output Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Security Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Input Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:22:55 --> Language Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Loader Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:22:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:22:55 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:22:55 --> Session Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:22:55 --> Session routines successfully run
DEBUG - 2013-04-12 13:22:55 --> Controller Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Language Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Config Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:22:55 --> Loader Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:22:55 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Final output sent to browser
DEBUG - 2013-04-12 13:22:56 --> Total execution time: 0.1199
DEBUG - 2013-04-12 13:22:56 --> Config Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:22:56 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:22:56 --> URI Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Router Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Output Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Security Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Input Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:22:56 --> Language Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Loader Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:22:56 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:22:56 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:22:56 --> Session Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:22:56 --> Session routines successfully run
DEBUG - 2013-04-12 13:22:56 --> Controller Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Language Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Config Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:22:56 --> Loader Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Model Class Initialized
DEBUG - 2013-04-12 13:22:56 --> Final output sent to browser
DEBUG - 2013-04-12 13:22:56 --> Total execution time: 0.1419
DEBUG - 2013-04-12 13:25:55 --> Config Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:25:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:25:55 --> URI Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Router Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Output Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Security Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Input Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:25:55 --> Language Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Loader Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:25:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:25:55 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:25:55 --> Session Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:25:55 --> Session routines successfully run
DEBUG - 2013-04-12 13:25:55 --> Controller Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Language Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Config Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:25:55 --> Loader Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Model Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Model Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:25:55 --> Model Class Initialized
DEBUG - 2013-04-12 13:25:55 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:25:55 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 13:25:55 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:25:55 --> Final output sent to browser
DEBUG - 2013-04-12 13:25:55 --> Total execution time: 0.0323
DEBUG - 2013-04-12 13:25:57 --> Config Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:25:57 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:25:57 --> URI Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Router Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Output Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Security Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Input Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:25:57 --> Language Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Loader Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:25:57 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:25:57 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:25:57 --> Session Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:25:57 --> Session routines successfully run
DEBUG - 2013-04-12 13:25:57 --> Controller Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Language Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Config Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:25:57 --> Loader Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Model Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Model Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Model Class Initialized
DEBUG - 2013-04-12 13:25:57 --> Final output sent to browser
DEBUG - 2013-04-12 13:25:57 --> Total execution time: 0.2652
DEBUG - 2013-04-12 13:31:04 --> Config Class Initialized
DEBUG - 2013-04-12 13:31:04 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:31:04 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:31:04 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:31:04 --> URI Class Initialized
DEBUG - 2013-04-12 13:31:04 --> Router Class Initialized
DEBUG - 2013-04-12 13:31:04 --> Output Class Initialized
DEBUG - 2013-04-12 13:31:04 --> Security Class Initialized
DEBUG - 2013-04-12 13:31:04 --> Input Class Initialized
DEBUG - 2013-04-12 13:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:31:04 --> Language Class Initialized
DEBUG - 2013-04-12 13:31:04 --> Loader Class Initialized
DEBUG - 2013-04-12 13:31:04 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:31:04 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:31:04 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:31:04 --> Session Class Initialized
DEBUG - 2013-04-12 13:31:04 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:31:04 --> Session routines successfully run
DEBUG - 2013-04-12 13:31:04 --> Controller Class Initialized
DEBUG - 2013-04-12 13:31:04 --> Language Class Initialized
DEBUG - 2013-04-12 13:31:04 --> Config Class Initialized
DEBUG - 2013-04-12 13:31:04 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:31:04 --> Loader Class Initialized
DEBUG - 2013-04-12 13:31:04 --> Model Class Initialized
DEBUG - 2013-04-12 13:31:04 --> Model Class Initialized
DEBUG - 2013-04-12 13:31:04 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:31:04 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:31:04 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 13:31:04 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:31:04 --> Final output sent to browser
DEBUG - 2013-04-12 13:31:04 --> Total execution time: 0.0230
DEBUG - 2013-04-12 13:31:09 --> Config Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:31:09 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:31:09 --> URI Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Router Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Output Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Security Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Input Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:31:09 --> Language Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Loader Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:31:09 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:31:09 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:31:09 --> Session Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:31:09 --> Session routines successfully run
DEBUG - 2013-04-12 13:31:09 --> Controller Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Language Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Config Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:31:09 --> Loader Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Model Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Model Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:31:09 --> Model Class Initialized
DEBUG - 2013-04-12 13:31:09 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:31:09 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 13:31:09 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:31:09 --> Final output sent to browser
DEBUG - 2013-04-12 13:31:09 --> Total execution time: 0.0272
DEBUG - 2013-04-12 13:34:49 --> Config Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:34:49 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:34:49 --> URI Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Router Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Output Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Security Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Input Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:34:49 --> Language Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Loader Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:34:49 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:34:49 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:34:49 --> Session Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:34:49 --> Session routines successfully run
DEBUG - 2013-04-12 13:34:49 --> Controller Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Language Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Config Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:34:49 --> Loader Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Model Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Model Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:34:49 --> Model Class Initialized
DEBUG - 2013-04-12 13:34:49 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:34:49 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 13:34:49 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:34:49 --> Final output sent to browser
DEBUG - 2013-04-12 13:34:49 --> Total execution time: 0.0344
DEBUG - 2013-04-12 13:38:38 --> Config Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:38:38 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:38:38 --> URI Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Router Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Output Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Security Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Input Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:38:38 --> Language Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Loader Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:38:38 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:38:38 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:38:38 --> Session Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:38:38 --> Session routines successfully run
DEBUG - 2013-04-12 13:38:38 --> Controller Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Language Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Config Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:38:38 --> Loader Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Model Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Model Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:38:38 --> Model Class Initialized
DEBUG - 2013-04-12 13:38:38 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:38:38 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 13:38:38 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:38:38 --> Final output sent to browser
DEBUG - 2013-04-12 13:38:38 --> Total execution time: 0.0270
DEBUG - 2013-04-12 13:38:58 --> Config Class Initialized
DEBUG - 2013-04-12 13:38:58 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:38:58 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:38:58 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:38:58 --> URI Class Initialized
DEBUG - 2013-04-12 13:38:58 --> Router Class Initialized
DEBUG - 2013-04-12 13:38:58 --> Output Class Initialized
DEBUG - 2013-04-12 13:38:58 --> Security Class Initialized
DEBUG - 2013-04-12 13:38:58 --> Input Class Initialized
DEBUG - 2013-04-12 13:39:33 --> Config Class Initialized
DEBUG - 2013-04-12 13:39:33 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:39:33 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:39:33 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:39:33 --> URI Class Initialized
DEBUG - 2013-04-12 13:39:33 --> Router Class Initialized
DEBUG - 2013-04-12 13:39:33 --> Output Class Initialized
DEBUG - 2013-04-12 13:39:33 --> Security Class Initialized
DEBUG - 2013-04-12 13:39:33 --> Input Class Initialized
DEBUG - 2013-04-12 13:41:12 --> Config Class Initialized
DEBUG - 2013-04-12 13:41:12 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:41:12 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:41:12 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:41:12 --> URI Class Initialized
DEBUG - 2013-04-12 13:41:12 --> Router Class Initialized
DEBUG - 2013-04-12 13:41:12 --> Output Class Initialized
DEBUG - 2013-04-12 13:41:12 --> Security Class Initialized
DEBUG - 2013-04-12 13:41:12 --> Input Class Initialized
DEBUG - 2013-04-12 13:41:14 --> Config Class Initialized
DEBUG - 2013-04-12 13:41:14 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:41:14 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:41:14 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:41:14 --> URI Class Initialized
DEBUG - 2013-04-12 13:41:14 --> Router Class Initialized
DEBUG - 2013-04-12 13:41:14 --> Output Class Initialized
DEBUG - 2013-04-12 13:41:14 --> Security Class Initialized
DEBUG - 2013-04-12 13:41:14 --> Input Class Initialized
DEBUG - 2013-04-12 13:41:14 --> Config Class Initialized
DEBUG - 2013-04-12 13:41:14 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:41:14 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:41:14 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:41:14 --> URI Class Initialized
DEBUG - 2013-04-12 13:41:14 --> Router Class Initialized
DEBUG - 2013-04-12 13:41:14 --> Output Class Initialized
DEBUG - 2013-04-12 13:41:14 --> Security Class Initialized
DEBUG - 2013-04-12 13:41:14 --> Input Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Config Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:41:15 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:41:15 --> URI Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Router Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Output Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Security Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Input Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Config Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:41:15 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:41:15 --> URI Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Router Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Output Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Security Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Input Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Config Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:41:15 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:41:15 --> URI Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Router Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Output Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Security Class Initialized
DEBUG - 2013-04-12 13:41:15 --> Input Class Initialized
DEBUG - 2013-04-12 13:41:32 --> Config Class Initialized
DEBUG - 2013-04-12 13:41:32 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:41:32 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:41:32 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:41:32 --> URI Class Initialized
DEBUG - 2013-04-12 13:41:32 --> Router Class Initialized
DEBUG - 2013-04-12 13:41:32 --> Output Class Initialized
DEBUG - 2013-04-12 13:41:32 --> Security Class Initialized
DEBUG - 2013-04-12 13:41:32 --> Input Class Initialized
DEBUG - 2013-04-12 13:41:37 --> Config Class Initialized
DEBUG - 2013-04-12 13:41:37 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:41:37 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:41:37 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:41:37 --> URI Class Initialized
DEBUG - 2013-04-12 13:41:37 --> Router Class Initialized
DEBUG - 2013-04-12 13:41:37 --> Output Class Initialized
DEBUG - 2013-04-12 13:41:37 --> Security Class Initialized
DEBUG - 2013-04-12 13:41:37 --> Input Class Initialized
DEBUG - 2013-04-12 13:41:53 --> Config Class Initialized
DEBUG - 2013-04-12 13:41:53 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:41:53 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:41:53 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:41:53 --> URI Class Initialized
DEBUG - 2013-04-12 13:41:53 --> Router Class Initialized
DEBUG - 2013-04-12 13:41:53 --> Output Class Initialized
DEBUG - 2013-04-12 13:41:53 --> Security Class Initialized
DEBUG - 2013-04-12 13:41:53 --> Input Class Initialized
DEBUG - 2013-04-12 13:42:21 --> Config Class Initialized
DEBUG - 2013-04-12 13:42:21 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:42:21 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:42:21 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:42:21 --> URI Class Initialized
DEBUG - 2013-04-12 13:42:21 --> Router Class Initialized
DEBUG - 2013-04-12 13:42:21 --> Output Class Initialized
DEBUG - 2013-04-12 13:42:21 --> Security Class Initialized
DEBUG - 2013-04-12 13:42:21 --> Input Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Config Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:42:47 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:42:47 --> URI Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Router Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Output Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Security Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Input Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:42:47 --> Language Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Loader Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:42:47 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:42:47 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:42:47 --> Session Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:42:47 --> Session routines successfully run
DEBUG - 2013-04-12 13:42:47 --> Controller Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Language Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Config Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:42:47 --> Loader Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Model Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Model Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:42:47 --> Model Class Initialized
DEBUG - 2013-04-12 13:42:47 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:42:47 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 13:42:47 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:42:47 --> Final output sent to browser
DEBUG - 2013-04-12 13:42:47 --> Total execution time: 0.0268
DEBUG - 2013-04-12 13:42:50 --> Config Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:42:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:42:50 --> URI Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Router Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Output Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Security Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Input Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:42:50 --> Language Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Loader Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:42:50 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:42:50 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:42:50 --> Session Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:42:50 --> Session routines successfully run
DEBUG - 2013-04-12 13:42:50 --> Controller Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Language Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Config Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:42:50 --> Loader Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Model Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Model Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:42:50 --> Model Class Initialized
DEBUG - 2013-04-12 13:42:50 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:42:50 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 13:42:50 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:42:50 --> Final output sent to browser
DEBUG - 2013-04-12 13:42:50 --> Total execution time: 0.0260
DEBUG - 2013-04-12 13:42:52 --> Config Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:42:52 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:42:52 --> URI Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Router Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Output Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Security Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Input Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:42:52 --> Language Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Loader Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:42:52 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:42:52 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:42:52 --> Session Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:42:52 --> Session routines successfully run
DEBUG - 2013-04-12 13:42:52 --> Controller Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Language Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Config Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:42:52 --> Loader Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Model Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Model Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Model Class Initialized
DEBUG - 2013-04-12 13:42:52 --> Final output sent to browser
DEBUG - 2013-04-12 13:42:52 --> Total execution time: 0.7054
DEBUG - 2013-04-12 13:42:59 --> Config Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:42:59 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:42:59 --> URI Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Router Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Output Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Security Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Input Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:42:59 --> Language Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Loader Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:42:59 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:42:59 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:42:59 --> Session Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:42:59 --> Session routines successfully run
DEBUG - 2013-04-12 13:42:59 --> Controller Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Language Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Config Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:42:59 --> Loader Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Model Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Model Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:42:59 --> Model Class Initialized
DEBUG - 2013-04-12 13:43:00 --> Final output sent to browser
DEBUG - 2013-04-12 13:43:00 --> Total execution time: 0.3652
DEBUG - 2013-04-12 13:43:57 --> Config Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:43:57 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:43:57 --> URI Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Router Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Output Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Security Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Input Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:43:57 --> Language Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Loader Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:43:57 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:43:57 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:43:57 --> Session Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:43:57 --> Session routines successfully run
DEBUG - 2013-04-12 13:43:57 --> Controller Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Language Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Config Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:43:57 --> Loader Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Model Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Model Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:43:57 --> Model Class Initialized
DEBUG - 2013-04-12 13:43:57 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:43:57 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 13:43:57 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:43:57 --> Final output sent to browser
DEBUG - 2013-04-12 13:43:57 --> Total execution time: 0.0353
DEBUG - 2013-04-12 13:44:38 --> Config Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:44:38 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:44:38 --> URI Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Router Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Output Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Security Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Input Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:44:38 --> Language Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Loader Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:44:38 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:44:38 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:44:38 --> Session Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:44:38 --> Session routines successfully run
DEBUG - 2013-04-12 13:44:38 --> Controller Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Language Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Config Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:44:38 --> Loader Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Model Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Model Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:44:38 --> Model Class Initialized
DEBUG - 2013-04-12 13:44:38 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:44:38 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 13:44:38 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:44:38 --> Final output sent to browser
DEBUG - 2013-04-12 13:44:38 --> Total execution time: 0.0346
DEBUG - 2013-04-12 13:45:37 --> Config Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:45:37 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:45:37 --> URI Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Router Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Output Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Security Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Input Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:45:37 --> Language Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Loader Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:45:37 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:45:37 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:45:37 --> Session Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:45:37 --> Session routines successfully run
DEBUG - 2013-04-12 13:45:37 --> Controller Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Language Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Config Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:45:37 --> Loader Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Model Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Model Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:45:37 --> Model Class Initialized
DEBUG - 2013-04-12 13:45:37 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:45:37 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 13:45:37 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:45:37 --> Final output sent to browser
DEBUG - 2013-04-12 13:45:37 --> Total execution time: 0.0283
DEBUG - 2013-04-12 13:54:07 --> Config Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:54:07 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:54:07 --> URI Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Router Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Output Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Security Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Input Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:54:07 --> Language Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Loader Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:54:07 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:54:07 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:54:07 --> Session Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:54:07 --> Session routines successfully run
DEBUG - 2013-04-12 13:54:07 --> Controller Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Language Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Config Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:54:07 --> Loader Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Model Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Model Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:54:07 --> Model Class Initialized
DEBUG - 2013-04-12 13:54:07 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:54:07 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 13:54:07 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:54:07 --> Final output sent to browser
DEBUG - 2013-04-12 13:54:07 --> Total execution time: 0.0281
DEBUG - 2013-04-12 13:55:00 --> Config Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:55:00 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:55:00 --> URI Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Router Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Output Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Security Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Input Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:55:00 --> Language Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Loader Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:55:00 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:55:00 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:55:00 --> Session Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:55:00 --> Session routines successfully run
DEBUG - 2013-04-12 13:55:00 --> Controller Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Language Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Config Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:55:00 --> Loader Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Model Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Model Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:55:00 --> Model Class Initialized
DEBUG - 2013-04-12 13:55:00 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:55:00 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 13:55:00 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:55:00 --> Final output sent to browser
DEBUG - 2013-04-12 13:55:00 --> Total execution time: 0.0342
DEBUG - 2013-04-12 13:56:23 --> Config Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:56:23 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:56:23 --> URI Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Router Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Output Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Security Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Input Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:56:23 --> Language Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Loader Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:56:23 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:56:23 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:56:23 --> Session Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:56:23 --> Session routines successfully run
DEBUG - 2013-04-12 13:56:23 --> Controller Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Language Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Config Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:56:23 --> Loader Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Model Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Model Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:56:23 --> Model Class Initialized
DEBUG - 2013-04-12 13:56:23 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:56:23 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 13:56:23 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:56:23 --> Final output sent to browser
DEBUG - 2013-04-12 13:56:23 --> Total execution time: 0.0321
DEBUG - 2013-04-12 13:57:35 --> Config Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:57:35 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:57:35 --> URI Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Router Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Output Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Security Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Input Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:57:35 --> Language Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Loader Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:57:35 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:57:35 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:57:35 --> Session Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:57:35 --> Session routines successfully run
DEBUG - 2013-04-12 13:57:35 --> Controller Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Language Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Config Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:57:35 --> Loader Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Model Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Model Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:57:35 --> Model Class Initialized
DEBUG - 2013-04-12 13:57:35 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 13:57:35 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 13:57:35 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:57:35 --> Final output sent to browser
DEBUG - 2013-04-12 13:57:35 --> Total execution time: 0.0267
DEBUG - 2013-04-12 13:58:53 --> Config Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Hooks Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Utf8 Class Initialized
DEBUG - 2013-04-12 13:58:53 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 13:58:53 --> URI Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Router Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Output Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Security Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Input Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 13:58:53 --> Language Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Loader Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Helper loaded: url_helper
DEBUG - 2013-04-12 13:58:53 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 13:58:53 --> Helper loaded: text_helper
DEBUG - 2013-04-12 13:58:53 --> Session Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Helper loaded: string_helper
DEBUG - 2013-04-12 13:58:53 --> Session routines successfully run
DEBUG - 2013-04-12 13:58:53 --> Controller Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Language Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Config Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 13:58:53 --> Loader Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Model Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Model Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Database Driver Class Initialized
DEBUG - 2013-04-12 13:58:53 --> Model Class Initialized
DEBUG - 2013-04-12 13:58:53 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
ERROR - 2013-04-12 13:58:53 --> Severity: Notice  --> Undefined property: stdClass::$caminhoArquivos /home/w3case/public_html/target-git/application/admin/modules/configuracao/views/geral.php 24
DEBUG - 2013-04-12 13:58:53 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 13:58:53 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 13:58:53 --> Final output sent to browser
DEBUG - 2013-04-12 13:58:53 --> Total execution time: 0.0350
DEBUG - 2013-04-12 14:02:30 --> Config Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:02:30 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:02:30 --> URI Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Router Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Output Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Security Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Input Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:02:30 --> Language Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Loader Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:02:30 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:02:30 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:02:30 --> Session Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:02:30 --> Session routines successfully run
DEBUG - 2013-04-12 14:02:30 --> Controller Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Language Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Config Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:02:30 --> Loader Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Model Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Model Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:02:30 --> Model Class Initialized
DEBUG - 2013-04-12 14:02:30 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:02:30 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 14:02:30 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:02:30 --> Final output sent to browser
DEBUG - 2013-04-12 14:02:30 --> Total execution time: 0.0339
DEBUG - 2013-04-12 14:02:44 --> Config Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:02:44 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:02:44 --> URI Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Router Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Output Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Security Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Input Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:02:44 --> Language Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Loader Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:02:44 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:02:44 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:02:44 --> Session Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:02:44 --> Session routines successfully run
DEBUG - 2013-04-12 14:02:44 --> Controller Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Language Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Config Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:02:44 --> Loader Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Model Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Model Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:02:44 --> Model Class Initialized
DEBUG - 2013-04-12 14:02:44 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:02:44 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 14:02:44 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:02:44 --> Final output sent to browser
DEBUG - 2013-04-12 14:02:44 --> Total execution time: 0.0332
DEBUG - 2013-04-12 14:02:55 --> Config Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:02:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:02:55 --> URI Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Router Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Output Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Security Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Input Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:02:55 --> Language Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Loader Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:02:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:02:55 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:02:55 --> Session Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:02:55 --> Session routines successfully run
DEBUG - 2013-04-12 14:02:55 --> Controller Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Language Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Config Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:02:55 --> Loader Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Model Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Model Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:02:55 --> Model Class Initialized
DEBUG - 2013-04-12 14:02:55 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:02:55 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 14:02:55 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:02:55 --> Final output sent to browser
DEBUG - 2013-04-12 14:02:55 --> Total execution time: 0.0347
DEBUG - 2013-04-12 14:03:53 --> Config Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:03:53 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:03:53 --> URI Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Router Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Output Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Security Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Input Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:03:53 --> Language Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Loader Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:03:53 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:03:53 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:03:53 --> Session Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:03:53 --> Session routines successfully run
DEBUG - 2013-04-12 14:03:53 --> Controller Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Language Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Config Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:03:53 --> Loader Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Model Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Model Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:03:53 --> Model Class Initialized
DEBUG - 2013-04-12 14:03:53 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:03:53 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 14:03:53 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:03:53 --> Final output sent to browser
DEBUG - 2013-04-12 14:03:53 --> Total execution time: 0.0319
DEBUG - 2013-04-12 14:05:49 --> Config Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:05:49 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:05:49 --> URI Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Router Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Output Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Security Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Input Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:05:49 --> Language Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Loader Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:05:49 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:05:49 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:05:49 --> Session Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:05:49 --> Session routines successfully run
DEBUG - 2013-04-12 14:05:49 --> Controller Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Language Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Config Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:05:49 --> Loader Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Model Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Model Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:05:49 --> Model Class Initialized
DEBUG - 2013-04-12 14:05:49 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
ERROR - 2013-04-12 14:05:49 --> Severity: Notice  --> Undefined property: stdClass::$parametro /home/w3case/public_html/target-git/application/admin/modules/configuracao/views/geral.php 26
ERROR - 2013-04-12 14:05:49 --> Severity: Notice  --> Undefined property: stdClass::$parametro /home/w3case/public_html/target-git/application/admin/modules/configuracao/views/geral.php 26
ERROR - 2013-04-12 14:05:49 --> Severity: Notice  --> Undefined property: stdClass::$parametro /home/w3case/public_html/target-git/application/admin/modules/configuracao/views/geral.php 26
ERROR - 2013-04-12 14:05:49 --> Severity: Notice  --> Undefined property: stdClass::$parametro /home/w3case/public_html/target-git/application/admin/modules/configuracao/views/geral.php 26
ERROR - 2013-04-12 14:05:49 --> Severity: Notice  --> Undefined property: stdClass::$parametro /home/w3case/public_html/target-git/application/admin/modules/configuracao/views/geral.php 26
ERROR - 2013-04-12 14:05:49 --> Severity: Notice  --> Undefined property: stdClass::$parametro /home/w3case/public_html/target-git/application/admin/modules/configuracao/views/geral.php 26
ERROR - 2013-04-12 14:05:49 --> Severity: Notice  --> Undefined property: stdClass::$parametro /home/w3case/public_html/target-git/application/admin/modules/configuracao/views/geral.php 26
ERROR - 2013-04-12 14:05:49 --> Severity: Notice  --> Undefined property: stdClass::$parametro /home/w3case/public_html/target-git/application/admin/modules/configuracao/views/geral.php 26
ERROR - 2013-04-12 14:05:49 --> Severity: Notice  --> Undefined property: stdClass::$parametro /home/w3case/public_html/target-git/application/admin/modules/configuracao/views/geral.php 26
DEBUG - 2013-04-12 14:05:49 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 14:05:49 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:05:49 --> Final output sent to browser
DEBUG - 2013-04-12 14:05:49 --> Total execution time: 0.0346
DEBUG - 2013-04-12 14:06:00 --> Config Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:06:00 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:06:00 --> URI Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Router Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Output Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Security Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Input Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:06:00 --> Language Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Loader Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:06:00 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:06:00 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:06:00 --> Session Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:06:00 --> Session routines successfully run
DEBUG - 2013-04-12 14:06:00 --> Controller Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Language Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Config Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:06:00 --> Loader Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Model Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Model Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:06:00 --> Model Class Initialized
DEBUG - 2013-04-12 14:06:00 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:06:00 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 14:06:00 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:06:00 --> Final output sent to browser
DEBUG - 2013-04-12 14:06:00 --> Total execution time: 0.0357
DEBUG - 2013-04-12 14:06:11 --> Config Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:06:11 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:06:11 --> URI Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Router Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Output Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Security Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Input Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:06:11 --> Language Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Loader Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:06:11 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:06:11 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:06:11 --> Session Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:06:11 --> Session routines successfully run
DEBUG - 2013-04-12 14:06:11 --> Controller Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Language Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Config Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:06:11 --> Loader Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Model Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Model Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:06:11 --> Model Class Initialized
DEBUG - 2013-04-12 14:06:11 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:06:11 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 14:06:11 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:06:11 --> Final output sent to browser
DEBUG - 2013-04-12 14:06:11 --> Total execution time: 0.0327
DEBUG - 2013-04-12 14:06:14 --> Config Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:06:14 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:06:14 --> URI Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Router Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Output Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Security Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Input Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:06:14 --> Language Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Loader Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:06:14 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:06:14 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:06:14 --> Session Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:06:14 --> Session routines successfully run
DEBUG - 2013-04-12 14:06:14 --> Controller Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Language Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Config Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:06:14 --> Loader Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Model Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Model Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:06:14 --> Model Class Initialized
DEBUG - 2013-04-12 14:06:14 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:06:14 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 14:06:14 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:06:14 --> Final output sent to browser
DEBUG - 2013-04-12 14:06:14 --> Total execution time: 0.0248
DEBUG - 2013-04-12 14:07:19 --> Config Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:07:19 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:07:19 --> URI Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Router Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Output Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Security Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Input Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:07:19 --> Language Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Loader Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:07:19 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:07:19 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:07:19 --> Session Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:07:19 --> Session routines successfully run
DEBUG - 2013-04-12 14:07:19 --> Controller Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Language Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Config Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:07:19 --> Loader Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Model Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Model Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:07:19 --> Model Class Initialized
DEBUG - 2013-04-12 14:07:19 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:07:19 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 14:07:19 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:07:19 --> Final output sent to browser
DEBUG - 2013-04-12 14:07:19 --> Total execution time: 0.0265
DEBUG - 2013-04-12 14:07:22 --> Config Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:07:22 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:07:22 --> URI Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Router Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Output Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Security Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Input Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:07:22 --> Language Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Loader Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:07:22 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:07:22 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:07:22 --> Session Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:07:22 --> Session routines successfully run
DEBUG - 2013-04-12 14:07:22 --> Controller Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Language Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Config Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:07:22 --> Loader Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Model Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Model Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Model Class Initialized
DEBUG - 2013-04-12 14:07:22 --> Final output sent to browser
DEBUG - 2013-04-12 14:07:22 --> Total execution time: 0.0385
DEBUG - 2013-04-12 14:08:17 --> Config Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:08:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:08:17 --> URI Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Router Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Output Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Security Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Input Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:08:17 --> Language Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Loader Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:08:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:08:17 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:08:17 --> Session Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:08:17 --> Session routines successfully run
DEBUG - 2013-04-12 14:08:17 --> Controller Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Language Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Config Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:08:17 --> Loader Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Model Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Model Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:08:17 --> Model Class Initialized
DEBUG - 2013-04-12 14:08:17 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:08:17 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 14:08:17 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:08:17 --> Final output sent to browser
DEBUG - 2013-04-12 14:08:17 --> Total execution time: 0.0240
DEBUG - 2013-04-12 14:09:55 --> Config Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:09:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:09:55 --> URI Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Router Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Output Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Security Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Input Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:09:55 --> Language Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Loader Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:09:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:09:55 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:09:55 --> Session Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:09:55 --> Session routines successfully run
DEBUG - 2013-04-12 14:09:55 --> Controller Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Language Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Config Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:09:55 --> Loader Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Model Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Model Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:09:55 --> Model Class Initialized
DEBUG - 2013-04-12 14:09:55 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:09:55 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 14:09:55 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:09:55 --> Final output sent to browser
DEBUG - 2013-04-12 14:09:55 --> Total execution time: 0.0250
DEBUG - 2013-04-12 14:10:21 --> Config Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:10:21 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:10:21 --> URI Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Router Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Output Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Security Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Input Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:10:21 --> Language Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Loader Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:10:21 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:10:21 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:10:21 --> Session Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:10:21 --> Session routines successfully run
DEBUG - 2013-04-12 14:10:21 --> Controller Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Language Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Config Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:10:21 --> Loader Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Model Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Model Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:10:21 --> Model Class Initialized
DEBUG - 2013-04-12 14:10:21 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:10:21 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 14:10:21 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:10:21 --> Final output sent to browser
DEBUG - 2013-04-12 14:10:21 --> Total execution time: 0.0334
DEBUG - 2013-04-12 14:11:14 --> Config Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:11:14 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:11:14 --> URI Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Router Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Output Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Security Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Input Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:11:14 --> Language Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Loader Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:11:14 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:11:14 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:11:14 --> Session Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:11:14 --> Session routines successfully run
DEBUG - 2013-04-12 14:11:14 --> Controller Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Language Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Config Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:11:14 --> Loader Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Model Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Model Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:11:14 --> Model Class Initialized
DEBUG - 2013-04-12 14:11:14 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:11:14 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 14:11:14 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:11:14 --> Final output sent to browser
DEBUG - 2013-04-12 14:11:14 --> Total execution time: 0.0273
DEBUG - 2013-04-12 14:12:15 --> Config Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:12:15 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:12:15 --> URI Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Router Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Output Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Security Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Input Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:12:15 --> Language Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Loader Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:12:15 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:12:15 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:12:15 --> Session Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:12:15 --> Session routines successfully run
DEBUG - 2013-04-12 14:12:15 --> Controller Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Language Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Config Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:12:15 --> Loader Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Model Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Model Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:12:15 --> Model Class Initialized
DEBUG - 2013-04-12 14:12:15 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:12:15 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 14:12:15 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:12:15 --> Final output sent to browser
DEBUG - 2013-04-12 14:12:15 --> Total execution time: 0.0244
DEBUG - 2013-04-12 14:12:22 --> Config Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:12:22 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:12:22 --> URI Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Router Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Output Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Security Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Input Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:12:22 --> Language Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Loader Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:12:22 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:12:22 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:12:22 --> Session Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:12:22 --> Session routines successfully run
DEBUG - 2013-04-12 14:12:22 --> Controller Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Language Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Config Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:12:22 --> Loader Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Model Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Model Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:12:22 --> Model Class Initialized
DEBUG - 2013-04-12 14:12:22 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:12:22 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 14:12:22 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:12:22 --> Final output sent to browser
DEBUG - 2013-04-12 14:12:22 --> Total execution time: 0.0345
DEBUG - 2013-04-12 14:12:55 --> Config Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:12:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:12:55 --> URI Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Router Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Output Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Security Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Input Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:12:55 --> Language Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Loader Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:12:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:12:55 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:12:55 --> Session Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:12:55 --> Session routines successfully run
DEBUG - 2013-04-12 14:12:55 --> Controller Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Language Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Config Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:12:55 --> Loader Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Model Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Model Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:12:55 --> Model Class Initialized
DEBUG - 2013-04-12 14:12:55 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:12:55 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 14:12:55 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:12:55 --> Final output sent to browser
DEBUG - 2013-04-12 14:12:55 --> Total execution time: 0.0325
DEBUG - 2013-04-12 14:12:56 --> Config Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:12:56 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:12:56 --> URI Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Router Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Output Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Security Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Input Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:12:56 --> Language Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Loader Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:12:56 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:12:56 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:12:56 --> Session Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:12:56 --> Session routines successfully run
DEBUG - 2013-04-12 14:12:56 --> Controller Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Language Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Config Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:12:56 --> Loader Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Model Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Model Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Model Class Initialized
DEBUG - 2013-04-12 14:12:56 --> Final output sent to browser
DEBUG - 2013-04-12 14:12:56 --> Total execution time: 0.0232
DEBUG - 2013-04-12 14:13:00 --> Config Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:13:00 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:13:00 --> URI Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Router Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Output Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Security Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Input Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:13:00 --> Language Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Loader Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:13:00 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:13:00 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:13:00 --> Session Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:13:00 --> Session routines successfully run
DEBUG - 2013-04-12 14:13:00 --> Controller Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Language Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Config Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:13:00 --> Loader Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:00 --> Final output sent to browser
DEBUG - 2013-04-12 14:13:00 --> Total execution time: 0.0253
DEBUG - 2013-04-12 14:13:03 --> Config Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:13:03 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:13:03 --> URI Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Router Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Output Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Security Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Input Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:13:03 --> Language Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Loader Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:13:03 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:13:03 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:13:03 --> Session Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:13:03 --> Session routines successfully run
DEBUG - 2013-04-12 14:13:03 --> Controller Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Language Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Config Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:13:03 --> Loader Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:13:03 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:03 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:13:03 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 14:13:03 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:13:03 --> Final output sent to browser
DEBUG - 2013-04-12 14:13:03 --> Total execution time: 0.0276
DEBUG - 2013-04-12 14:13:16 --> Config Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:13:16 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:13:16 --> URI Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Router Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Output Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Security Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Input Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:13:16 --> Language Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Loader Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:13:16 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:13:16 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:13:16 --> Session Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:13:16 --> Session routines successfully run
DEBUG - 2013-04-12 14:13:16 --> Controller Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Language Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Config Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:13:16 --> Loader Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:13:16 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:16 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:13:16 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 14:13:16 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:13:16 --> Final output sent to browser
DEBUG - 2013-04-12 14:13:16 --> Total execution time: 0.0253
DEBUG - 2013-04-12 14:13:18 --> Config Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:13:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:13:18 --> URI Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Router Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Output Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Security Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Input Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:13:18 --> Language Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Loader Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:13:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:13:18 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:13:18 --> Session Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:13:18 --> Session routines successfully run
DEBUG - 2013-04-12 14:13:18 --> Controller Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Language Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Config Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:13:18 --> Loader Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:18 --> Final output sent to browser
DEBUG - 2013-04-12 14:13:18 --> Total execution time: 0.0237
DEBUG - 2013-04-12 14:13:22 --> Config Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:13:22 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:13:22 --> URI Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Router Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Output Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Security Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Input Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:13:22 --> Language Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Loader Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:13:22 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:13:22 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:13:22 --> Session Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:13:22 --> Session routines successfully run
DEBUG - 2013-04-12 14:13:22 --> Controller Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Language Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Config Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:13:22 --> Loader Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:22 --> Final output sent to browser
DEBUG - 2013-04-12 14:13:22 --> Total execution time: 0.0228
DEBUG - 2013-04-12 14:13:37 --> Config Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:13:37 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:13:37 --> URI Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Router Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Output Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Security Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Input Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:13:37 --> Language Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Loader Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:13:37 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:13:37 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:13:37 --> Session Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:13:37 --> Session routines successfully run
DEBUG - 2013-04-12 14:13:37 --> Controller Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Language Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Config Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:13:37 --> Loader Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:37 --> Final output sent to browser
DEBUG - 2013-04-12 14:13:37 --> Total execution time: 0.0348
DEBUG - 2013-04-12 14:13:41 --> Config Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:13:41 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:13:41 --> URI Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Router Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Output Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Security Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Input Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:13:41 --> Language Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Loader Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:13:41 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:13:41 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:13:41 --> Session Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:13:41 --> Session routines successfully run
DEBUG - 2013-04-12 14:13:41 --> Controller Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Language Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Config Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:13:41 --> Loader Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:13:41 --> Model Class Initialized
DEBUG - 2013-04-12 14:13:41 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:13:41 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 14:13:41 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:13:41 --> Final output sent to browser
DEBUG - 2013-04-12 14:13:41 --> Total execution time: 0.0262
DEBUG - 2013-04-12 14:34:00 --> Config Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:34:00 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:34:00 --> URI Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Router Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Output Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Security Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Input Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:34:00 --> Language Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Loader Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:34:00 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:34:00 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:34:00 --> Session Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:34:00 --> Session routines successfully run
DEBUG - 2013-04-12 14:34:00 --> Controller Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Language Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Config Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:34:00 --> Loader Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Model Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Model Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Model Class Initialized
DEBUG - 2013-04-12 14:34:00 --> Final output sent to browser
DEBUG - 2013-04-12 14:34:00 --> Total execution time: 0.0242
DEBUG - 2013-04-12 14:34:03 --> Config Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:34:03 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:34:03 --> URI Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Router Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Output Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Security Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Input Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:34:03 --> Language Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Loader Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:34:03 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:34:03 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:34:03 --> Session Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:34:03 --> Session routines successfully run
DEBUG - 2013-04-12 14:34:03 --> Controller Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Language Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Config Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:34:03 --> Loader Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Model Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Model Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:34:03 --> Model Class Initialized
DEBUG - 2013-04-12 14:34:03 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:34:03 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 14:34:03 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:34:03 --> Final output sent to browser
DEBUG - 2013-04-12 14:34:03 --> Total execution time: 0.0241
DEBUG - 2013-04-12 14:34:12 --> Config Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:34:12 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:34:12 --> URI Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Router Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Output Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Security Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Input Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:34:12 --> Language Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Loader Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:34:12 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:34:12 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:34:12 --> Session Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:34:12 --> Session routines successfully run
DEBUG - 2013-04-12 14:34:12 --> Controller Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Language Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Config Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:34:12 --> Loader Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Model Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Model Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Model Class Initialized
DEBUG - 2013-04-12 14:34:12 --> Final output sent to browser
DEBUG - 2013-04-12 14:34:12 --> Total execution time: 0.0231
DEBUG - 2013-04-12 14:35:05 --> Config Class Initialized
DEBUG - 2013-04-12 14:35:05 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:35:05 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:35:05 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:35:05 --> URI Class Initialized
DEBUG - 2013-04-12 14:35:05 --> Router Class Initialized
DEBUG - 2013-04-12 14:35:05 --> Output Class Initialized
DEBUG - 2013-04-12 14:35:05 --> Security Class Initialized
DEBUG - 2013-04-12 14:35:05 --> Input Class Initialized
DEBUG - 2013-04-12 14:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:35:05 --> Language Class Initialized
DEBUG - 2013-04-12 14:35:05 --> Loader Class Initialized
DEBUG - 2013-04-12 14:35:05 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:35:05 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:35:05 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:35:05 --> Session Class Initialized
DEBUG - 2013-04-12 14:35:05 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:35:05 --> Session routines successfully run
DEBUG - 2013-04-12 14:35:05 --> Controller Class Initialized
DEBUG - 2013-04-12 14:35:05 --> Language Class Initialized
DEBUG - 2013-04-12 14:35:05 --> Config Class Initialized
DEBUG - 2013-04-12 14:35:05 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:35:05 --> Loader Class Initialized
DEBUG - 2013-04-12 14:35:05 --> Model Class Initialized
DEBUG - 2013-04-12 14:35:05 --> Model Class Initialized
DEBUG - 2013-04-12 14:35:05 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:35:05 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:35:05 --> File loaded: ../application/admin/modules/configuracao/views/metas-analytics.php
DEBUG - 2013-04-12 14:35:05 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:35:05 --> Final output sent to browser
DEBUG - 2013-04-12 14:35:05 --> Total execution time: 0.0352
DEBUG - 2013-04-12 14:38:36 --> Config Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:38:36 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:38:36 --> URI Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Router Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Output Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Security Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Input Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:38:36 --> Language Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Loader Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:38:36 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:38:36 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:38:36 --> Session Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:38:36 --> Session routines successfully run
DEBUG - 2013-04-12 14:38:36 --> Controller Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Language Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Config Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:38:36 --> Loader Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Model Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Model Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:38:36 --> Model Class Initialized
DEBUG - 2013-04-12 14:38:36 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:38:36 --> File loaded: ../application/admin/modules/configuracao/views/metas-analytics.php
DEBUG - 2013-04-12 14:38:36 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:38:36 --> Final output sent to browser
DEBUG - 2013-04-12 14:38:36 --> Total execution time: 0.0275
DEBUG - 2013-04-12 14:39:04 --> Config Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:39:04 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:39:04 --> URI Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Router Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Output Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Security Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Input Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:39:04 --> Language Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Loader Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:39:04 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:39:04 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:39:04 --> Session Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:39:04 --> Session routines successfully run
DEBUG - 2013-04-12 14:39:04 --> Controller Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Language Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Config Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:39:04 --> Loader Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:39:04 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:04 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:39:04 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 14:39:04 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:39:04 --> Final output sent to browser
DEBUG - 2013-04-12 14:39:04 --> Total execution time: 0.0253
DEBUG - 2013-04-12 14:39:07 --> Config Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:39:07 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:39:07 --> URI Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Router Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Output Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Security Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Input Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:39:07 --> Language Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Loader Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:39:07 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:39:07 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:39:07 --> Session Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:39:07 --> Session routines successfully run
DEBUG - 2013-04-12 14:39:07 --> Controller Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Language Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Config Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:39:07 --> Loader Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:39:07 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:07 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:39:07 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 14:39:07 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:39:07 --> Final output sent to browser
DEBUG - 2013-04-12 14:39:07 --> Total execution time: 0.0263
DEBUG - 2013-04-12 14:39:10 --> Config Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:39:10 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:39:10 --> URI Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Router Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Output Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Security Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Input Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:39:10 --> Language Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Loader Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:39:10 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:39:10 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:39:10 --> Session Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:39:10 --> Session routines successfully run
DEBUG - 2013-04-12 14:39:10 --> Controller Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Language Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Config Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:39:10 --> Loader Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:39:10 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:10 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:39:10 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 14:39:10 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:39:10 --> Final output sent to browser
DEBUG - 2013-04-12 14:39:10 --> Total execution time: 0.0263
DEBUG - 2013-04-12 14:39:46 --> Config Class Initialized
DEBUG - 2013-04-12 14:39:46 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:39:46 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:39:46 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:39:46 --> URI Class Initialized
DEBUG - 2013-04-12 14:39:46 --> Router Class Initialized
DEBUG - 2013-04-12 14:39:46 --> Output Class Initialized
DEBUG - 2013-04-12 14:39:46 --> Security Class Initialized
DEBUG - 2013-04-12 14:39:46 --> Input Class Initialized
DEBUG - 2013-04-12 14:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:39:46 --> Language Class Initialized
DEBUG - 2013-04-12 14:39:46 --> Loader Class Initialized
DEBUG - 2013-04-12 14:39:46 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:39:46 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:39:46 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:39:46 --> Session Class Initialized
DEBUG - 2013-04-12 14:39:46 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:39:46 --> Session routines successfully run
DEBUG - 2013-04-12 14:39:46 --> Controller Class Initialized
DEBUG - 2013-04-12 14:39:46 --> Language Class Initialized
DEBUG - 2013-04-12 14:39:46 --> Config Class Initialized
DEBUG - 2013-04-12 14:39:46 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:39:46 --> Loader Class Initialized
DEBUG - 2013-04-12 14:39:46 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:46 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:46 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:39:46 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:39:46 --> File loaded: ../application/admin/modules/configuracao/views/manutencao.php
DEBUG - 2013-04-12 14:39:46 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:39:46 --> Final output sent to browser
DEBUG - 2013-04-12 14:39:46 --> Total execution time: 0.0264
DEBUG - 2013-04-12 14:39:54 --> Config Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:39:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:39:54 --> URI Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Router Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Output Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Security Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Input Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:39:54 --> Language Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Loader Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:39:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:39:54 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:39:54 --> Session Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:39:54 --> Session routines successfully run
DEBUG - 2013-04-12 14:39:54 --> Controller Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Language Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Config Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:39:54 --> Loader Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:39:54 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:54 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:39:54 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 14:39:54 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:39:54 --> Final output sent to browser
DEBUG - 2013-04-12 14:39:54 --> Total execution time: 0.0253
DEBUG - 2013-04-12 14:39:55 --> Config Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:39:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:39:55 --> URI Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Router Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Output Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Security Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Input Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:39:55 --> Language Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Loader Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:39:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:39:55 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:39:55 --> Session Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:39:55 --> Session routines successfully run
DEBUG - 2013-04-12 14:39:55 --> Controller Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Language Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Config Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:39:55 --> Loader Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:39:55 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:55 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:39:55 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 14:39:55 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:39:55 --> Final output sent to browser
DEBUG - 2013-04-12 14:39:55 --> Total execution time: 0.0268
DEBUG - 2013-04-12 14:39:59 --> Config Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:39:59 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:39:59 --> URI Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Router Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Output Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Security Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Input Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:39:59 --> Language Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Loader Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:39:59 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:39:59 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:39:59 --> Session Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:39:59 --> Session routines successfully run
DEBUG - 2013-04-12 14:39:59 --> Controller Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Language Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Config Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:39:59 --> Loader Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:39:59 --> Model Class Initialized
DEBUG - 2013-04-12 14:39:59 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:39:59 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 14:39:59 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:39:59 --> Final output sent to browser
DEBUG - 2013-04-12 14:39:59 --> Total execution time: 0.0265
DEBUG - 2013-04-12 14:40:24 --> Config Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:40:24 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:40:24 --> URI Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Router Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Output Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Security Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Input Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:40:24 --> Language Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Loader Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:40:24 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:40:24 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:40:24 --> Session Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:40:24 --> Session routines successfully run
DEBUG - 2013-04-12 14:40:24 --> Controller Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Language Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Config Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:40:24 --> Loader Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Model Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Model Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:40:24 --> Model Class Initialized
DEBUG - 2013-04-12 14:40:24 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:40:24 --> File loaded: ../application/admin/modules/configuracao/views/metas-analytics.php
DEBUG - 2013-04-12 14:40:24 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:40:24 --> Final output sent to browser
DEBUG - 2013-04-12 14:40:24 --> Total execution time: 0.0326
DEBUG - 2013-04-12 14:43:28 --> Config Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:43:28 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:43:28 --> URI Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Router Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Output Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Security Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Input Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:43:28 --> Language Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Loader Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:43:28 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:43:28 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:43:28 --> Session Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:43:28 --> Session routines successfully run
DEBUG - 2013-04-12 14:43:28 --> Controller Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Language Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Config Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:43:28 --> Loader Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Model Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Model Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:43:28 --> Model Class Initialized
DEBUG - 2013-04-12 14:43:28 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:43:28 --> File loaded: ../application/admin/modules/configuracao/views/metas-analytics.php
DEBUG - 2013-04-12 14:43:28 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:43:28 --> Final output sent to browser
DEBUG - 2013-04-12 14:43:28 --> Total execution time: 0.0265
DEBUG - 2013-04-12 14:43:45 --> Config Class Initialized
DEBUG - 2013-04-12 14:43:45 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:43:45 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:43:45 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:43:45 --> URI Class Initialized
DEBUG - 2013-04-12 14:43:45 --> Router Class Initialized
DEBUG - 2013-04-12 14:43:45 --> Output Class Initialized
DEBUG - 2013-04-12 14:43:45 --> Security Class Initialized
DEBUG - 2013-04-12 14:43:45 --> Input Class Initialized
DEBUG - 2013-04-12 14:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:43:45 --> Language Class Initialized
DEBUG - 2013-04-12 14:43:45 --> Loader Class Initialized
DEBUG - 2013-04-12 14:43:45 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:43:45 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:43:45 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:43:45 --> Session Class Initialized
DEBUG - 2013-04-12 14:43:45 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:43:45 --> Session routines successfully run
DEBUG - 2013-04-12 14:43:45 --> Controller Class Initialized
DEBUG - 2013-04-12 14:43:45 --> Language Class Initialized
DEBUG - 2013-04-12 14:43:45 --> Config Class Initialized
DEBUG - 2013-04-12 14:43:45 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:43:45 --> Loader Class Initialized
DEBUG - 2013-04-12 14:43:45 --> Model Class Initialized
DEBUG - 2013-04-12 14:43:45 --> Model Class Initialized
DEBUG - 2013-04-12 14:43:45 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:43:45 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:43:45 --> File loaded: ../application/admin/modules/configuracao/views/manutencao.php
DEBUG - 2013-04-12 14:43:45 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:43:45 --> Final output sent to browser
DEBUG - 2013-04-12 14:43:45 --> Total execution time: 0.0345
DEBUG - 2013-04-12 14:43:52 --> Config Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:43:52 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:43:52 --> URI Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Router Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Output Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Security Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Input Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:43:52 --> Language Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Loader Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:43:52 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:43:52 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:43:52 --> Session Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:43:52 --> Session routines successfully run
DEBUG - 2013-04-12 14:43:52 --> Controller Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Language Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Config Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:43:52 --> Loader Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Model Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Model Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:43:52 --> Model Class Initialized
DEBUG - 2013-04-12 14:43:52 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:43:52 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 14:43:52 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:43:52 --> Final output sent to browser
DEBUG - 2013-04-12 14:43:52 --> Total execution time: 0.0348
DEBUG - 2013-04-12 14:43:54 --> Config Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:43:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:43:54 --> URI Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Router Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Output Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Security Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Input Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:43:54 --> Language Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Loader Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:43:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:43:54 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:43:54 --> Session Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:43:54 --> Session routines successfully run
DEBUG - 2013-04-12 14:43:54 --> Controller Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Language Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Config Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:43:54 --> Loader Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Model Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Model Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:43:54 --> Model Class Initialized
DEBUG - 2013-04-12 14:43:54 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:43:54 --> File loaded: ../application/admin/modules/configuracao/views/metas-analytics.php
DEBUG - 2013-04-12 14:43:54 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:43:54 --> Final output sent to browser
DEBUG - 2013-04-12 14:43:54 --> Total execution time: 0.0286
DEBUG - 2013-04-12 14:44:27 --> Config Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:44:27 --> URI Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Router Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Output Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Security Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Input Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:44:27 --> Language Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Loader Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:44:27 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:44:27 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:44:27 --> Session Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:44:27 --> Session routines successfully run
DEBUG - 2013-04-12 14:44:27 --> Controller Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Language Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Config Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:44:27 --> Loader Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:44:27 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:27 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:44:27 --> File loaded: ../application/admin/modules/configuracao/views/metas-analytics.php
DEBUG - 2013-04-12 14:44:27 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:44:27 --> Final output sent to browser
DEBUG - 2013-04-12 14:44:27 --> Total execution time: 0.0335
DEBUG - 2013-04-12 14:44:29 --> Config Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:44:29 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:44:29 --> URI Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Router Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Output Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Security Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Input Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:44:29 --> Language Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Loader Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:44:29 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:44:29 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:44:29 --> Session Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:44:29 --> Session routines successfully run
DEBUG - 2013-04-12 14:44:29 --> Controller Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Language Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Config Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:44:29 --> Loader Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:29 --> Final output sent to browser
DEBUG - 2013-04-12 14:44:29 --> Total execution time: 0.0251
DEBUG - 2013-04-12 14:44:33 --> Config Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:44:33 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:44:33 --> URI Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Router Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Output Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Security Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Input Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:44:33 --> Language Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Loader Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:44:33 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:44:33 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:44:33 --> Session Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:44:33 --> Session routines successfully run
DEBUG - 2013-04-12 14:44:33 --> Controller Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Language Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Config Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:44:33 --> Loader Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:44:33 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:33 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:44:33 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 14:44:33 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:44:33 --> Final output sent to browser
DEBUG - 2013-04-12 14:44:33 --> Total execution time: 0.0234
DEBUG - 2013-04-12 14:44:34 --> Config Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:44:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:44:34 --> URI Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Router Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Output Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Security Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Input Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:44:34 --> Language Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Loader Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:44:34 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:44:34 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:44:34 --> Session Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:44:34 --> Session routines successfully run
DEBUG - 2013-04-12 14:44:34 --> Controller Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Language Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Config Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:44:34 --> Loader Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:34 --> Final output sent to browser
DEBUG - 2013-04-12 14:44:34 --> Total execution time: 0.0259
DEBUG - 2013-04-12 14:44:36 --> Config Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:44:36 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:44:36 --> URI Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Router Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Output Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Security Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Input Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:44:36 --> Language Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Loader Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:44:36 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:44:36 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:44:36 --> Session Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:44:36 --> Session routines successfully run
DEBUG - 2013-04-12 14:44:36 --> Controller Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Language Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Config Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:44:36 --> Loader Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:44:36 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:36 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:44:36 --> File loaded: ../application/admin/modules/configuracao/views/metas-analytics.php
DEBUG - 2013-04-12 14:44:36 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:44:36 --> Final output sent to browser
DEBUG - 2013-04-12 14:44:36 --> Total execution time: 0.0248
DEBUG - 2013-04-12 14:44:37 --> Config Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:44:37 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:44:37 --> URI Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Router Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Output Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Security Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Input Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:44:37 --> Language Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Loader Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:44:37 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:44:37 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:44:37 --> Session Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:44:37 --> Session routines successfully run
DEBUG - 2013-04-12 14:44:37 --> Controller Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Language Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Config Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:44:37 --> Loader Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Model Class Initialized
DEBUG - 2013-04-12 14:44:37 --> Final output sent to browser
DEBUG - 2013-04-12 14:44:37 --> Total execution time: 0.0249
DEBUG - 2013-04-12 14:47:06 --> Config Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:47:06 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:47:06 --> URI Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Router Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Output Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Security Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Input Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:47:06 --> Language Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Loader Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:47:06 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:47:06 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:47:06 --> Session Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:47:06 --> Session routines successfully run
DEBUG - 2013-04-12 14:47:06 --> Controller Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Language Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Config Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:47:06 --> Loader Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:47:06 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:06 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:47:06 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 14:47:06 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:47:06 --> Final output sent to browser
DEBUG - 2013-04-12 14:47:06 --> Total execution time: 0.0317
DEBUG - 2013-04-12 14:47:07 --> Config Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:47:07 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:47:07 --> URI Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Router Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Output Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Security Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Input Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:47:07 --> Language Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Loader Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:47:07 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:47:07 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:47:07 --> Session Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:47:07 --> Session routines successfully run
DEBUG - 2013-04-12 14:47:07 --> Controller Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Language Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Config Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:47:07 --> Loader Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:47:07 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:07 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:47:07 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 14:47:07 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:47:07 --> Final output sent to browser
DEBUG - 2013-04-12 14:47:07 --> Total execution time: 0.0258
DEBUG - 2013-04-12 14:47:08 --> Config Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:47:08 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:47:08 --> URI Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Router Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Output Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Security Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Input Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:47:08 --> Language Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Loader Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:47:08 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:47:08 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:47:08 --> Session Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:47:08 --> Session routines successfully run
DEBUG - 2013-04-12 14:47:08 --> Controller Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Language Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Config Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:47:08 --> Loader Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:47:08 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:08 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:47:08 --> File loaded: ../application/admin/modules/configuracao/views/metas-analytics.php
DEBUG - 2013-04-12 14:47:08 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:47:08 --> Final output sent to browser
DEBUG - 2013-04-12 14:47:08 --> Total execution time: 0.0254
DEBUG - 2013-04-12 14:47:17 --> Config Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:47:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:47:17 --> URI Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Router Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Output Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Security Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Input Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:47:17 --> Language Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Loader Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:47:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:47:17 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:47:17 --> Session Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:47:17 --> Session routines successfully run
DEBUG - 2013-04-12 14:47:17 --> Controller Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Language Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Config Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:47:17 --> Loader Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:17 --> Final output sent to browser
DEBUG - 2013-04-12 14:47:17 --> Total execution time: 0.0316
DEBUG - 2013-04-12 14:47:20 --> Config Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:47:20 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:47:20 --> URI Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Router Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Output Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Security Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Input Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:47:20 --> Language Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Loader Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:47:20 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:47:20 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:47:20 --> Session Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:47:20 --> Session routines successfully run
DEBUG - 2013-04-12 14:47:20 --> Controller Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Language Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Config Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:47:20 --> Loader Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:20 --> Final output sent to browser
DEBUG - 2013-04-12 14:47:20 --> Total execution time: 0.0265
DEBUG - 2013-04-12 14:47:23 --> Config Class Initialized
DEBUG - 2013-04-12 14:47:23 --> Hooks Class Initialized
DEBUG - 2013-04-12 14:47:23 --> Utf8 Class Initialized
DEBUG - 2013-04-12 14:47:23 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 14:47:23 --> URI Class Initialized
DEBUG - 2013-04-12 14:47:23 --> Router Class Initialized
DEBUG - 2013-04-12 14:47:23 --> Output Class Initialized
DEBUG - 2013-04-12 14:47:23 --> Security Class Initialized
DEBUG - 2013-04-12 14:47:23 --> Input Class Initialized
DEBUG - 2013-04-12 14:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 14:47:23 --> Language Class Initialized
DEBUG - 2013-04-12 14:47:23 --> Loader Class Initialized
DEBUG - 2013-04-12 14:47:23 --> Helper loaded: url_helper
DEBUG - 2013-04-12 14:47:23 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 14:47:23 --> Helper loaded: text_helper
DEBUG - 2013-04-12 14:47:23 --> Session Class Initialized
DEBUG - 2013-04-12 14:47:23 --> Helper loaded: string_helper
DEBUG - 2013-04-12 14:47:23 --> Session routines successfully run
DEBUG - 2013-04-12 14:47:23 --> Controller Class Initialized
DEBUG - 2013-04-12 14:47:23 --> Language Class Initialized
DEBUG - 2013-04-12 14:47:23 --> Config Class Initialized
DEBUG - 2013-04-12 14:47:23 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 14:47:23 --> Loader Class Initialized
DEBUG - 2013-04-12 14:47:23 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:23 --> Model Class Initialized
DEBUG - 2013-04-12 14:47:23 --> Database Driver Class Initialized
DEBUG - 2013-04-12 14:47:23 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 14:47:23 --> File loaded: ../application/admin/modules/configuracao/views/manutencao.php
DEBUG - 2013-04-12 14:47:23 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 14:47:23 --> Final output sent to browser
DEBUG - 2013-04-12 14:47:23 --> Total execution time: 0.0224
DEBUG - 2013-04-12 15:03:52 --> Config Class Initialized
DEBUG - 2013-04-12 15:03:52 --> Hooks Class Initialized
DEBUG - 2013-04-12 15:03:52 --> Utf8 Class Initialized
DEBUG - 2013-04-12 15:03:52 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 15:03:52 --> URI Class Initialized
DEBUG - 2013-04-12 15:03:52 --> Router Class Initialized
DEBUG - 2013-04-12 15:03:52 --> Output Class Initialized
DEBUG - 2013-04-12 15:03:52 --> Security Class Initialized
DEBUG - 2013-04-12 15:03:52 --> Input Class Initialized
DEBUG - 2013-04-12 15:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 15:03:52 --> Language Class Initialized
DEBUG - 2013-04-12 15:03:52 --> Loader Class Initialized
DEBUG - 2013-04-12 15:03:52 --> Helper loaded: url_helper
DEBUG - 2013-04-12 15:03:52 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 15:03:52 --> Helper loaded: text_helper
DEBUG - 2013-04-12 15:03:52 --> Session Class Initialized
DEBUG - 2013-04-12 15:03:52 --> Helper loaded: string_helper
DEBUG - 2013-04-12 15:03:52 --> Session routines successfully run
DEBUG - 2013-04-12 15:03:52 --> Controller Class Initialized
DEBUG - 2013-04-12 15:03:52 --> Language Class Initialized
DEBUG - 2013-04-12 15:03:52 --> Config Class Initialized
DEBUG - 2013-04-12 15:03:52 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 15:03:52 --> Loader Class Initialized
DEBUG - 2013-04-12 15:03:52 --> Model Class Initialized
DEBUG - 2013-04-12 15:03:52 --> Model Class Initialized
DEBUG - 2013-04-12 15:03:52 --> Database Driver Class Initialized
DEBUG - 2013-04-12 15:03:52 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 15:03:52 --> File loaded: ../application/admin/modules/configuracao/views/manutencao.php
DEBUG - 2013-04-12 15:03:52 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 15:03:52 --> Final output sent to browser
DEBUG - 2013-04-12 15:03:52 --> Total execution time: 0.0242
DEBUG - 2013-04-12 15:03:54 --> Config Class Initialized
DEBUG - 2013-04-12 15:03:54 --> Hooks Class Initialized
DEBUG - 2013-04-12 15:03:54 --> Utf8 Class Initialized
DEBUG - 2013-04-12 15:03:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 15:03:54 --> URI Class Initialized
DEBUG - 2013-04-12 15:03:54 --> Router Class Initialized
DEBUG - 2013-04-12 15:03:54 --> Output Class Initialized
DEBUG - 2013-04-12 15:03:54 --> Security Class Initialized
DEBUG - 2013-04-12 15:03:54 --> Input Class Initialized
DEBUG - 2013-04-12 15:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 15:03:54 --> Language Class Initialized
DEBUG - 2013-04-12 15:03:54 --> Loader Class Initialized
DEBUG - 2013-04-12 15:03:54 --> Helper loaded: url_helper
DEBUG - 2013-04-12 15:03:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 15:03:54 --> Helper loaded: text_helper
DEBUG - 2013-04-12 15:03:54 --> Session Class Initialized
DEBUG - 2013-04-12 15:03:54 --> Helper loaded: string_helper
DEBUG - 2013-04-12 15:03:54 --> Session routines successfully run
DEBUG - 2013-04-12 15:03:54 --> Controller Class Initialized
DEBUG - 2013-04-12 15:03:54 --> Language Class Initialized
DEBUG - 2013-04-12 15:03:54 --> Config Class Initialized
DEBUG - 2013-04-12 15:03:54 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 15:03:54 --> Loader Class Initialized
DEBUG - 2013-04-12 15:03:54 --> Model Class Initialized
DEBUG - 2013-04-12 15:03:54 --> Model Class Initialized
DEBUG - 2013-04-12 15:03:54 --> Database Driver Class Initialized
ERROR - 2013-04-12 15:03:54 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 15:03:55 --> Config Class Initialized
DEBUG - 2013-04-12 15:03:55 --> Hooks Class Initialized
DEBUG - 2013-04-12 15:03:55 --> Utf8 Class Initialized
DEBUG - 2013-04-12 15:03:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 15:03:55 --> URI Class Initialized
DEBUG - 2013-04-12 15:03:55 --> Router Class Initialized
DEBUG - 2013-04-12 15:03:55 --> Output Class Initialized
DEBUG - 2013-04-12 15:03:55 --> Security Class Initialized
DEBUG - 2013-04-12 15:03:55 --> Input Class Initialized
DEBUG - 2013-04-12 15:03:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 15:03:55 --> Language Class Initialized
DEBUG - 2013-04-12 15:03:55 --> Loader Class Initialized
DEBUG - 2013-04-12 15:03:55 --> Helper loaded: url_helper
DEBUG - 2013-04-12 15:03:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 15:03:55 --> Helper loaded: text_helper
DEBUG - 2013-04-12 15:03:55 --> Session Class Initialized
DEBUG - 2013-04-12 15:03:55 --> Helper loaded: string_helper
DEBUG - 2013-04-12 15:03:55 --> Session routines successfully run
DEBUG - 2013-04-12 15:03:55 --> Controller Class Initialized
DEBUG - 2013-04-12 15:03:55 --> Language Class Initialized
DEBUG - 2013-04-12 15:03:55 --> Config Class Initialized
DEBUG - 2013-04-12 15:03:55 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 15:03:55 --> Loader Class Initialized
DEBUG - 2013-04-12 15:03:55 --> Model Class Initialized
DEBUG - 2013-04-12 15:03:55 --> Model Class Initialized
DEBUG - 2013-04-12 15:03:55 --> Database Driver Class Initialized
ERROR - 2013-04-12 15:03:55 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 15:04:12 --> Config Class Initialized
DEBUG - 2013-04-12 15:04:12 --> Hooks Class Initialized
DEBUG - 2013-04-12 15:04:12 --> Utf8 Class Initialized
DEBUG - 2013-04-12 15:04:12 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 15:04:12 --> URI Class Initialized
DEBUG - 2013-04-12 15:04:12 --> Router Class Initialized
DEBUG - 2013-04-12 15:04:12 --> Output Class Initialized
DEBUG - 2013-04-12 15:04:12 --> Security Class Initialized
DEBUG - 2013-04-12 15:04:12 --> Input Class Initialized
DEBUG - 2013-04-12 15:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 15:04:12 --> Language Class Initialized
DEBUG - 2013-04-12 15:04:12 --> Loader Class Initialized
DEBUG - 2013-04-12 15:04:12 --> Helper loaded: url_helper
DEBUG - 2013-04-12 15:04:12 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 15:04:12 --> Helper loaded: text_helper
DEBUG - 2013-04-12 15:04:12 --> Session Class Initialized
DEBUG - 2013-04-12 15:04:12 --> Helper loaded: string_helper
DEBUG - 2013-04-12 15:04:12 --> Session routines successfully run
DEBUG - 2013-04-12 15:04:12 --> Controller Class Initialized
DEBUG - 2013-04-12 15:04:12 --> Language Class Initialized
DEBUG - 2013-04-12 15:04:12 --> Config Class Initialized
DEBUG - 2013-04-12 15:04:12 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 15:04:12 --> Loader Class Initialized
DEBUG - 2013-04-12 15:04:12 --> Model Class Initialized
DEBUG - 2013-04-12 15:04:12 --> Model Class Initialized
DEBUG - 2013-04-12 15:04:12 --> Database Driver Class Initialized
ERROR - 2013-04-12 15:04:12 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 15:06:23 --> Config Class Initialized
DEBUG - 2013-04-12 15:06:23 --> Hooks Class Initialized
DEBUG - 2013-04-12 15:06:23 --> Utf8 Class Initialized
DEBUG - 2013-04-12 15:06:23 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 15:06:23 --> URI Class Initialized
DEBUG - 2013-04-12 15:06:23 --> Router Class Initialized
DEBUG - 2013-04-12 15:06:23 --> Output Class Initialized
DEBUG - 2013-04-12 15:06:23 --> Security Class Initialized
DEBUG - 2013-04-12 15:06:23 --> Input Class Initialized
DEBUG - 2013-04-12 15:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 15:06:23 --> Language Class Initialized
DEBUG - 2013-04-12 15:06:23 --> Loader Class Initialized
DEBUG - 2013-04-12 15:06:23 --> Helper loaded: url_helper
DEBUG - 2013-04-12 15:06:23 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 15:06:23 --> Helper loaded: text_helper
DEBUG - 2013-04-12 15:06:23 --> Session Class Initialized
DEBUG - 2013-04-12 15:06:23 --> Helper loaded: string_helper
DEBUG - 2013-04-12 15:06:23 --> Session routines successfully run
DEBUG - 2013-04-12 15:06:23 --> Controller Class Initialized
DEBUG - 2013-04-12 15:06:23 --> Language Class Initialized
DEBUG - 2013-04-12 15:06:23 --> Config Class Initialized
DEBUG - 2013-04-12 15:06:23 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 15:06:23 --> Loader Class Initialized
DEBUG - 2013-04-12 15:06:23 --> Model Class Initialized
DEBUG - 2013-04-12 15:06:23 --> Model Class Initialized
DEBUG - 2013-04-12 15:06:23 --> Database Driver Class Initialized
ERROR - 2013-04-12 15:06:23 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 15:08:31 --> Config Class Initialized
DEBUG - 2013-04-12 15:08:31 --> Hooks Class Initialized
DEBUG - 2013-04-12 15:08:31 --> Utf8 Class Initialized
DEBUG - 2013-04-12 15:08:31 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 15:08:31 --> URI Class Initialized
DEBUG - 2013-04-12 15:08:31 --> Router Class Initialized
DEBUG - 2013-04-12 15:08:31 --> Output Class Initialized
DEBUG - 2013-04-12 15:08:31 --> Security Class Initialized
DEBUG - 2013-04-12 15:08:31 --> Input Class Initialized
DEBUG - 2013-04-12 15:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 15:08:31 --> Language Class Initialized
DEBUG - 2013-04-12 15:08:31 --> Loader Class Initialized
DEBUG - 2013-04-12 15:08:31 --> Helper loaded: url_helper
DEBUG - 2013-04-12 15:08:31 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 15:08:31 --> Helper loaded: text_helper
DEBUG - 2013-04-12 15:08:31 --> Session Class Initialized
DEBUG - 2013-04-12 15:08:31 --> Helper loaded: string_helper
DEBUG - 2013-04-12 15:08:31 --> Session routines successfully run
DEBUG - 2013-04-12 15:08:31 --> Controller Class Initialized
DEBUG - 2013-04-12 15:08:31 --> Language Class Initialized
DEBUG - 2013-04-12 15:08:31 --> Config Class Initialized
DEBUG - 2013-04-12 15:08:31 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 15:08:31 --> Loader Class Initialized
DEBUG - 2013-04-12 15:08:31 --> Model Class Initialized
DEBUG - 2013-04-12 15:08:31 --> Model Class Initialized
DEBUG - 2013-04-12 15:08:31 --> Database Driver Class Initialized
ERROR - 2013-04-12 15:08:31 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 15:08:46 --> Config Class Initialized
DEBUG - 2013-04-12 15:08:46 --> Hooks Class Initialized
DEBUG - 2013-04-12 15:08:46 --> Utf8 Class Initialized
DEBUG - 2013-04-12 15:08:46 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 15:08:46 --> URI Class Initialized
DEBUG - 2013-04-12 15:08:46 --> Router Class Initialized
DEBUG - 2013-04-12 15:08:46 --> Output Class Initialized
DEBUG - 2013-04-12 15:08:46 --> Security Class Initialized
DEBUG - 2013-04-12 15:08:46 --> Input Class Initialized
DEBUG - 2013-04-12 15:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 15:08:46 --> Language Class Initialized
DEBUG - 2013-04-12 15:08:46 --> Loader Class Initialized
DEBUG - 2013-04-12 15:08:46 --> Helper loaded: url_helper
DEBUG - 2013-04-12 15:08:46 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 15:08:46 --> Helper loaded: text_helper
DEBUG - 2013-04-12 15:08:46 --> Session Class Initialized
DEBUG - 2013-04-12 15:08:46 --> Helper loaded: string_helper
DEBUG - 2013-04-12 15:08:46 --> Session routines successfully run
DEBUG - 2013-04-12 15:08:46 --> Controller Class Initialized
DEBUG - 2013-04-12 15:08:46 --> Language Class Initialized
DEBUG - 2013-04-12 15:08:46 --> Config Class Initialized
DEBUG - 2013-04-12 15:08:46 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 15:08:46 --> Loader Class Initialized
DEBUG - 2013-04-12 15:08:46 --> Model Class Initialized
DEBUG - 2013-04-12 15:08:46 --> Model Class Initialized
DEBUG - 2013-04-12 15:08:46 --> Database Driver Class Initialized
ERROR - 2013-04-12 15:08:46 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 15:09:03 --> Config Class Initialized
DEBUG - 2013-04-12 15:09:03 --> Hooks Class Initialized
DEBUG - 2013-04-12 15:09:03 --> Utf8 Class Initialized
DEBUG - 2013-04-12 15:09:03 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 15:09:03 --> URI Class Initialized
DEBUG - 2013-04-12 15:09:03 --> Router Class Initialized
DEBUG - 2013-04-12 15:09:03 --> Output Class Initialized
DEBUG - 2013-04-12 15:09:03 --> Security Class Initialized
DEBUG - 2013-04-12 15:09:03 --> Input Class Initialized
DEBUG - 2013-04-12 15:09:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 15:09:03 --> Language Class Initialized
DEBUG - 2013-04-12 15:09:03 --> Loader Class Initialized
DEBUG - 2013-04-12 15:09:03 --> Helper loaded: url_helper
DEBUG - 2013-04-12 15:09:03 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 15:09:03 --> Helper loaded: text_helper
DEBUG - 2013-04-12 15:09:03 --> Session Class Initialized
DEBUG - 2013-04-12 15:09:03 --> Helper loaded: string_helper
DEBUG - 2013-04-12 15:09:03 --> Session routines successfully run
DEBUG - 2013-04-12 15:09:03 --> Controller Class Initialized
DEBUG - 2013-04-12 15:09:03 --> Language Class Initialized
DEBUG - 2013-04-12 15:09:03 --> Config Class Initialized
DEBUG - 2013-04-12 15:09:03 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 15:09:03 --> Loader Class Initialized
DEBUG - 2013-04-12 15:09:03 --> Model Class Initialized
DEBUG - 2013-04-12 15:09:03 --> Model Class Initialized
DEBUG - 2013-04-12 15:09:03 --> Database Driver Class Initialized
ERROR - 2013-04-12 15:09:03 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 15:09:03 --> Model Class Initialized
ERROR - 2013-04-12 15:09:03 --> Severity: Notice  --> Undefined property: CI::$crud /home/w3case/public_html/target-git/application/admin/third_party/MX/Controller.php 57
DEBUG - 2013-04-12 15:09:22 --> Config Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Hooks Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Utf8 Class Initialized
DEBUG - 2013-04-12 15:09:22 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 15:09:22 --> URI Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Router Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Output Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Security Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Input Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 15:09:22 --> Language Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Loader Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Helper loaded: url_helper
DEBUG - 2013-04-12 15:09:22 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 15:09:22 --> Helper loaded: text_helper
DEBUG - 2013-04-12 15:09:22 --> Session Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Helper loaded: string_helper
DEBUG - 2013-04-12 15:09:22 --> Session routines successfully run
DEBUG - 2013-04-12 15:09:22 --> Controller Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Language Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Config Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 15:09:22 --> Loader Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Model Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Model Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Database Driver Class Initialized
ERROR - 2013-04-12 15:09:22 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 15:09:22 --> Model Class Initialized
ERROR - 2013-04-12 15:09:22 --> Severity: Notice  --> Undefined variable: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 171
ERROR - 2013-04-12 15:09:22 --> Severity: Warning  --> include_once(config/config.php): failed to open stream: No such file or directory /home/w3case/public_html/target-git/application/admin/models/manutencao.php 38
ERROR - 2013-04-12 15:09:22 --> Severity: Warning  --> include_once(): Failed opening 'config/config.php' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /home/w3case/public_html/target-git/application/admin/models/manutencao.php 38
DEBUG - 2013-04-12 15:09:22 --> Database Forge Class Initialized
DEBUG - 2013-04-12 15:09:22 --> Database Utility Class Initialized
ERROR - 2013-04-12 15:09:44 --> Severity: Notice  --> Undefined property: CI::$crud /home/w3case/public_html/target-git/application/admin/third_party/MX/Controller.php 57
DEBUG - 2013-04-12 15:15:39 --> Config Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Hooks Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Utf8 Class Initialized
DEBUG - 2013-04-12 15:15:39 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 15:15:39 --> URI Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Router Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Output Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Security Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Input Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 15:15:39 --> Language Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Loader Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Helper loaded: url_helper
DEBUG - 2013-04-12 15:15:39 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 15:15:39 --> Helper loaded: text_helper
DEBUG - 2013-04-12 15:15:39 --> Session Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Helper loaded: string_helper
DEBUG - 2013-04-12 15:15:39 --> Session routines successfully run
DEBUG - 2013-04-12 15:15:39 --> Controller Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Language Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Config Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 15:15:39 --> Loader Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Model Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Model Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Database Driver Class Initialized
ERROR - 2013-04-12 15:15:39 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 15:15:39 --> Model Class Initialized
ERROR - 2013-04-12 15:15:39 --> Severity: Warning  --> include_once(config/config.php): failed to open stream: No such file or directory /home/w3case/public_html/target-git/application/admin/models/manutencao.php 38
ERROR - 2013-04-12 15:15:39 --> Severity: Warning  --> include_once(): Failed opening 'config/config.php' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /home/w3case/public_html/target-git/application/admin/models/manutencao.php 38
DEBUG - 2013-04-12 15:15:39 --> Database Forge Class Initialized
DEBUG - 2013-04-12 15:15:39 --> Database Utility Class Initialized
ERROR - 2013-04-12 15:16:00 --> Severity: Notice  --> Undefined property: CI::$crud /home/w3case/public_html/target-git/application/admin/third_party/MX/Controller.php 57
DEBUG - 2013-04-12 15:16:57 --> Config Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Hooks Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Utf8 Class Initialized
DEBUG - 2013-04-12 15:16:57 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 15:16:57 --> URI Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Router Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Output Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Security Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Input Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 15:16:57 --> Language Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Loader Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Helper loaded: url_helper
DEBUG - 2013-04-12 15:16:57 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 15:16:57 --> Helper loaded: text_helper
DEBUG - 2013-04-12 15:16:57 --> Session Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Helper loaded: string_helper
DEBUG - 2013-04-12 15:16:57 --> Session routines successfully run
DEBUG - 2013-04-12 15:16:57 --> Controller Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Language Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Config Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 15:16:57 --> Loader Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Model Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Model Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Database Driver Class Initialized
ERROR - 2013-04-12 15:16:57 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 15:16:57 --> Model Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Database Forge Class Initialized
DEBUG - 2013-04-12 15:16:57 --> Database Utility Class Initialized
ERROR - 2013-04-12 15:17:18 --> Severity: Notice  --> Undefined property: CI::$crud /home/w3case/public_html/target-git/application/admin/third_party/MX/Controller.php 57
DEBUG - 2013-04-12 15:43:18 --> Config Class Initialized
DEBUG - 2013-04-12 15:43:18 --> Hooks Class Initialized
DEBUG - 2013-04-12 15:43:18 --> Utf8 Class Initialized
DEBUG - 2013-04-12 15:43:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 15:43:18 --> URI Class Initialized
DEBUG - 2013-04-12 15:43:18 --> Router Class Initialized
DEBUG - 2013-04-12 15:43:19 --> Output Class Initialized
DEBUG - 2013-04-12 15:43:19 --> Security Class Initialized
DEBUG - 2013-04-12 15:43:19 --> Input Class Initialized
DEBUG - 2013-04-12 15:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 15:43:19 --> Language Class Initialized
DEBUG - 2013-04-12 15:43:19 --> Loader Class Initialized
DEBUG - 2013-04-12 15:43:19 --> Helper loaded: url_helper
DEBUG - 2013-04-12 15:43:19 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 15:43:19 --> Helper loaded: text_helper
DEBUG - 2013-04-12 15:43:19 --> Session Class Initialized
DEBUG - 2013-04-12 15:43:19 --> Helper loaded: string_helper
DEBUG - 2013-04-12 15:43:19 --> Session routines successfully run
DEBUG - 2013-04-12 15:43:19 --> Controller Class Initialized
DEBUG - 2013-04-12 15:43:19 --> Language Class Initialized
DEBUG - 2013-04-12 15:43:19 --> Config Class Initialized
DEBUG - 2013-04-12 15:43:19 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 15:43:19 --> Loader Class Initialized
DEBUG - 2013-04-12 15:43:19 --> Model Class Initialized
DEBUG - 2013-04-12 15:43:19 --> Model Class Initialized
DEBUG - 2013-04-12 15:43:19 --> Database Driver Class Initialized
ERROR - 2013-04-12 15:43:19 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 15:43:19 --> Model Class Initialized
DEBUG - 2013-04-12 15:43:19 --> Model Class Initialized
DEBUG - 2013-04-12 15:43:19 --> Database Forge Class Initialized
DEBUG - 2013-04-12 15:43:19 --> Database Utility Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Config Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Hooks Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Utf8 Class Initialized
DEBUG - 2013-04-12 15:45:56 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 15:45:56 --> URI Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Router Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Output Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Security Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Input Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 15:45:56 --> Language Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Loader Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Helper loaded: url_helper
DEBUG - 2013-04-12 15:45:56 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 15:45:56 --> Helper loaded: text_helper
DEBUG - 2013-04-12 15:45:56 --> Session Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Helper loaded: string_helper
DEBUG - 2013-04-12 15:45:56 --> Session routines successfully run
DEBUG - 2013-04-12 15:45:56 --> Controller Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Language Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Config Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 15:45:56 --> Loader Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Model Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Model Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Database Driver Class Initialized
ERROR - 2013-04-12 15:45:56 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 15:45:56 --> Model Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Model Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Database Forge Class Initialized
DEBUG - 2013-04-12 15:45:56 --> Database Utility Class Initialized
ERROR - 2013-04-12 15:46:20 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 15:46:20 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 15:46:20 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 15:46:20 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 15:46:20 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 15:46:20 --> Severity: Warning  --> Missing argument 2 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 199 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 15:46:20 --> Severity: Warning  --> Missing argument 3 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 199 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 15:46:20 --> Severity: Notice  --> Undefined variable: id_name /home/w3case/public_html/target-git/application/admin/models/crud.php 272
DEBUG - 2013-04-12 15:46:20 --> Final output sent to browser
DEBUG - 2013-04-12 15:46:20 --> Total execution time: 23.9125
DEBUG - 2013-04-12 16:07:18 --> Config Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:07:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:07:18 --> URI Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Router Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Output Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Security Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Input Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:07:18 --> Language Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Loader Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:07:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:07:18 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:07:18 --> Session Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:07:18 --> Session routines successfully run
DEBUG - 2013-04-12 16:07:18 --> Controller Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Language Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Config Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:07:18 --> Loader Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Model Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Model Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Database Driver Class Initialized
ERROR - 2013-04-12 16:07:18 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 16:07:18 --> Model Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Model Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Database Forge Class Initialized
DEBUG - 2013-04-12 16:07:18 --> Database Utility Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Config Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:07:26 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:07:26 --> URI Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Router Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Output Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Security Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Input Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:07:26 --> Language Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Loader Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:07:26 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:07:26 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:07:26 --> Session Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:07:26 --> Session routines successfully run
DEBUG - 2013-04-12 16:07:26 --> Controller Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Language Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Config Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:07:26 --> Loader Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Model Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Model Class Initialized
DEBUG - 2013-04-12 16:07:26 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:07:26 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:07:26 --> File loaded: ../application/admin/modules/configuracao/views/manutencao.php
DEBUG - 2013-04-12 16:07:26 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:07:26 --> Final output sent to browser
DEBUG - 2013-04-12 16:07:26 --> Total execution time: 0.1089
DEBUG - 2013-04-12 16:07:29 --> Config Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:07:29 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:07:29 --> URI Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Router Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Output Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Security Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Input Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:07:29 --> Language Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Loader Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:07:29 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:07:29 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:07:29 --> Session Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:07:29 --> Session routines successfully run
DEBUG - 2013-04-12 16:07:29 --> Controller Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Language Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Config Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:07:29 --> Loader Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Model Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Model Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Database Driver Class Initialized
ERROR - 2013-04-12 16:07:29 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 16:07:29 --> Model Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Model Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Database Forge Class Initialized
DEBUG - 2013-04-12 16:07:29 --> Database Utility Class Initialized
ERROR - 2013-04-12 16:07:52 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:07:52 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:07:52 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:07:52 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:07:52 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:07:52 --> Severity: Warning  --> Missing argument 2 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 199 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:07:52 --> Severity: Warning  --> Missing argument 3 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 199 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:07:52 --> Severity: Notice  --> Undefined variable: id_name /home/w3case/public_html/target-git/application/admin/models/crud.php 272
DEBUG - 2013-04-12 16:07:52 --> Final output sent to browser
DEBUG - 2013-04-12 16:07:52 --> Total execution time: 33.8714
ERROR - 2013-04-12 16:08:02 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:08:02 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:08:02 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:08:02 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:08:02 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:08:02 --> Severity: Warning  --> Missing argument 2 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 199 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:08:02 --> Severity: Warning  --> Missing argument 3 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 199 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:08:02 --> Severity: Notice  --> Undefined variable: id_name /home/w3case/public_html/target-git/application/admin/models/crud.php 272
DEBUG - 2013-04-12 16:08:02 --> Final output sent to browser
DEBUG - 2013-04-12 16:08:02 --> Total execution time: 32.7251
DEBUG - 2013-04-12 16:12:10 --> Config Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:12:10 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:12:10 --> URI Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Router Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Output Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Security Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Input Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:12:10 --> Language Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Loader Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:12:10 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:12:10 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:12:10 --> Session Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:12:10 --> Session routines successfully run
DEBUG - 2013-04-12 16:12:10 --> Controller Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Language Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Config Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:12:10 --> Loader Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Model Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Model Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Database Driver Class Initialized
ERROR - 2013-04-12 16:12:10 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 16:12:10 --> Model Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Model Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Database Forge Class Initialized
DEBUG - 2013-04-12 16:12:10 --> Database Utility Class Initialized
ERROR - 2013-04-12 16:12:31 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:12:31 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:12:31 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:12:31 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:12:31 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:12:31 --> Severity: Warning  --> Missing argument 2 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 199 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:12:31 --> Severity: Warning  --> Missing argument 3 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 199 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:12:31 --> Severity: Notice  --> Undefined variable: id_name /home/w3case/public_html/target-git/application/admin/models/crud.php 272
DEBUG - 2013-04-12 16:12:31 --> Final output sent to browser
DEBUG - 2013-04-12 16:12:31 --> Total execution time: 21.2944
DEBUG - 2013-04-12 16:13:01 --> Config Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:13:01 --> URI Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Router Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Output Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Security Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Input Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:13:01 --> Language Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Loader Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:13:01 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:13:01 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:13:01 --> Session Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:13:01 --> Session routines successfully run
DEBUG - 2013-04-12 16:13:01 --> Controller Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Language Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Config Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:13:01 --> Loader Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Model Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Model Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Database Driver Class Initialized
ERROR - 2013-04-12 16:13:01 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 16:13:01 --> Model Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Model Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Database Forge Class Initialized
DEBUG - 2013-04-12 16:13:01 --> Database Utility Class Initialized
ERROR - 2013-04-12 16:13:24 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:13:24 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:13:24 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:13:24 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:13:24 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:13:24 --> Severity: Warning  --> Missing argument 2 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 199 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:13:24 --> Severity: Warning  --> Missing argument 3 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 199 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:13:24 --> Severity: Notice  --> Undefined variable: id_name /home/w3case/public_html/target-git/application/admin/models/crud.php 272
DEBUG - 2013-04-12 16:13:24 --> Final output sent to browser
DEBUG - 2013-04-12 16:13:24 --> Total execution time: 22.5939
DEBUG - 2013-04-12 16:16:28 --> Config Class Initialized
DEBUG - 2013-04-12 16:16:28 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:16:28 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:16:28 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:16:28 --> URI Class Initialized
DEBUG - 2013-04-12 16:16:28 --> Router Class Initialized
DEBUG - 2013-04-12 16:16:28 --> Output Class Initialized
DEBUG - 2013-04-12 16:16:28 --> Security Class Initialized
DEBUG - 2013-04-12 16:16:28 --> Input Class Initialized
DEBUG - 2013-04-12 16:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:16:28 --> Language Class Initialized
DEBUG - 2013-04-12 16:16:28 --> Loader Class Initialized
DEBUG - 2013-04-12 16:16:28 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:16:28 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:16:28 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:16:28 --> Session Class Initialized
DEBUG - 2013-04-12 16:16:28 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:16:28 --> Session routines successfully run
DEBUG - 2013-04-12 16:16:28 --> Controller Class Initialized
DEBUG - 2013-04-12 16:16:28 --> Language Class Initialized
DEBUG - 2013-04-12 16:16:28 --> Config Class Initialized
DEBUG - 2013-04-12 16:16:28 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:16:28 --> Loader Class Initialized
DEBUG - 2013-04-12 16:16:28 --> Model Class Initialized
DEBUG - 2013-04-12 16:16:28 --> Model Class Initialized
DEBUG - 2013-04-12 16:16:28 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:16:28 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:16:28 --> File loaded: ../application/admin/modules/configuracao/views/manutencao.php
DEBUG - 2013-04-12 16:16:28 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:16:28 --> Final output sent to browser
DEBUG - 2013-04-12 16:16:28 --> Total execution time: 0.0331
DEBUG - 2013-04-12 16:16:32 --> Config Class Initialized
DEBUG - 2013-04-12 16:16:32 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:16:32 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:16:32 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:16:32 --> URI Class Initialized
DEBUG - 2013-04-12 16:16:32 --> Router Class Initialized
DEBUG - 2013-04-12 16:16:32 --> Output Class Initialized
DEBUG - 2013-04-12 16:16:32 --> Security Class Initialized
DEBUG - 2013-04-12 16:16:32 --> Input Class Initialized
DEBUG - 2013-04-12 16:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:16:32 --> Language Class Initialized
DEBUG - 2013-04-12 16:16:32 --> Loader Class Initialized
DEBUG - 2013-04-12 16:16:32 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:16:32 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:16:32 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:16:32 --> Session Class Initialized
DEBUG - 2013-04-12 16:16:32 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:16:32 --> Session routines successfully run
DEBUG - 2013-04-12 16:16:32 --> Controller Class Initialized
DEBUG - 2013-04-12 16:16:32 --> Language Class Initialized
DEBUG - 2013-04-12 16:16:32 --> Config Class Initialized
DEBUG - 2013-04-12 16:16:32 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:16:32 --> Loader Class Initialized
DEBUG - 2013-04-12 16:16:32 --> Model Class Initialized
DEBUG - 2013-04-12 16:16:32 --> Model Class Initialized
DEBUG - 2013-04-12 16:16:32 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:16:32 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:16:32 --> File loaded: ../application/admin/modules/configuracao/views/manutencao.php
DEBUG - 2013-04-12 16:16:32 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:16:32 --> Final output sent to browser
DEBUG - 2013-04-12 16:16:32 --> Total execution time: 0.0247
DEBUG - 2013-04-12 16:16:34 --> Config Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:16:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:16:34 --> URI Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Router Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Output Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Security Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Input Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:16:34 --> Language Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Loader Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:16:34 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:16:34 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:16:34 --> Session Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:16:34 --> Session routines successfully run
DEBUG - 2013-04-12 16:16:34 --> Controller Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Language Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Config Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:16:34 --> Loader Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Model Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Model Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Database Driver Class Initialized
ERROR - 2013-04-12 16:16:34 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 16:16:34 --> Model Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Model Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Database Forge Class Initialized
DEBUG - 2013-04-12 16:16:34 --> Database Utility Class Initialized
ERROR - 2013-04-12 16:17:30 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:17:30 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:17:30 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:17:30 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:17:30 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:17:30 --> Severity: Warning  --> Missing argument 2 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 199 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:17:30 --> Severity: Warning  --> Missing argument 3 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 199 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:17:30 --> Severity: Notice  --> Undefined variable: id_name /home/w3case/public_html/target-git/application/admin/models/crud.php 272
DEBUG - 2013-04-12 16:17:30 --> Final output sent to browser
DEBUG - 2013-04-12 16:17:30 --> Total execution time: 55.3719
DEBUG - 2013-04-12 16:20:40 --> Config Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:20:40 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:20:40 --> URI Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Router Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Output Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Security Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Input Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:20:40 --> Language Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Loader Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:20:40 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:20:40 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:20:40 --> Session Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:20:40 --> Session routines successfully run
DEBUG - 2013-04-12 16:20:40 --> Controller Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Language Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Config Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:20:40 --> Loader Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Model Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Model Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Database Driver Class Initialized
ERROR - 2013-04-12 16:20:40 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 16:20:40 --> Model Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Model Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Database Forge Class Initialized
DEBUG - 2013-04-12 16:20:40 --> Database Utility Class Initialized
ERROR - 2013-04-12 16:21:37 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:21:37 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:21:37 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:21:37 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:21:37 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:21:37 --> Severity: Warning  --> Missing argument 2 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 200 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:21:37 --> Severity: Warning  --> Missing argument 3 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 200 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:21:37 --> Severity: Notice  --> Undefined variable: id_name /home/w3case/public_html/target-git/application/admin/models/crud.php 272
DEBUG - 2013-04-12 16:21:37 --> Final output sent to browser
DEBUG - 2013-04-12 16:21:37 --> Total execution time: 56.2948
DEBUG - 2013-04-12 16:22:42 --> Config Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:22:42 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:22:42 --> URI Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Router Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Output Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Security Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Input Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:22:42 --> Language Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Loader Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:22:42 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:22:42 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:22:42 --> Session Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:22:42 --> Session routines successfully run
DEBUG - 2013-04-12 16:22:42 --> Controller Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Language Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Config Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:22:42 --> Loader Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Model Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Model Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Database Driver Class Initialized
ERROR - 2013-04-12 16:22:42 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 16:22:42 --> Model Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Model Class Initialized
ERROR - 2013-04-12 16:22:42 --> Severity: Notice  --> Undefined variable: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 172
DEBUG - 2013-04-12 16:22:42 --> Database Forge Class Initialized
DEBUG - 2013-04-12 16:22:42 --> Database Utility Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Config Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:22:47 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:22:47 --> URI Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Router Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Output Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Security Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Input Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:22:47 --> Language Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Loader Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:22:47 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:22:47 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:22:47 --> Session Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:22:47 --> Session routines successfully run
DEBUG - 2013-04-12 16:22:47 --> Controller Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Language Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Config Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:22:47 --> Loader Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Model Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Model Class Initialized
DEBUG - 2013-04-12 16:22:47 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:22:47 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:22:47 --> File loaded: ../application/admin/modules/configuracao/views/manutencao.php
DEBUG - 2013-04-12 16:22:47 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:22:47 --> Final output sent to browser
DEBUG - 2013-04-12 16:22:47 --> Total execution time: 0.0352
DEBUG - 2013-04-12 16:22:49 --> Config Class Initialized
DEBUG - 2013-04-12 16:22:49 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:22:49 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:22:49 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:22:49 --> URI Class Initialized
DEBUG - 2013-04-12 16:22:49 --> Router Class Initialized
DEBUG - 2013-04-12 16:22:49 --> Output Class Initialized
DEBUG - 2013-04-12 16:22:49 --> Security Class Initialized
DEBUG - 2013-04-12 16:22:49 --> Input Class Initialized
DEBUG - 2013-04-12 16:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:22:49 --> Language Class Initialized
DEBUG - 2013-04-12 16:22:49 --> Loader Class Initialized
DEBUG - 2013-04-12 16:22:49 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:22:49 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:22:49 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:22:49 --> Session Class Initialized
DEBUG - 2013-04-12 16:22:49 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:22:49 --> Session routines successfully run
DEBUG - 2013-04-12 16:22:49 --> Controller Class Initialized
DEBUG - 2013-04-12 16:22:49 --> Language Class Initialized
DEBUG - 2013-04-12 16:22:49 --> Config Class Initialized
DEBUG - 2013-04-12 16:22:49 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:22:49 --> Loader Class Initialized
DEBUG - 2013-04-12 16:22:49 --> Model Class Initialized
DEBUG - 2013-04-12 16:22:49 --> Model Class Initialized
DEBUG - 2013-04-12 16:22:49 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:22:49 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:22:49 --> File loaded: ../application/admin/modules/configuracao/views/manutencao.php
DEBUG - 2013-04-12 16:22:49 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:22:49 --> Final output sent to browser
DEBUG - 2013-04-12 16:22:49 --> Total execution time: 0.0251
DEBUG - 2013-04-12 16:22:50 --> Config Class Initialized
DEBUG - 2013-04-12 16:22:50 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:22:50 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:22:50 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:22:50 --> URI Class Initialized
DEBUG - 2013-04-12 16:22:50 --> Router Class Initialized
DEBUG - 2013-04-12 16:22:50 --> Output Class Initialized
DEBUG - 2013-04-12 16:22:50 --> Security Class Initialized
DEBUG - 2013-04-12 16:22:50 --> Input Class Initialized
DEBUG - 2013-04-12 16:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:22:50 --> Language Class Initialized
DEBUG - 2013-04-12 16:22:50 --> Loader Class Initialized
DEBUG - 2013-04-12 16:22:50 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:22:50 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:22:50 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:22:50 --> Session Class Initialized
DEBUG - 2013-04-12 16:22:50 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:22:50 --> Session routines successfully run
DEBUG - 2013-04-12 16:22:50 --> Controller Class Initialized
DEBUG - 2013-04-12 16:22:50 --> Language Class Initialized
DEBUG - 2013-04-12 16:22:50 --> Config Class Initialized
DEBUG - 2013-04-12 16:22:50 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:22:50 --> Loader Class Initialized
DEBUG - 2013-04-12 16:22:50 --> Model Class Initialized
DEBUG - 2013-04-12 16:22:50 --> Model Class Initialized
DEBUG - 2013-04-12 16:22:50 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:22:50 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:22:50 --> File loaded: ../application/admin/modules/configuracao/views/manutencao.php
DEBUG - 2013-04-12 16:22:50 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:22:50 --> Final output sent to browser
DEBUG - 2013-04-12 16:22:50 --> Total execution time: 0.0271
DEBUG - 2013-04-12 16:22:53 --> Config Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:22:53 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:22:53 --> URI Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Router Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Output Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Security Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Input Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:22:53 --> Language Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Loader Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:22:53 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:22:53 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:22:53 --> Session Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:22:53 --> Session routines successfully run
DEBUG - 2013-04-12 16:22:53 --> Controller Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Language Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Config Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:22:53 --> Loader Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Model Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Model Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Model Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Model Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Database Forge Class Initialized
DEBUG - 2013-04-12 16:22:53 --> Database Utility Class Initialized
ERROR - 2013-04-12 16:23:23 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:23:23 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:23:23 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:23:23 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:23:23 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:23:23 --> Severity: Warning  --> Missing argument 2 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 196 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:23:23 --> Severity: Warning  --> Missing argument 3 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 196 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:23:23 --> Severity: Notice  --> Undefined variable: id_name /home/w3case/public_html/target-git/application/admin/models/crud.php 272
DEBUG - 2013-04-12 16:23:23 --> Final output sent to browser
DEBUG - 2013-04-12 16:23:23 --> Total execution time: 40.7840
DEBUG - 2013-04-12 16:23:31 --> Helper loaded: file_helper
ERROR - 2013-04-12 16:23:31 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:23:31 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:23:31 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:23:31 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:23:31 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:23:31 --> Severity: Warning  --> Missing argument 2 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 196 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:23:31 --> Severity: Warning  --> Missing argument 3 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 196 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:23:31 --> Severity: Notice  --> Undefined variable: id_name /home/w3case/public_html/target-git/application/admin/models/crud.php 272
DEBUG - 2013-04-12 16:23:31 --> Final output sent to browser
DEBUG - 2013-04-12 16:23:31 --> Total execution time: 37.8326
DEBUG - 2013-04-12 16:23:52 --> Config Class Initialized
DEBUG - 2013-04-12 16:23:52 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:23:52 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:23:52 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:23:52 --> URI Class Initialized
DEBUG - 2013-04-12 16:23:52 --> Router Class Initialized
DEBUG - 2013-04-12 16:23:52 --> Output Class Initialized
DEBUG - 2013-04-12 16:23:52 --> Security Class Initialized
DEBUG - 2013-04-12 16:23:52 --> Input Class Initialized
DEBUG - 2013-04-12 16:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:23:52 --> Language Class Initialized
DEBUG - 2013-04-12 16:23:52 --> Loader Class Initialized
DEBUG - 2013-04-12 16:23:52 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:23:52 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:23:52 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:23:52 --> Session Class Initialized
DEBUG - 2013-04-12 16:23:52 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:23:52 --> Session routines successfully run
DEBUG - 2013-04-12 16:23:52 --> Controller Class Initialized
DEBUG - 2013-04-12 16:23:52 --> Language Class Initialized
DEBUG - 2013-04-12 16:23:52 --> Config Class Initialized
DEBUG - 2013-04-12 16:23:52 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:23:52 --> Loader Class Initialized
DEBUG - 2013-04-12 16:23:52 --> Model Class Initialized
DEBUG - 2013-04-12 16:23:52 --> Model Class Initialized
DEBUG - 2013-04-12 16:23:52 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:23:52 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:23:52 --> File loaded: ../application/admin/modules/configuracao/views/manutencao.php
DEBUG - 2013-04-12 16:23:52 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:23:52 --> Final output sent to browser
DEBUG - 2013-04-12 16:23:52 --> Total execution time: 0.0327
DEBUG - 2013-04-12 16:23:54 --> Config Class Initialized
DEBUG - 2013-04-12 16:23:54 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:23:54 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:23:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:23:54 --> URI Class Initialized
DEBUG - 2013-04-12 16:23:54 --> Router Class Initialized
DEBUG - 2013-04-12 16:23:54 --> Output Class Initialized
DEBUG - 2013-04-12 16:23:54 --> Security Class Initialized
DEBUG - 2013-04-12 16:23:54 --> Input Class Initialized
DEBUG - 2013-04-12 16:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:23:54 --> Language Class Initialized
DEBUG - 2013-04-12 16:23:54 --> Loader Class Initialized
DEBUG - 2013-04-12 16:23:54 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:23:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:23:54 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:23:54 --> Session Class Initialized
DEBUG - 2013-04-12 16:23:54 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:23:54 --> Session routines successfully run
DEBUG - 2013-04-12 16:23:54 --> Controller Class Initialized
DEBUG - 2013-04-12 16:23:54 --> Language Class Initialized
DEBUG - 2013-04-12 16:23:54 --> Config Class Initialized
DEBUG - 2013-04-12 16:23:54 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:23:54 --> Loader Class Initialized
DEBUG - 2013-04-12 16:23:54 --> Model Class Initialized
DEBUG - 2013-04-12 16:23:54 --> Model Class Initialized
DEBUG - 2013-04-12 16:23:54 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:23:54 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:23:54 --> File loaded: ../application/admin/modules/configuracao/views/tempo.php
DEBUG - 2013-04-12 16:23:54 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:23:54 --> Final output sent to browser
DEBUG - 2013-04-12 16:23:54 --> Total execution time: 0.0366
DEBUG - 2013-04-12 16:24:45 --> Config Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:24:45 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:24:45 --> URI Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Router Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Output Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Security Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Input Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:24:45 --> Language Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Loader Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:24:45 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:24:45 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:24:45 --> Session Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:24:45 --> Session routines successfully run
DEBUG - 2013-04-12 16:24:45 --> Controller Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Language Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Config Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:24:45 --> Loader Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:24:45 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:45 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:24:45 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 16:24:45 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:24:45 --> Final output sent to browser
DEBUG - 2013-04-12 16:24:45 --> Total execution time: 0.1000
DEBUG - 2013-04-12 16:24:47 --> Config Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:24:47 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:24:47 --> URI Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Router Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Output Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Security Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Input Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:24:47 --> Language Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Loader Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:24:47 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:24:47 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:24:47 --> Session Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:24:47 --> Session routines successfully run
DEBUG - 2013-04-12 16:24:47 --> Controller Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Language Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Config Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:24:47 --> Loader Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:47 --> Final output sent to browser
DEBUG - 2013-04-12 16:24:47 --> Total execution time: 0.0259
DEBUG - 2013-04-12 16:24:48 --> Config Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:24:48 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:24:48 --> URI Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Router Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Output Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Security Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Input Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:24:48 --> Language Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Loader Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:24:48 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:24:48 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:24:48 --> Session Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:24:48 --> Session routines successfully run
DEBUG - 2013-04-12 16:24:48 --> Controller Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Language Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Config Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:24:48 --> Loader Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:24:48 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:48 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:24:48 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 16:24:48 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:24:48 --> Final output sent to browser
DEBUG - 2013-04-12 16:24:48 --> Total execution time: 0.0334
DEBUG - 2013-04-12 16:24:49 --> Config Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:24:49 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:24:49 --> URI Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Router Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Output Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Security Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Input Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:24:49 --> Language Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Loader Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:24:49 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:24:49 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:24:49 --> Session Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:24:49 --> Session routines successfully run
DEBUG - 2013-04-12 16:24:49 --> Controller Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Language Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Config Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:24:49 --> Loader Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:49 --> Final output sent to browser
DEBUG - 2013-04-12 16:24:49 --> Total execution time: 0.0228
DEBUG - 2013-04-12 16:24:52 --> Config Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:24:52 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:24:52 --> URI Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Router Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Output Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Security Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Input Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:24:52 --> Language Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Loader Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:24:52 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:24:52 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:24:52 --> Session Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:24:52 --> Session routines successfully run
DEBUG - 2013-04-12 16:24:52 --> Controller Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Language Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Config Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:24:52 --> Loader Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:24:52 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:52 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:24:52 --> File loaded: ../application/admin/modules/configuracao/views/metas-analytics.php
DEBUG - 2013-04-12 16:24:52 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:24:52 --> Final output sent to browser
DEBUG - 2013-04-12 16:24:52 --> Total execution time: 0.0335
DEBUG - 2013-04-12 16:24:53 --> Config Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:24:53 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:24:53 --> URI Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Router Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Output Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Security Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Input Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:24:53 --> Language Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Loader Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:24:53 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:24:53 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:24:53 --> Session Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:24:53 --> Session routines successfully run
DEBUG - 2013-04-12 16:24:53 --> Controller Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Language Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Config Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:24:53 --> Loader Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:53 --> Final output sent to browser
DEBUG - 2013-04-12 16:24:53 --> Total execution time: 0.0242
DEBUG - 2013-04-12 16:24:54 --> Config Class Initialized
DEBUG - 2013-04-12 16:24:54 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:24:54 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:24:54 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:24:54 --> URI Class Initialized
DEBUG - 2013-04-12 16:24:54 --> Router Class Initialized
DEBUG - 2013-04-12 16:24:54 --> Output Class Initialized
DEBUG - 2013-04-12 16:24:54 --> Security Class Initialized
DEBUG - 2013-04-12 16:24:54 --> Input Class Initialized
DEBUG - 2013-04-12 16:24:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:24:54 --> Language Class Initialized
DEBUG - 2013-04-12 16:24:54 --> Loader Class Initialized
DEBUG - 2013-04-12 16:24:54 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:24:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:24:54 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:24:54 --> Session Class Initialized
DEBUG - 2013-04-12 16:24:54 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:24:54 --> Session routines successfully run
DEBUG - 2013-04-12 16:24:54 --> Controller Class Initialized
DEBUG - 2013-04-12 16:24:54 --> Language Class Initialized
DEBUG - 2013-04-12 16:24:54 --> Config Class Initialized
DEBUG - 2013-04-12 16:24:54 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:24:54 --> Loader Class Initialized
DEBUG - 2013-04-12 16:24:54 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:54 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:54 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:24:54 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:24:54 --> File loaded: ../application/admin/modules/configuracao/views/manutencao.php
DEBUG - 2013-04-12 16:24:54 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:24:54 --> Final output sent to browser
DEBUG - 2013-04-12 16:24:54 --> Total execution time: 0.0229
DEBUG - 2013-04-12 16:24:55 --> Config Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:24:55 --> URI Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Router Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Output Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Security Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Input Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:24:55 --> Language Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Loader Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:24:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:24:55 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:24:55 --> Session Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:24:55 --> Session routines successfully run
DEBUG - 2013-04-12 16:24:55 --> Controller Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Language Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Config Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:24:55 --> Loader Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Database Driver Class Initialized
ERROR - 2013-04-12 16:24:55 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 16:24:55 --> Model Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Model Class Initialized
ERROR - 2013-04-12 16:24:55 --> Severity: Notice  --> Undefined variable: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 172
DEBUG - 2013-04-12 16:24:55 --> Database Forge Class Initialized
DEBUG - 2013-04-12 16:24:55 --> Database Utility Class Initialized
ERROR - 2013-04-12 16:25:16 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:25:16 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:25:16 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:25:16 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:25:16 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:25:16 --> Severity: Warning  --> Missing argument 2 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 196 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:25:16 --> Severity: Warning  --> Missing argument 3 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 196 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:25:16 --> Severity: Notice  --> Undefined variable: id_name /home/w3case/public_html/target-git/application/admin/models/crud.php 272
DEBUG - 2013-04-12 16:25:16 --> Final output sent to browser
DEBUG - 2013-04-12 16:25:16 --> Total execution time: 21.5048
DEBUG - 2013-04-12 16:25:35 --> Config Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:25:35 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:25:35 --> URI Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Router Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Output Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Security Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Input Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:25:35 --> Language Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Loader Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:25:35 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:25:35 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:25:35 --> Session Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:25:35 --> Session routines successfully run
DEBUG - 2013-04-12 16:25:35 --> Controller Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Language Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Config Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:25:35 --> Loader Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Model Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Model Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Database Driver Class Initialized
ERROR - 2013-04-12 16:25:35 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 16:25:35 --> Model Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Model Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Database Forge Class Initialized
DEBUG - 2013-04-12 16:25:35 --> Database Utility Class Initialized
ERROR - 2013-04-12 16:25:57 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:25:57 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:25:57 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:25:57 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:25:57 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:25:57 --> Severity: Warning  --> Missing argument 2 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 200 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:25:57 --> Severity: Warning  --> Missing argument 3 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 200 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:25:57 --> Severity: Notice  --> Undefined variable: id_name /home/w3case/public_html/target-git/application/admin/models/crud.php 272
DEBUG - 2013-04-12 16:25:57 --> Final output sent to browser
DEBUG - 2013-04-12 16:25:57 --> Total execution time: 22.0261
DEBUG - 2013-04-12 16:30:31 --> Config Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:30:31 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:30:31 --> URI Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Router Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Output Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Security Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Input Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:30:31 --> Language Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Loader Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:30:31 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:30:31 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:30:31 --> Session Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:30:31 --> Session routines successfully run
DEBUG - 2013-04-12 16:30:31 --> Controller Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Language Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Config Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:30:31 --> Loader Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Model Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Model Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Database Driver Class Initialized
ERROR - 2013-04-12 16:30:31 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 16:30:31 --> Model Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Model Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Database Forge Class Initialized
DEBUG - 2013-04-12 16:30:31 --> Database Utility Class Initialized
ERROR - 2013-04-12 16:30:53 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:30:53 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:30:53 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:30:53 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:30:53 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:30:53 --> Severity: Warning  --> Missing argument 2 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 200 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:30:53 --> Severity: Warning  --> Missing argument 3 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 200 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:30:53 --> Severity: Notice  --> Undefined variable: id_name /home/w3case/public_html/target-git/application/admin/models/crud.php 272
DEBUG - 2013-04-12 16:30:53 --> Final output sent to browser
DEBUG - 2013-04-12 16:30:53 --> Total execution time: 22.3726
DEBUG - 2013-04-12 16:32:27 --> Config Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:32:27 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:32:27 --> URI Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Router Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Output Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Security Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Input Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:32:27 --> Language Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Loader Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:32:27 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:32:27 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:32:27 --> Session Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:32:27 --> Session routines successfully run
DEBUG - 2013-04-12 16:32:27 --> Controller Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Language Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Config Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:32:27 --> Loader Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Model Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Model Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Database Driver Class Initialized
ERROR - 2013-04-12 16:32:27 --> Severity: Notice  --> Undefined index: backup /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php 162
DEBUG - 2013-04-12 16:32:27 --> Model Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Model Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Database Forge Class Initialized
DEBUG - 2013-04-12 16:32:27 --> Database Utility Class Initialized
ERROR - 2013-04-12 16:32:48 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:32:48 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:32:48 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:32:48 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:32:48 --> Severity: Notice  --> Undefined index: titulo /home/w3case/public_html/target-git/application/admin/models/crud.php 274
ERROR - 2013-04-12 16:32:48 --> Severity: Warning  --> Missing argument 2 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 200 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:32:48 --> Severity: Warning  --> Missing argument 3 for Crud::delete(), called in /home/w3case/public_html/target-git/application/admin/modules/configuracao/controllers/configuracao.php on line 200 and defined /home/w3case/public_html/target-git/application/admin/models/crud.php 270
ERROR - 2013-04-12 16:32:48 --> Severity: Notice  --> Undefined variable: id_name /home/w3case/public_html/target-git/application/admin/models/crud.php 272
DEBUG - 2013-04-12 16:32:48 --> Final output sent to browser
DEBUG - 2013-04-12 16:32:48 --> Total execution time: 21.4324
DEBUG - 2013-04-12 16:34:09 --> Config Class Initialized
DEBUG - 2013-04-12 16:34:09 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:34:09 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:34:09 --> URI Class Initialized
DEBUG - 2013-04-12 16:34:09 --> Router Class Initialized
DEBUG - 2013-04-12 16:34:09 --> Output Class Initialized
DEBUG - 2013-04-12 16:34:09 --> Security Class Initialized
DEBUG - 2013-04-12 16:34:09 --> Input Class Initialized
DEBUG - 2013-04-12 16:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:34:09 --> Language Class Initialized
DEBUG - 2013-04-12 16:34:09 --> Loader Class Initialized
DEBUG - 2013-04-12 16:34:09 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:34:09 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:34:09 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:34:09 --> Session Class Initialized
DEBUG - 2013-04-12 16:34:09 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:34:09 --> Session routines successfully run
DEBUG - 2013-04-12 16:34:09 --> Controller Class Initialized
DEBUG - 2013-04-12 16:34:09 --> Language Class Initialized
DEBUG - 2013-04-12 16:34:09 --> Config Class Initialized
DEBUG - 2013-04-12 16:34:09 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:34:09 --> Loader Class Initialized
DEBUG - 2013-04-12 16:34:09 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:09 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:09 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:34:09 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:34:09 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-12 16:34:09 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:34:09 --> Final output sent to browser
DEBUG - 2013-04-12 16:34:09 --> Total execution time: 0.0368
DEBUG - 2013-04-12 16:34:10 --> Config Class Initialized
DEBUG - 2013-04-12 16:34:10 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:34:10 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:34:10 --> URI Class Initialized
DEBUG - 2013-04-12 16:34:10 --> Router Class Initialized
DEBUG - 2013-04-12 16:34:10 --> Output Class Initialized
DEBUG - 2013-04-12 16:34:10 --> Security Class Initialized
DEBUG - 2013-04-12 16:34:10 --> Input Class Initialized
DEBUG - 2013-04-12 16:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:34:10 --> Language Class Initialized
DEBUG - 2013-04-12 16:34:10 --> Loader Class Initialized
DEBUG - 2013-04-12 16:34:10 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:34:10 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:34:10 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:34:10 --> Session Class Initialized
DEBUG - 2013-04-12 16:34:10 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:34:10 --> Session routines successfully run
DEBUG - 2013-04-12 16:34:10 --> Controller Class Initialized
DEBUG - 2013-04-12 16:34:10 --> Language Class Initialized
DEBUG - 2013-04-12 16:34:10 --> Config Class Initialized
DEBUG - 2013-04-12 16:34:10 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-12 16:34:10 --> Loader Class Initialized
DEBUG - 2013-04-12 16:34:10 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:10 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:10 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:34:10 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-12 16:34:10 --> File loaded: ../application/admin/modules/usuarios/views/usuarios.php
DEBUG - 2013-04-12 16:34:10 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:34:10 --> Final output sent to browser
DEBUG - 2013-04-12 16:34:10 --> Total execution time: 0.0822
DEBUG - 2013-04-12 16:34:12 --> Config Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:34:12 --> URI Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Router Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Output Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Security Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Input Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:34:12 --> Language Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Loader Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:34:12 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:34:12 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:34:12 --> Session Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:34:12 --> Session routines successfully run
DEBUG - 2013-04-12 16:34:12 --> Controller Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Language Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Config Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-12 16:34:12 --> Loader Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Database Driver Class Initialized
ERROR - 2013-04-12 16:34:12 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-12 16:34:12 --> Pagination Class Initialized
DEBUG - 2013-04-12 16:34:12 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:12 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-12 16:34:12 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-12 16:34:12 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:34:12 --> Final output sent to browser
DEBUG - 2013-04-12 16:34:12 --> Total execution time: 0.1604
DEBUG - 2013-04-12 16:34:14 --> Config Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:34:14 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:34:14 --> URI Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Router Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Output Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Security Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Input Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:34:14 --> Language Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Loader Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:34:14 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:34:14 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:34:14 --> Session Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:34:14 --> Session routines successfully run
DEBUG - 2013-04-12 16:34:14 --> Controller Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Language Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Config Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-12 16:34:14 --> Loader Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Database Driver Class Initialized
ERROR - 2013-04-12 16:34:14 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-12 16:34:14 --> Pagination Class Initialized
DEBUG - 2013-04-12 16:34:14 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:14 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-12 16:34:14 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-12 16:34:14 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:34:14 --> Final output sent to browser
DEBUG - 2013-04-12 16:34:14 --> Total execution time: 0.0950
DEBUG - 2013-04-12 16:34:15 --> Config Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:34:15 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:34:15 --> URI Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Router Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Output Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Security Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Input Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:34:15 --> Language Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Loader Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:34:15 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:34:15 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:34:15 --> Session Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:34:15 --> Session routines successfully run
DEBUG - 2013-04-12 16:34:15 --> Controller Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Language Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Config Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-12 16:34:15 --> Loader Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:34:15 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:16 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-12 16:34:16 --> File loaded: ../application/admin/modules/usuarios/views/cadastrar.php
DEBUG - 2013-04-12 16:34:16 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:34:16 --> Final output sent to browser
DEBUG - 2013-04-12 16:34:16 --> Total execution time: 0.2716
DEBUG - 2013-04-12 16:34:17 --> Config Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:34:17 --> URI Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Router Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Output Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Security Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Input Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:34:17 --> Language Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Loader Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:34:17 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:34:17 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:34:17 --> Session Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:34:17 --> Session routines successfully run
DEBUG - 2013-04-12 16:34:17 --> Controller Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Language Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Config Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-12 16:34:17 --> Loader Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Database Driver Class Initialized
ERROR - 2013-04-12 16:34:17 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 127
DEBUG - 2013-04-12 16:34:17 --> Pagination Class Initialized
DEBUG - 2013-04-12 16:34:17 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:17 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-12 16:34:17 --> File loaded: ../application/admin/modules/usuarios/views/gerenciar.php
DEBUG - 2013-04-12 16:34:17 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:34:17 --> Final output sent to browser
DEBUG - 2013-04-12 16:34:17 --> Total execution time: 0.0278
DEBUG - 2013-04-12 16:34:19 --> Config Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:34:19 --> URI Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Router Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Output Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Security Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Input Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:34:19 --> Language Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Loader Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:34:19 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:34:19 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:34:19 --> Session Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:34:19 --> Session routines successfully run
DEBUG - 2013-04-12 16:34:19 --> Controller Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Language Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Config Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-12 16:34:19 --> Loader Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Database Driver Class Initialized
ERROR - 2013-04-12 16:34:19 --> Severity: Notice  --> Undefined index: busca /home/w3case/public_html/target-git/application/admin/modules/usuarios/controllers/usuarios.php 270
DEBUG - 2013-04-12 16:34:19 --> Pagination Class Initialized
DEBUG - 2013-04-12 16:34:19 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:19 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-12 16:34:19 --> File loaded: ../application/admin/modules/usuarios/views/lixeira.php
DEBUG - 2013-04-12 16:34:19 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:34:19 --> Final output sent to browser
DEBUG - 2013-04-12 16:34:19 --> Total execution time: 0.0315
DEBUG - 2013-04-12 16:34:22 --> Config Class Initialized
DEBUG - 2013-04-12 16:34:22 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:34:22 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:34:22 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:34:22 --> URI Class Initialized
DEBUG - 2013-04-12 16:34:22 --> Router Class Initialized
DEBUG - 2013-04-12 16:34:22 --> Output Class Initialized
DEBUG - 2013-04-12 16:34:22 --> Security Class Initialized
DEBUG - 2013-04-12 16:34:22 --> Input Class Initialized
DEBUG - 2013-04-12 16:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:34:22 --> Language Class Initialized
DEBUG - 2013-04-12 16:34:22 --> Loader Class Initialized
DEBUG - 2013-04-12 16:34:22 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:34:22 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:34:22 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:34:22 --> Session Class Initialized
DEBUG - 2013-04-12 16:34:22 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:34:22 --> Session routines successfully run
DEBUG - 2013-04-12 16:34:22 --> Controller Class Initialized
DEBUG - 2013-04-12 16:34:22 --> Language Class Initialized
DEBUG - 2013-04-12 16:34:22 --> Config Class Initialized
DEBUG - 2013-04-12 16:34:22 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:34:22 --> Loader Class Initialized
DEBUG - 2013-04-12 16:34:22 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:22 --> Model Class Initialized
DEBUG - 2013-04-12 16:34:22 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:34:22 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:34:22 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-12 16:34:22 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:34:22 --> Final output sent to browser
DEBUG - 2013-04-12 16:34:22 --> Total execution time: 0.0223
DEBUG - 2013-04-12 16:44:38 --> Config Class Initialized
DEBUG - 2013-04-12 16:44:38 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:44:38 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:44:38 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:44:38 --> URI Class Initialized
DEBUG - 2013-04-12 16:44:38 --> Router Class Initialized
DEBUG - 2013-04-12 16:44:38 --> Output Class Initialized
DEBUG - 2013-04-12 16:44:38 --> Security Class Initialized
DEBUG - 2013-04-12 16:44:38 --> Input Class Initialized
DEBUG - 2013-04-12 16:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:44:38 --> Language Class Initialized
DEBUG - 2013-04-12 16:44:38 --> Loader Class Initialized
DEBUG - 2013-04-12 16:44:38 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:44:38 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:44:38 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:44:38 --> Session Class Initialized
DEBUG - 2013-04-12 16:44:38 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:44:38 --> Session routines successfully run
DEBUG - 2013-04-12 16:44:38 --> Controller Class Initialized
DEBUG - 2013-04-12 16:44:38 --> Language Class Initialized
DEBUG - 2013-04-12 16:44:38 --> Config Class Initialized
DEBUG - 2013-04-12 16:44:38 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:44:38 --> Loader Class Initialized
DEBUG - 2013-04-12 16:44:38 --> Model Class Initialized
DEBUG - 2013-04-12 16:44:38 --> Model Class Initialized
DEBUG - 2013-04-12 16:44:38 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:44:38 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:44:38 --> File loaded: ../application/admin/modules/configuracao/views/tempo.php
DEBUG - 2013-04-12 16:44:38 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:44:38 --> Final output sent to browser
DEBUG - 2013-04-12 16:44:38 --> Total execution time: 0.0379
DEBUG - 2013-04-12 16:48:34 --> Config Class Initialized
DEBUG - 2013-04-12 16:48:34 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:48:34 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:48:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:48:34 --> URI Class Initialized
DEBUG - 2013-04-12 16:48:34 --> Router Class Initialized
DEBUG - 2013-04-12 16:48:34 --> Output Class Initialized
DEBUG - 2013-04-12 16:48:34 --> Security Class Initialized
DEBUG - 2013-04-12 16:48:34 --> Input Class Initialized
DEBUG - 2013-04-12 16:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:48:34 --> Language Class Initialized
DEBUG - 2013-04-12 16:48:34 --> Loader Class Initialized
DEBUG - 2013-04-12 16:48:34 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:48:34 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:48:34 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:48:34 --> Session Class Initialized
DEBUG - 2013-04-12 16:48:34 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:48:34 --> Session routines successfully run
DEBUG - 2013-04-12 16:48:34 --> Controller Class Initialized
DEBUG - 2013-04-12 16:48:34 --> Language Class Initialized
DEBUG - 2013-04-12 16:48:34 --> Config Class Initialized
DEBUG - 2013-04-12 16:48:34 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:48:34 --> Loader Class Initialized
DEBUG - 2013-04-12 16:48:34 --> Model Class Initialized
DEBUG - 2013-04-12 16:48:34 --> Model Class Initialized
DEBUG - 2013-04-12 16:48:34 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:48:35 --> Model Class Initialized
DEBUG - 2013-04-12 16:48:35 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:48:35 --> File loaded: ../application/admin/modules/configuracao/views/tempo.php
DEBUG - 2013-04-12 16:48:35 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:48:35 --> Final output sent to browser
DEBUG - 2013-04-12 16:48:35 --> Total execution time: 0.0326
DEBUG - 2013-04-12 16:49:15 --> Config Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:49:15 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:49:15 --> URI Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Router Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Output Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Security Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Input Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:49:15 --> Language Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Loader Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:49:15 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:49:15 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:49:15 --> Session Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:49:15 --> Session routines successfully run
DEBUG - 2013-04-12 16:49:15 --> Controller Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Language Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Config Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:49:15 --> Loader Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:49:15 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:15 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:49:15 --> File loaded: ../application/admin/modules/configuracao/views/tempo.php
DEBUG - 2013-04-12 16:49:15 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:49:15 --> Final output sent to browser
DEBUG - 2013-04-12 16:49:15 --> Total execution time: 0.0248
DEBUG - 2013-04-12 16:49:18 --> Config Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:49:18 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:49:18 --> URI Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Router Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Output Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Security Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Input Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:49:18 --> Language Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Loader Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:49:18 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:49:18 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:49:18 --> Session Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:49:18 --> Session routines successfully run
DEBUG - 2013-04-12 16:49:18 --> Controller Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Language Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Config Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:49:18 --> Loader Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:49:18 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:18 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:49:18 --> File loaded: ../application/admin/modules/configuracao/views/tempo.php
DEBUG - 2013-04-12 16:49:18 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:49:18 --> Final output sent to browser
DEBUG - 2013-04-12 16:49:18 --> Total execution time: 0.0268
DEBUG - 2013-04-12 16:49:32 --> Config Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:49:32 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:49:32 --> URI Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Router Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Output Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Security Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Input Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:49:32 --> Language Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Loader Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:49:32 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:49:32 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:49:32 --> Session Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:49:32 --> Session routines successfully run
DEBUG - 2013-04-12 16:49:32 --> Controller Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Language Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Config Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:49:32 --> Loader Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:49:32 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:32 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:49:32 --> File loaded: ../application/admin/modules/configuracao/views/tempo.php
DEBUG - 2013-04-12 16:49:32 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:49:32 --> Final output sent to browser
DEBUG - 2013-04-12 16:49:32 --> Total execution time: 0.0334
DEBUG - 2013-04-12 16:49:33 --> Config Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:49:33 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:49:33 --> URI Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Router Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Output Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Security Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Input Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:49:33 --> Language Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Loader Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:49:33 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:49:33 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:49:33 --> Session Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:49:33 --> Session routines successfully run
DEBUG - 2013-04-12 16:49:33 --> Controller Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Language Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Config Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:49:33 --> Loader Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:49:33 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:33 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:49:33 --> File loaded: ../application/admin/modules/configuracao/views/tempo.php
DEBUG - 2013-04-12 16:49:33 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:49:33 --> Final output sent to browser
DEBUG - 2013-04-12 16:49:33 --> Total execution time: 0.0298
DEBUG - 2013-04-12 16:49:34 --> Config Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:49:34 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:49:34 --> URI Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Router Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Output Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Security Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Input Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:49:34 --> Language Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Loader Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:49:34 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:49:34 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:49:34 --> Session Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:49:34 --> Session routines successfully run
DEBUG - 2013-04-12 16:49:34 --> Controller Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Language Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Config Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:49:34 --> Loader Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:49:34 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:34 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:49:34 --> File loaded: ../application/admin/modules/configuracao/views/tempo.php
DEBUG - 2013-04-12 16:49:34 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:49:34 --> Final output sent to browser
DEBUG - 2013-04-12 16:49:34 --> Total execution time: 0.0286
DEBUG - 2013-04-12 16:49:53 --> Config Class Initialized
DEBUG - 2013-04-12 16:49:53 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:49:53 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:49:53 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:49:53 --> URI Class Initialized
DEBUG - 2013-04-12 16:49:53 --> Router Class Initialized
DEBUG - 2013-04-12 16:49:53 --> Output Class Initialized
DEBUG - 2013-04-12 16:49:53 --> Security Class Initialized
DEBUG - 2013-04-12 16:49:53 --> Input Class Initialized
DEBUG - 2013-04-12 16:49:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:49:53 --> Language Class Initialized
DEBUG - 2013-04-12 16:49:54 --> Loader Class Initialized
DEBUG - 2013-04-12 16:49:54 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:49:54 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:49:54 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:49:54 --> Session Class Initialized
DEBUG - 2013-04-12 16:49:54 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:49:54 --> Session routines successfully run
DEBUG - 2013-04-12 16:49:54 --> Controller Class Initialized
DEBUG - 2013-04-12 16:49:54 --> Language Class Initialized
DEBUG - 2013-04-12 16:49:54 --> Config Class Initialized
DEBUG - 2013-04-12 16:49:54 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:49:54 --> Loader Class Initialized
DEBUG - 2013-04-12 16:49:54 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:54 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:54 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:49:54 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:54 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:49:54 --> File loaded: ../application/admin/modules/configuracao/views/tempo.php
DEBUG - 2013-04-12 16:49:54 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:49:54 --> Final output sent to browser
DEBUG - 2013-04-12 16:49:54 --> Total execution time: 0.0258
DEBUG - 2013-04-12 16:49:55 --> Config Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:49:55 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:49:55 --> URI Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Router Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Output Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Security Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Input Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:49:55 --> Language Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Loader Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:49:55 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:49:55 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:49:55 --> Session Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:49:55 --> Session routines successfully run
DEBUG - 2013-04-12 16:49:55 --> Controller Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Language Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Config Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:49:55 --> Loader Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Model Class Initialized
DEBUG - 2013-04-12 16:49:55 --> Final output sent to browser
DEBUG - 2013-04-12 16:49:55 --> Total execution time: 0.0238
DEBUG - 2013-04-12 16:50:02 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:50:02 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:50:02 --> URI Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Router Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Output Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Security Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Input Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:50:02 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:50:02 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:50:02 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:50:02 --> Session Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:50:02 --> Session routines successfully run
DEBUG - 2013-04-12 16:50:02 --> Controller Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:50:02 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:02 --> Final output sent to browser
DEBUG - 2013-04-12 16:50:02 --> Total execution time: 0.0345
DEBUG - 2013-04-12 16:50:03 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:50:03 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:50:03 --> URI Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Router Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Output Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Security Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Input Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:50:03 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:50:03 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:50:03 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:50:03 --> Session Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:50:03 --> Session routines successfully run
DEBUG - 2013-04-12 16:50:03 --> Controller Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:50:03 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:50:03 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:03 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:50:03 --> File loaded: ../application/admin/modules/configuracao/views/tempo.php
DEBUG - 2013-04-12 16:50:03 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:50:03 --> Final output sent to browser
DEBUG - 2013-04-12 16:50:03 --> Total execution time: 0.0256
DEBUG - 2013-04-12 16:50:09 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:09 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:50:09 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:50:09 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:50:09 --> URI Class Initialized
DEBUG - 2013-04-12 16:50:09 --> Router Class Initialized
DEBUG - 2013-04-12 16:50:09 --> Output Class Initialized
DEBUG - 2013-04-12 16:50:09 --> Security Class Initialized
DEBUG - 2013-04-12 16:50:09 --> Input Class Initialized
DEBUG - 2013-04-12 16:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:50:09 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:09 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:09 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:50:09 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:50:09 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:50:09 --> Session Class Initialized
DEBUG - 2013-04-12 16:50:09 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:50:09 --> Session routines successfully run
DEBUG - 2013-04-12 16:50:09 --> Controller Class Initialized
DEBUG - 2013-04-12 16:50:09 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:09 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:09 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:50:09 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:09 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:09 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:09 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:50:09 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:50:09 --> File loaded: ../application/admin/modules/configuracao/views/manutencao.php
DEBUG - 2013-04-12 16:50:09 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:50:09 --> Final output sent to browser
DEBUG - 2013-04-12 16:50:09 --> Total execution time: 0.0319
DEBUG - 2013-04-12 16:50:10 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:50:10 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:50:10 --> URI Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Router Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Output Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Security Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Input Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:50:10 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:50:10 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:50:10 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:50:10 --> Session Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:50:10 --> Session routines successfully run
DEBUG - 2013-04-12 16:50:10 --> Controller Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:50:10 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:50:10 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:10 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:50:10 --> File loaded: ../application/admin/modules/configuracao/views/metas-analytics.php
DEBUG - 2013-04-12 16:50:10 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:50:10 --> Final output sent to browser
DEBUG - 2013-04-12 16:50:10 --> Total execution time: 0.0354
DEBUG - 2013-04-12 16:50:11 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:50:11 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:50:11 --> URI Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Router Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Output Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Security Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Input Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:50:11 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:50:11 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:50:11 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:50:11 --> Session Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:50:11 --> Session routines successfully run
DEBUG - 2013-04-12 16:50:11 --> Controller Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:50:11 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:50:11 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:11 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:50:11 --> File loaded: ../application/admin/modules/configuracao/views/emails.php
DEBUG - 2013-04-12 16:50:11 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:50:11 --> Final output sent to browser
DEBUG - 2013-04-12 16:50:11 --> Total execution time: 0.0309
DEBUG - 2013-04-12 16:50:12 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:50:12 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:50:12 --> URI Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Router Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Output Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Security Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Input Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:50:12 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:50:12 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:50:12 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:50:12 --> Session Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:50:12 --> Session routines successfully run
DEBUG - 2013-04-12 16:50:12 --> Controller Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:50:12 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:50:12 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:12 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:50:12 --> File loaded: ../application/admin/modules/configuracao/views/geral.php
DEBUG - 2013-04-12 16:50:12 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:50:12 --> Final output sent to browser
DEBUG - 2013-04-12 16:50:12 --> Total execution time: 0.0345
DEBUG - 2013-04-12 16:50:19 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:19 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:50:19 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:50:19 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:50:19 --> URI Class Initialized
DEBUG - 2013-04-12 16:50:19 --> Router Class Initialized
DEBUG - 2013-04-12 16:50:19 --> Output Class Initialized
DEBUG - 2013-04-12 16:50:19 --> Security Class Initialized
DEBUG - 2013-04-12 16:50:19 --> Input Class Initialized
DEBUG - 2013-04-12 16:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:50:19 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:19 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:19 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:50:19 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:50:19 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:50:19 --> Session Class Initialized
DEBUG - 2013-04-12 16:50:19 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:50:19 --> Session routines successfully run
DEBUG - 2013-04-12 16:50:19 --> Controller Class Initialized
DEBUG - 2013-04-12 16:50:19 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:19 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:19 --> Configuracao MX_Controller Initialized
DEBUG - 2013-04-12 16:50:19 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:19 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:19 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:19 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:50:19 --> File loaded: ../application/admin/modules/configuracao/views/nav.php
DEBUG - 2013-04-12 16:50:19 --> File loaded: ../application/admin/modules/configuracao/views/configuracoes.php
DEBUG - 2013-04-12 16:50:19 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:50:19 --> Final output sent to browser
DEBUG - 2013-04-12 16:50:19 --> Total execution time: 0.0237
DEBUG - 2013-04-12 16:50:21 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:21 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:50:21 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:50:21 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:50:21 --> URI Class Initialized
DEBUG - 2013-04-12 16:50:21 --> Router Class Initialized
DEBUG - 2013-04-12 16:50:21 --> Output Class Initialized
DEBUG - 2013-04-12 16:50:21 --> Security Class Initialized
DEBUG - 2013-04-12 16:50:21 --> Input Class Initialized
DEBUG - 2013-04-12 16:50:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:50:21 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:21 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:21 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:50:21 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:50:21 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:50:21 --> Session Class Initialized
DEBUG - 2013-04-12 16:50:21 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:50:21 --> Session routines successfully run
DEBUG - 2013-04-12 16:50:21 --> Controller Class Initialized
DEBUG - 2013-04-12 16:50:21 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:21 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:21 --> Usuarios MX_Controller Initialized
DEBUG - 2013-04-12 16:50:21 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:21 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:21 --> Model Class Initialized
DEBUG - 2013-04-12 16:50:21 --> Database Driver Class Initialized
DEBUG - 2013-04-12 16:50:21 --> File loaded: ../application/admin/modules/usuarios/views/nav.php
DEBUG - 2013-04-12 16:50:21 --> File loaded: ../application/admin/modules/usuarios/views/usuarios.php
DEBUG - 2013-04-12 16:50:21 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:50:21 --> Final output sent to browser
DEBUG - 2013-04-12 16:50:21 --> Total execution time: 0.0285
DEBUG - 2013-04-12 16:50:24 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:24 --> Hooks Class Initialized
DEBUG - 2013-04-12 16:50:24 --> Utf8 Class Initialized
DEBUG - 2013-04-12 16:50:24 --> UTF-8 Support Enabled
DEBUG - 2013-04-12 16:50:24 --> URI Class Initialized
DEBUG - 2013-04-12 16:50:24 --> Router Class Initialized
DEBUG - 2013-04-12 16:50:24 --> Output Class Initialized
DEBUG - 2013-04-12 16:50:24 --> Security Class Initialized
DEBUG - 2013-04-12 16:50:24 --> Input Class Initialized
DEBUG - 2013-04-12 16:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-04-12 16:50:24 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:24 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:24 --> Helper loaded: url_helper
DEBUG - 2013-04-12 16:50:24 --> Helper loaded: functions_helper
DEBUG - 2013-04-12 16:50:24 --> Helper loaded: text_helper
DEBUG - 2013-04-12 16:50:24 --> Session Class Initialized
DEBUG - 2013-04-12 16:50:24 --> Helper loaded: string_helper
DEBUG - 2013-04-12 16:50:24 --> Session routines successfully run
DEBUG - 2013-04-12 16:50:24 --> Controller Class Initialized
DEBUG - 2013-04-12 16:50:24 --> Language Class Initialized
DEBUG - 2013-04-12 16:50:24 --> Config Class Initialized
DEBUG - 2013-04-12 16:50:24 --> Atualizacoes MX_Controller Initialized
DEBUG - 2013-04-12 16:50:24 --> Loader Class Initialized
DEBUG - 2013-04-12 16:50:24 --> File loaded: ../application/admin/modules/atualizacoes/views/atualizacoes.php
DEBUG - 2013-04-12 16:50:24 --> File loaded: ../application/admin/modules/principal/views/principal.php
DEBUG - 2013-04-12 16:50:24 --> Final output sent to browser
DEBUG - 2013-04-12 16:50:24 --> Total execution time: 0.0321
