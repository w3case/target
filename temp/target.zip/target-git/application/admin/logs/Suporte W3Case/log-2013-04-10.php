<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

INFO  - 2013-04-10 07:44:03 --> O usuario logou no sistema
INFO  - 2013-04-10 07:44:11 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 07:52:57 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 08:18:22 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 08:23:09 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 08:23:27 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 08:24:36 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 08:25:13 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 08:30:03 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 08:30:23 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 08:30:26 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 08:30:29 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 09:53:31 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 10:05:19 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 10:10:32 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 10:32:11 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 10:40:31 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 10:41:09 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 10:41:22 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 10:42:48 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 10:44:20 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 13:32:22 --> O usuario logou no sistema
INFO  - 2013-04-10 13:49:15 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 13:50:37 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 13:50:44 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 13:54:19 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 13:54:28 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 13:55:30 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 13:55:33 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 13:56:02 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 13:56:07 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 13:56:07 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 13:59:48 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 13:59:57 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 13:59:57 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:00:58 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:01:08 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:02:23 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:02:46 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:02:57 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:03:09 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:03:27 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:04:14 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:04:40 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:05:37 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:06:42 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:08:16 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:09:28 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:09:31 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:10:36 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:14:08 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:14:58 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:15:09 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:15:18 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:16:18 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-10 14:16:20 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:16:26 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:16:29 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:17:37 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:17:51 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:18:15 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:19:55 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:20:13 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:20:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:25:50 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:26:01 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:26:41 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:26:57 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:27:18 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:27:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:27:41 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:27:58 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:28:18 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:28:30 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:48:08 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:49:48 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:50:01 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:50:13 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:50:17 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:50:20 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:50:23 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 14:50:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:14:19 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:15:05 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:16:43 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:16:47 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:16:48 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:17:13 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:17:16 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:17:19 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:17:20 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:17:23 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:18:55 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:18:55 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:19:00 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:19:00 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:19:52 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:19:56 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:19:56 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:20:01 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:20:07 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:20:07 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:20:37 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:21:14 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:21:30 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:21:33 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:21:34 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:22:10 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:22:10 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:22:14 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:22:14 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:22:37 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:22:39 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:22:41 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:22:52 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:22:56 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:22:58 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:23:02 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:23:05 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:23:08 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:23:12 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:23:14 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:23:18 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:23:21 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:23:50 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:23:51 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:23:53 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:24:16 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:24:18 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:24:21 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:24:26 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:24:28 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:24:31 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:24:55 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:24:57 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:25:00 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:25:02 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:25:03 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:25:10 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:25:50 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:26:02 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:26:06 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:26:09 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:26:11 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:27:37 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:27:44 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:27:46 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:27:49 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:27:50 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:27:57 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:27:57 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:28:09 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:28:11 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:28:14 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:29:09 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:29:12 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:31:12 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:31:15 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:31:17 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:31:18 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:31:26 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:31:55 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:32:10 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:32:14 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:32:20 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:32:21 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:32:24 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:32:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:32:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:32:29 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:32:33 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:32:42 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:32:48 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:32:50 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:33:05 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:33:34 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:34:21 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:35:33 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:36:18 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:38:05 --> O usuario logou no sistema
INFO  - 2013-04-10 15:38:11 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:38:39 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:38:41 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:39:13 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:39:13 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:39:17 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:39:22 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:39:27 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:39:27 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:39:30 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:39:44 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:40:14 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:40:18 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:40:31 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:40:31 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:40:48 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:40:53 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:41:05 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:41:05 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:41:07 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:41:12 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:41:56 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:41:59 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:42:11 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:44:18 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:44:19 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:44:19 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:44:19 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:44:20 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 15:44:26 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:01:18 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:01:26 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:01:38 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:01:41 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:01:49 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:02:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:02:34 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:02:43 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:02:52 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:02:52 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:02:52 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:03:00 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:03:40 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:03:51 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:04:16 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:04:23 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:04:24 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:04:46 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:04:54 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:05:01 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:05:19 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:05:36 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:06:43 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:07:08 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:07:14 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:07:49 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:07:51 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:07:51 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:07:51 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:07:59 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:00 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:00 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:00 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:09 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:09 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:09 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:10 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:10 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:10 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:10 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:10 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:10 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:40 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:40 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:40 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:40 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:41 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:41 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:08:41 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:08 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:09 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:09 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:09 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:09 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:10 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:10 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:10 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:10 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:10 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:10 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:11 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:11 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:11 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:11 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:11 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:11 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:11 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:24 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:09:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:10:13 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:10:13 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:10:14 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:10:14 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:10:14 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:10:52 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:10:53 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:10:53 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:10:53 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:10:53 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:10:54 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:10:54 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:10:54 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:11:12 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:11:12 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:11:12 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:11:13 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:11:51 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:12:42 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:12:44 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:12:49 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:13:17 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:13:32 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:13:35 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:13:37 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:13:38 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:13:38 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:13:40 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:13:40 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:15:15 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:27:05 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:27:28 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:28:29 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:29:57 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:30:22 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:39:14 --> O usuario logou no sistema
INFO  - 2013-04-10 16:39:20 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:40:23 --> O usuario logou no sistema
INFO  - 2013-04-10 16:40:39 --> O usuario logou no sistema
INFO  - 2013-04-10 16:40:44 --> O usuario logou no sistema
INFO  - 2013-04-10 16:40:53 --> O usuario logou no sistema
INFO  - 2013-04-10 16:40:59 --> O usuario logou no sistema
INFO  - 2013-04-10 16:41:08 --> O usuario logou no sistema
INFO  - 2013-04-10 16:41:12 --> O usuario logou no sistema
INFO  - 2013-04-10 16:41:16 --> O usuario logou no sistema
INFO  - 2013-04-10 16:41:22 --> O usuario logou no sistema
INFO  - 2013-04-10 16:41:34 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:41:43 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:41:43 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:41:50 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:41:50 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:41:53 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:41:53 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:41:56 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:41:56 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-10 16:42:01 --> O usuario acessou a área para a listagem dos dados dos usuarios
