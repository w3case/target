<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

INFO  - 2013-04-13 08:39:41 --> O usuario logou no sistema
INFO  - 2013-04-13 08:39:48 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-13 08:39:52 --> O usuario acessou a área de configurações de MetaTags / Analytics
INFO  - 2013-04-13 08:39:57 --> O usuario acessou a área de configurações do Codigo do tempo
INFO  - 2013-04-13 08:49:54 --> O usuario acessou a área de configurações do Codigo do tempo
INFO  - 2013-04-13 08:49:58 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-13 08:50:07 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-13 08:50:09 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-13 08:50:37 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-13 08:50:40 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-13 09:20:39 --> O usuario acessou a área de configurações de MetaTags / Analytics
INFO  - 2013-04-13 09:20:45 --> O usuario acessou a área para a listagem dos dados dos usuarios
