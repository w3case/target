<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

INFO  - 2013-04-15 14:08:53 --> O usuario logou no sistema
INFO  - 2013-04-15 14:09:05 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-15 14:09:21 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-15 14:09:25 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-15 14:36:34 --> O usuario logou no sistema
INFO  - 2013-04-15 14:40:12 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-15 14:44:36 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-15 15:07:15 --> O usuario logou no sistema
