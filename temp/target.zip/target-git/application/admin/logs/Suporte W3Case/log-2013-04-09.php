<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

INFO  - 2013-04-09 09:58:16 --> O usuario logou no sistema
INFO  - 2013-04-09 10:04:32 --> O usuario logou no sistema
INFO  - 2013-04-09 10:40:50 --> O usuario logou no sistema
INFO  - 2013-04-09 10:51:53 --> O usuario logou no sistema
INFO  - 2013-04-09 10:52:19 --> O usuario logou no sistema
INFO  - 2013-04-09 10:53:32 --> O usuario logou no sistema
INFO  - 2013-04-09 13:24:08 --> O usuario logou no sistema
INFO  - 2013-04-09 14:16:43 --> O usuario logou no sistema
INFO  - 2013-04-09 15:03:51 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 15:03:53 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 15:32:10 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 15:47:54 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 15:47:55 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 15:47:56 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 15:47:56 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 15:47:56 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 15:48:30 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 15:55:51 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 15:57:09 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 15:57:49 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 15:57:52 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 15:57:52 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 15:57:57 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 15:59:19 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 16:04:17 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 16:04:48 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 16:21:41 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 16:25:47 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 16:26:55 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 16:27:24 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 16:27:57 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 16:28:16 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 16:28:25 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 16:28:37 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 16:29:31 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 16:32:51 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 16:33:38 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 16:33:45 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-09 16:33:52 --> O usuario acessou a area de cadastro de novos usuários
