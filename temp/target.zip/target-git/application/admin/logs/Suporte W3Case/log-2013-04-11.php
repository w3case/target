<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

INFO  - 2013-04-11 08:08:44 --> O usuario logou no sistema
INFO  - 2013-04-11 08:08:50 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 08:09:13 --> O usuario logou no sistema
INFO  - 2013-04-11 08:09:18 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 08:13:46 --> O usuario logou no sistema
INFO  - 2013-04-11 08:13:49 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 08:13:56 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 08:13:56 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 08:13:59 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 08:13:59 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 08:34:34 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 08:36:07 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 08:38:31 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 08:52:19 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 09:03:58 --> O usuario logou no sistema
INFO  - 2013-04-11 09:04:11 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 09:31:30 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 09:56:20 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 09:57:50 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 09:58:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 09:59:28 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:00:07 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:20:39 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:33:12 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:34:00 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:34:03 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:34:52 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:36:54 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:37:03 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:37:12 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:50:01 --> O usuario logou no sistema
INFO  - 2013-04-11 10:50:06 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:50:58 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:51:24 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:51:27 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:51:51 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:51:53 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:52:08 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:52:35 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:54:08 --> O usuario excluiu um outro usuário com id: 
INFO  - 2013-04-11 10:54:12 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:54:14 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 10:54:37 --> O usuario excluiu um outro usuário com id: 
INFO  - 2013-04-11 10:56:15 --> O usuario excluiu um outro usuário com id: 
INFO  - 2013-04-11 13:18:06 --> O usuario logou no sistema
INFO  - 2013-04-11 13:20:39 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:20:58 --> O usuario logou no sistema
INFO  - 2013-04-11 13:22:16 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:25:29 --> O usuario excluiu um outro usuário com id: 
INFO  - 2013-04-11 13:26:03 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:27:23 --> O usuario excluiu um outro usuário com id: 20
INFO  - 2013-04-11 13:27:28 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:28:01 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:28:09 --> O usuario excluiu um outro usuário com id: 21
INFO  - 2013-04-11 13:28:09 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:28:16 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 13:31:28 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:34:36 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:34:46 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:38:20 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:39:46 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:39:54 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:40:28 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:41:41 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:41:45 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:43:18 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:43:23 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:43:27 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:46:06 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 13:46:25 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 13:46:28 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:47:22 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:48:54 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:50:41 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 13:50:50 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:04:07 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:05:19 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:05:51 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:05:59 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:07:02 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:07:05 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:07:09 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:07:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:07:47 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:13:50 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:13:50 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:13:52 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:15:34 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:19:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:19:27 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:19:29 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:19:30 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:29:18 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:36:28 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:36:52 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 14:37:44 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 14:38:01 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 14:38:04 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:38:09 --> O usuario excluiu um outro usuário com id: 22
INFO  - 2013-04-11 14:38:09 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:38:16 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:38:19 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 14:38:21 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:39:29 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:44:24 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:45:00 --> O usuario excluiu um outro usuário com id: 22
INFO  - 2013-04-11 14:45:00 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:45:03 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:45:17 --> O usuario excluiu um outro usuário com id: 22
INFO  - 2013-04-11 14:45:17 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:45:19 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 14:48:34 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 14:49:01 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 14:49:06 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:00:25 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:02:48 --> O usuario excluiu um outro usuário com id: 22
INFO  - 2013-04-11 15:02:48 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:02:51 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:03:30 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:03:32 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 15:03:51 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 15:03:54 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:04:03 --> O usuario excluiu um outro usuário com id: 23
INFO  - 2013-04-11 15:04:03 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:04:08 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:04:16 --> O usuario excluiu um outro usuário com id: 23
INFO  - 2013-04-11 15:04:16 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:04:53 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:05:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:05:28 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 15:05:54 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 15:06:02 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:06:04 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:06:08 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:06:16 --> O usuario excluiu um outro usuário com id: 24
INFO  - 2013-04-11 15:06:16 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:06:18 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:06:27 --> O usuario excluiu um outro usuário com id: 24
INFO  - 2013-04-11 15:06:27 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:06:31 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 15:06:34 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:06:38 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 15:07:02 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 15:07:23 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 15:07:30 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:07:37 --> O usuario excluiu um outro usuário com id: 25
INFO  - 2013-04-11 15:07:37 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:07:43 --> O usuario excluiu um outro usuário com id: 26
INFO  - 2013-04-11 15:07:43 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:07:56 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:27:33 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:27:41 --> O usuario logou no sistema
INFO  - 2013-04-11 15:27:44 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:28:32 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:29:57 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:30:02 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:30:04 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:30:15 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:30:17 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:30:27 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:30:32 --> O usuario excluiu um outro usuário com id: 26
INFO  - 2013-04-11 15:30:33 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:30:34 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:30:41 --> O usuario excluiu um outro usuário com id: 25
INFO  - 2013-04-11 15:30:41 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:32:51 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:32:53 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:32:54 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:32:57 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:33:07 --> O usuario excluiu um outro usuário com id: 25
INFO  - 2013-04-11 15:33:07 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:34:03 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:34:05 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:35:24 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:43:42 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:43:43 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 15:43:50 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:43:53 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:45:16 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:47:53 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:47:55 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-11 15:47:56 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:48:08 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 15:54:25 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 15:57:18 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 16:00:13 --> O usuario acessou a area de atualização de novos usuários
INFO  - 2013-04-11 16:01:13 --> O usuario acessou a area de atualização de novos usuários
INFO  - 2013-04-11 16:01:43 --> O usuario acessou a area de atualização de novos usuários
INFO  - 2013-04-11 16:01:55 --> O usuario acessou a area de atualização de novos usuários
INFO  - 2013-04-11 16:02:20 --> O usuario acessou a area de atualização de novos usuários
INFO  - 2013-04-11 16:02:52 --> O usuario acessou a area de atualização de novos usuários
INFO  - 2013-04-11 16:03:07 --> O usuario acessou a area de atualização de novos usuários
INFO  - 2013-04-11 16:10:41 --> O usuario acessou a area de atualização de novos usuários
INFO  - 2013-04-11 16:11:14 --> O usuario acessou a area de atualização de novos usuários
INFO  - 2013-04-11 16:11:26 --> O usuario acessou a area de atualização de novos usuários
INFO  - 2013-04-11 16:11:32 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 16:11:34 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-11 16:19:38 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-11 16:19:40 --> O usuario acessou a area de atualização de novos usuários
INFO  - 2013-04-11 16:20:06 --> O usuario acessou a area de atualização de novos usuários
