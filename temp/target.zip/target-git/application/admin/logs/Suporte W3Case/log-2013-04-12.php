<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

INFO  - 2013-04-12 08:17:32 --> O usuario logou no sistema
INFO  - 2013-04-12 13:18:56 --> O usuario logou no sistema
INFO  - 2013-04-12 13:25:55 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 13:25:57 --> O usuario mudou a configuracao: caminhoArquivos para /home/w3case/public_html/target-git/arquivos/
INFO  - 2013-04-12 13:25:57 --> O usuario mudou a configuracao: caminhoRaiz para /home/w3case/public_html/target-git/
INFO  - 2013-04-12 13:25:57 --> O usuario mudou a configuracao: timezone para America/Campo_Grande
INFO  - 2013-04-12 13:31:09 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 13:34:49 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 13:38:38 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 13:42:47 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 13:42:50 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 13:42:52 --> O usuario mudou a configuracao: caminhoArquivos para /home/w3case/public_html/target-git/arquivos/
INFO  - 2013-04-12 13:42:52 --> O usuario mudou a configuracao: caminhoModulosAdmin para /home/w3case/public_html/application/admin/
INFO  - 2013-04-12 13:42:52 --> O usuario mudou a configuracao: caminhoModulosPublic para /home/w3case/public_html/application/public
INFO  - 2013-04-12 13:42:52 --> O usuario mudou a configuracao: caminhoRaiz para /home/w3case/public_html/target-git/
INFO  - 2013-04-12 13:42:52 --> O usuario mudou a configuracao: caminhoRelativoRaiz para /public_html/
INFO  - 2013-04-12 13:42:52 --> O usuario mudou a configuracao: retornoDeRegistros para 100
INFO  - 2013-04-12 13:42:52 --> O usuario mudou a configuracao: timezone para America/Campo_Grande
INFO  - 2013-04-12 13:42:52 --> O usuario mudou a configuracao: timeZoneMysql para -01:00
INFO  - 2013-04-12 13:42:52 --> O usuario mudou a configuracao: versaoSistema para 3
INFO  - 2013-04-12 13:42:59 --> O usuario mudou a configuracao: caminhoArquivos para /home/w3case/public_html/target-git/arquivos/
INFO  - 2013-04-12 13:42:59 --> O usuario mudou a configuracao: caminhoModulosAdmin para /home/w3case/public_html/application/admin/
INFO  - 2013-04-12 13:42:59 --> O usuario mudou a configuracao: caminhoModulosPublic para /home/w3case/public_html/application/public
INFO  - 2013-04-12 13:42:59 --> O usuario mudou a configuracao: caminhoRaiz para /home/w3case/public_html/target-git/
INFO  - 2013-04-12 13:42:59 --> O usuario mudou a configuracao: caminhoRelativoRaiz para /public_html/
INFO  - 2013-04-12 13:42:59 --> O usuario mudou a configuracao: retornoDeRegistros para 100
INFO  - 2013-04-12 13:42:59 --> O usuario mudou a configuracao: timezone para America/Campo_Grande
INFO  - 2013-04-12 13:43:00 --> O usuario mudou a configuracao: timeZoneMysql para -01:00
INFO  - 2013-04-12 13:43:00 --> O usuario mudou a configuracao: versaoSistema para 3
INFO  - 2013-04-12 13:43:57 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 13:44:38 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 13:45:37 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 13:54:07 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 13:55:00 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 13:56:23 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 13:57:35 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 13:58:53 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:02:30 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:02:44 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:02:55 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:03:53 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:05:49 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:06:00 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:06:11 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:06:14 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:07:19 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:08:17 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:09:55 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:10:21 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 14:11:14 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 14:12:15 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 14:12:22 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 14:12:55 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 14:13:03 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 14:13:16 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 14:13:41 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 14:34:03 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:38:36 --> O usuario acessou a área de configurações de MetaTags / Analytics
INFO  - 2013-04-12 14:39:04 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 14:39:07 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:39:10 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 14:39:54 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 14:39:55 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:39:59 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 14:40:24 --> O usuario acessou a área de configurações de MetaTags / Analytics
INFO  - 2013-04-12 14:43:28 --> O usuario acessou a área de configurações de MetaTags / Analytics
INFO  - 2013-04-12 14:43:52 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:43:54 --> O usuario acessou a área de configurações de MetaTags / Analytics
INFO  - 2013-04-12 14:44:27 --> O usuario acessou a área de configurações de MetaTags / Analytics
INFO  - 2013-04-12 14:44:33 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 14:44:36 --> O usuario acessou a área de configurações de MetaTags / Analytics
INFO  - 2013-04-12 14:47:06 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 14:47:07 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 14:47:08 --> O usuario acessou a área de configurações de MetaTags / Analytics
INFO  - 2013-04-12 16:24:45 --> O usuario acessou a área de configurações gerais
INFO  - 2013-04-12 16:24:48 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 16:24:52 --> O usuario acessou a área de configurações de MetaTags / Analytics
INFO  - 2013-04-12 16:34:12 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-12 16:34:14 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-12 16:34:15 --> O usuario acessou a area de cadastro de novos usuários
INFO  - 2013-04-12 16:34:17 --> O usuario acessou a área para a listagem dos dados dos usuarios
INFO  - 2013-04-12 16:34:19 --> O usuario acessou a área para a listagem dos usuarios na lixeira
INFO  - 2013-04-12 16:48:35 --> O usuario acessou a área de configurações do Codigo do tempo
INFO  - 2013-04-12 16:49:15 --> O usuario acessou a área de configurações do Codigo do tempo
INFO  - 2013-04-12 16:49:18 --> O usuario acessou a área de configurações do Codigo do tempo
INFO  - 2013-04-12 16:49:32 --> O usuario acessou a área de configurações do Codigo do tempo
INFO  - 2013-04-12 16:49:33 --> O usuario acessou a área de configurações do Codigo do tempo
INFO  - 2013-04-12 16:49:34 --> O usuario acessou a área de configurações do Codigo do tempo
INFO  - 2013-04-12 16:49:54 --> O usuario acessou a área de configurações do Codigo do tempo
INFO  - 2013-04-12 16:50:03 --> O usuario acessou a área de configurações do Codigo do tempo
INFO  - 2013-04-12 16:50:10 --> O usuario acessou a área de configurações de MetaTags / Analytics
INFO  - 2013-04-12 16:50:11 --> O usuario acessou a área de configurações de emails
INFO  - 2013-04-12 16:50:12 --> O usuario acessou a área de configurações gerais
