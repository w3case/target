<h2 class="page-title">
	<i class="icon-align-left"></i>
	Textos e Imagens
</h2>

<?php $this->load->view("nav") ?>