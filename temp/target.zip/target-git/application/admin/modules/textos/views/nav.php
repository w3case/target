<div class="widget">	
	<div class="widget-content">
		<ul id="" class="main-nav">
			<li>
				<a href="textos/cadastrar" class="btn">
					<i class="icon-plus"></i>
					Cadastrar
				</a>
			</li>

			<li>
				<a href="textos/gerenciar" class="btn">
					<i class="icon-align-justify"></i>
					Gerenciar
				</a>
			</li>

			<li>
				<a href="textos/lixeira" class="btn">
					<i class="icon-trash"></i>
					Lixeira
				</a>
			</li>
		</ul>
	</div>
</div>