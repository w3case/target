<div class="widget">	
    <div class="widget-content">
        <ul id="" class="main-nav">
            <li>
                <a href="usuarios/cadastrar" class="btn">
                    <i class="icon-plus"></i>
                    Cadastrar
                </a>
            </li>

            <li>
                <a href="usuarios/gerenciar/null" class="btn">
                    <i class="icon-align-justify"></i>
                    Gerenciar
                </a>
            </li>

            <li>
                <a href="usuarios/lixeira" class="btn">
                    <i class="icon-trash"></i>
                    Lixeira
                </a>
            </li>
        </ul>
    </div>
</div>