<div class="widget">	
    <div class="widget-content">
        <ul id="" class="main-nav">
            <li>
                <a href="configuracao/geral" class="btn">
                    <i class="icon-wrench"></i>
                    Gerais
                </a>
            </li>

            <li>
                <a href="configuracao/emails" class="btn">
                    <i class="icon-envelope"></i>
                    E-mails
                </a>
            </li>

            <li>
                <a href="configuracao/metas-analytics" class="btn">
                    <i class="icon-flag"></i>
                    Metas / Analytics
                </a>
            </li>

            <li>
                <a href="configuracao/manutencao" class="btn">
                    <i class="icon-cog"></i>
                    Manutenção
                </a>
            </li>

            <li>
                <a href="configuracao/tempo" class="btn">
                    <i class="icon-leaf"></i>
                    Tempo
                </a>
            </li>
            
        </ul>
    </div>
</div>